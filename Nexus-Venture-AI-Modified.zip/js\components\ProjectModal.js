/**
 * NEXUS VENTURE AI - Project Details Modal Component
 * Displays all 9 sections in EXACT order:
 * 1. PROJECT SUMMARY & FUNDING BOXES
 * 2. WORKING-MODEL VIDEO & LIVE DEMO
 * 3. WHAT THE PROJECT DOES
 * 4. REAL BENEFITS FOR PEOPLE
 * 5. TECHNICAL DETAILS & PARTS LIST
 * 6. PATENT & INTELLECTUAL PROPERTY STATUS
 * 7. DEVELOPER PROFILE
 * 8. RATINGS & REVIEWS
 * 9. BOTTOM ACTION BAR
 */

function ProjectModal({ project, onClose, onAddReview }) {
  if (!project) return null;

  const { useState } = React;

  // Review submission state inside modal
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewerName, setReviewerName] = useState('');
  const [reviewerRole, setReviewerRole] = useState('Investor');
  const [ratingVal, setRatingVal] = useState(4.5);
  const [feedback, setFeedback] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);
  const [founderEmailNotice, setFounderEmailNotice] = useState(false);

  // Currency Formatter ensuring consistent number display and preventing comma errors
  const formatCurrency = (val) => {
    if (!val) return '₹ 0';
    const digitsOnly = val.toString().replace(/[^0-9]/g, '');
    const num = parseInt(digitsOnly, 10);
    if (isNaN(num)) return val;
    return '₹ ' + num.toLocaleString('en-IN');
  };

  // Convert any YouTube link into a clean embeddable URL
  const getEmbedVideoUrl = (rawUrl) => {
    if (!rawUrl) return 'https://www.youtube-nocookie.com/embed/ScMzIvxBSi4';

    let videoId = '';
    // YouTube Watch URL: youtube.com/watch?v=ID
    if (rawUrl.includes('watch?v=')) {
      videoId = rawUrl.split('watch?v=')[1]?.split('&')[0];
    } 
    // YouTube Short URL: youtu.be/ID
    else if (rawUrl.includes('youtu.be/')) {
      videoId = rawUrl.split('youtu.be/')[1]?.split('?')[0];
    }
    // Already an embed URL: youtube.com/embed/ID
    else if (rawUrl.includes('/embed/')) {
      return rawUrl;
    }

    if (videoId) {
      return `https://www.youtube-nocookie.com/embed/${videoId}?rel=0`;
    }
    return rawUrl;
  };

  // Direct watch link for YouTube
  const getDirectWatchUrl = (rawUrl) => {
    if (!rawUrl) return 'https://www.youtube.com/watch?v=ScMzIvxBSi4';
    if (rawUrl.includes('/embed/')) {
      const id = rawUrl.split('/embed/')[1]?.split('?')[0];
      return `https://www.youtube.com/watch?v=${id}`;
    }
    return rawUrl;
  };

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    if (!reviewerName.trim() || !feedback.trim()) return;

    if (onAddReview) {
      onAddReview(project.id, {
        reviewerName: reviewerName.trim(),
        role: reviewerRole,
        rating: parseFloat(ratingVal) || 4.5,
        comment: feedback.trim()
      });
    }

    setReviewSubmitted(true);
    setTimeout(() => {
      setReviewSubmitted(false);
      setShowReviewForm(false);
      setFeedback('');
    }, 2000);
  };

  // Connect with Founder: Pre-addressed Gmail / email composition window
  const handleConnectWithFounder = () => {
    const dev = project.developer || {};
    const email = dev.email || 'founder@nexusventure.ai';
    const founderName = dev.name || 'Project Founder';
    const subject = `NEXUS VENTURE AI: Investment Inquiry for ${project.name}`;
    const body = `Hello ${founderName},\n\nI reviewed your project "${project.name}" on the NEXUS VENTURE AI platform.\n\nI would like to discuss your technology, milestone roadmap, and investment tranches under the platform's milestone escrow protocol.\n\nBest regards,\n`;

    const gmailWebUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(email)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    const mailtoFallback = `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    setFounderEmailNotice(true);

    // Open Gmail web composition in a new window; fall back to mailto if popup blocked
    const newWindow = window.open(gmailWebUrl, '_blank');
    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
      window.location.href = mailtoFallback;
    }

    setTimeout(() => {
      setFounderEmailNotice(false);
    }, 4500);
  };

  // Helper for star icons
  const renderStars = (rating) => {
    const stars = [];
    const num = typeof rating === 'number' ? rating : parseFloat(rating) || 4.5;
    const full = Math.floor(num);
    const half = (num % 1) >= 0.25 && (num % 1) <= 0.75;
    for (let i = 1; i <= 5; i++) {
      if (i <= full) {
        stars.push(<span key={i} className="material-symbols-outlined text-[16px] text-amber-500 fill-current">star</span>);
      } else if (i === full + 1 && half) {
        stars.push(<span key={i} className="material-symbols-outlined text-[16px] text-amber-500 fill-current">star_half</span>);
      } else {
        stars.push(<span key={i} className="material-symbols-outlined text-[16px] text-gray-300">star</span>);
      }
    }
    return stars;
  };

  // Patent badge styling helper
  const getPatentBadge = (status) => {
    switch (status) {
      case 'Granted Patent':
        return { bg: 'bg-emerald-50 text-emerald-800 border-emerald-400', icon: 'verified', label: 'Granted Patent' };
      case 'Published Patent Application':
        return { bg: 'bg-blue-50 text-blue-800 border-blue-400', icon: 'description', label: 'Published Patent Application' };
      case 'Patent Applied – Pending':
        return { bg: 'bg-amber-50 text-amber-900 border-amber-400', icon: 'pending_actions', label: 'Patent Applied – Pending' };
      default:
        return { bg: 'bg-gray-100 text-gray-700 border-gray-300', icon: 'info', label: 'No Patent (Open Tech)' };
    }
  };

  const patentBadge = getPatentBadge(project.patentStatus);

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-dialog max-w-4xl" onClick={(e) => e.stopPropagation()}>
        
        {/* ===================== HEADER ===================== */}
        <div className="modal-header-burgundy">
          <div className="flex flex-col gap-1 min-w-0 pr-4">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#f7e7ce] text-[#561922] border border-[#d4af37]">
                {project.sector}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#3c0b12] text-white border border-[#e8d3b9]/40">
                {project.stage}
              </span>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 ${patentBadge.bg}`}>
                <span className="material-symbols-outlined text-[13px]">{patentBadge.icon}</span>
                <span>{patentBadge.label}</span>
              </span>
            </div>

            <h2 className="font-headline font-bold text-xl sm:text-2xl text-white truncate">
              {project.name}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#561922] hover:bg-[#722f37] border border-[#d4af37] text-white flex items-center justify-center shrink-0 cursor-pointer"
            aria-label="Close Project Details"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Founder Email Composition Toast Notification */}
        {founderEmailNotice && (
          <div className="p-3 bg-[#561922] text-[#f7e7ce] border-b-2 border-[#d4af37] flex items-center justify-between text-xs font-semibold px-6">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#d4af37] text-[18px]">mail</span>
              <span>Opening pre-addressed Gmail compose window to connect with <strong>{project.developer?.name}</strong>...</span>
            </div>
            <span className="text-[10px] text-[#e8d3b9]">Direct Communication Flow</span>
          </div>
        )}

        {/* ===================== SCROLLABLE BODY (9 SECTIONS) ===================== */}
        <div className="modal-body-scroll flex flex-col gap-8 text-[#1b1c1a]">
          
          {/* SECTION 1: PROJECT SUMMARY & CONSISTENT FUNDING BOXES */}
          <section className="flex flex-col gap-3 pb-6 border-b border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[20px] text-[#d4af37]">summarize</span>
              <h3 className="font-headline font-bold text-base uppercase tracking-wider text-[#561922]">
                1. Project Summary
              </h3>
            </div>

            <p className="text-sm sm:text-base font-semibold text-[#1b1c1a] leading-relaxed bg-[#faf6f0] p-4 rounded-xl border border-[#e8d3b9]">
              "{project.summary}"
            </p>

            {/* Exactly Consistent Sizing & Appearance for Both Funding Boxes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
              {/* Box 1: Total Build Cost */}
              <div className="p-5 rounded-2xl bg-white border-2 border-[#e8d3b9] flex flex-col justify-between gap-2 shadow-xs min-h-[115px]">
                <span className="text-xs font-bold uppercase tracking-wider text-[#6b5c47]">
                  Total Build Cost
                </span>
                <span className="text-2xl font-extrabold text-[#561922]">
                  {formatCurrency(project.buildCost)}
                </span>
                <span className="text-[11px] text-[#534343]">
                  {project.costExplanation || 'Includes BOM & sensor assembly'}
                </span>
              </div>

              {/* Box 2: Total Target Funding Required */}
              <div className="p-5 rounded-2xl bg-white border-2 border-[#d4af37] flex flex-col justify-between gap-2 shadow-xs min-h-[115px]">
                <span className="text-xs font-bold uppercase tracking-wider text-[#b89358]">
                  Total Target Funding Required
                </span>
                <span className="text-2xl font-extrabold text-[#561922]">
                  {formatCurrency(project.targetFunding)}
                </span>
                <span className="text-[11px] text-[#534343]">
                  Pre-seed tranche via milestone smart escrow
                </span>
              </div>
            </div>
          </section>

          {/* SECTION 2: WORKING-MODEL VIDEO & LIVE DEMO */}
          {/* Direct embed URL + Direct YouTube opening without error screen */}
          <section className="flex flex-col gap-3 pb-6 border-b border-[#e8d3b9]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#561922]">
                <span className="material-symbols-outlined text-[20px] text-[#d4af37]">smart_display</span>
                <h3 className="font-headline font-bold text-base uppercase tracking-wider text-[#561922]">
                  2. Working-Model Video & Live Demo
                </h3>
              </div>

              <a
                href={getDirectWatchUrl(project.videoUrl)}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-bold text-[#561922] hover:text-[#d4af37] flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#faf6f0] border border-[#e8d3b9] transition-all"
              >
                <span className="material-symbols-outlined text-[16px] text-red-600">play_circle</span>
                <span>Watch on YouTube</span>
              </a>
            </div>

            <div className="relative w-full rounded-2xl overflow-hidden border-2 border-[#e8d3b9] bg-black shadow-inner aspect-video">
              <iframe
                src={getEmbedVideoUrl(project.videoUrl)}
                title={`${project.name} Working Model Demonstration`}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>

            <p className="text-xs text-[#534343] italic bg-[#faf6f0] p-3 rounded-xl border border-[#e8d3b9]">
              <strong>Demonstration Overview:</strong> {project.videoDescription || 'Live technical prototype test demonstration showing sensor telemetry and hardware loop execution.'}
            </p>
          </section>

          {/* SECTION 3: WHAT THE PROJECT DOES (PRESERVED) */}
          <section className="flex flex-col gap-3 pb-6 border-b border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[20px] text-[#d4af37]">help</span>
              <h3 className="font-headline font-bold text-base uppercase tracking-wider text-[#561922]">
                3. What the Project Does
              </h3>
            </div>

            <p className="text-xs sm:text-sm text-[#1b1c1a] leading-relaxed">
              {project.fullDescription}
            </p>
          </section>

          {/* SECTION 4: REAL BENEFITS FOR PEOPLE (PRESERVED) */}
          <section className="flex flex-col gap-3 pb-6 border-b border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[20px] text-[#d4af37]">volunteer_activism</span>
              <h3 className="font-headline font-bold text-base uppercase tracking-wider text-[#561922]">
                4. Real Benefits for People
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {(project.benefits || []).map((benefit, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-white border border-[#e8d3b9] shadow-2xs flex flex-col gap-2">
                  <div className="w-7 h-7 rounded-lg bg-[#faf6f0] text-[#561922] font-bold text-xs flex items-center justify-center border border-[#d4af37]">
                    0{idx + 1}
                  </div>
                  <p className="text-xs text-[#534343] leading-relaxed">{benefit}</p>
                </div>
              ))}
            </div>
          </section>

          {/* SECTION 5: TECHNICAL DETAILS & PARTS LIST */}
          <section className="flex flex-col gap-3 pb-6 border-b border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[20px] text-[#d4af37]">memory</span>
              <h3 className="font-headline font-bold text-base uppercase tracking-wider text-[#561922]">
                5. Technical Details & Parts List
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Computer Languages */}
              <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col gap-2">
                <span className="text-xs font-bold text-[#561922] flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-[#d4af37]">code</span>
                  <span>Computer Languages Used</span>
                </span>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {(project.languages || []).map((lang) => (
                    <span key={lang} className="px-2 py-0.5 rounded bg-white border border-[#e8d3b9] text-[11px] font-semibold text-[#1b1c1a]">
                      {lang}
                    </span>
                  ))}
                </div>
              </div>

              {/* Software & Frameworks */}
              <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col gap-2">
                <span className="text-xs font-bold text-[#561922] flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-[#d4af37]">layers</span>
                  <span>Software & Frameworks</span>
                </span>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {(project.frameworks || []).map((fw) => (
                    <span key={fw} className="px-2 py-0.5 rounded bg-white border border-[#e8d3b9] text-[11px] font-semibold text-[#1b1c1a]">
                      {fw}
                    </span>
                  ))}
                </div>
              </div>

              {/* Hardware Parts List */}
              <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col gap-2">
                <span className="text-xs font-bold text-[#561922] flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-[#d4af37]">hardware</span>
                  <span>Hardware Parts List</span>
                </span>
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {(project.hardwareParts || []).map((part) => (
                    <span key={part} className="px-2 py-0.5 rounded bg-white border border-[#e8d3b9] text-[11px] font-semibold text-[#1b1c1a]">
                      {part}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* SECTION 6: PATENT & INTELLECTUAL PROPERTY STATUS */}
          <section className="flex flex-col gap-3 pb-6 border-b border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[20px] text-[#d4af37]">policy</span>
              <h3 className="font-headline font-bold text-base uppercase tracking-wider text-[#561922]">
                6. Patent & Intellectual Property Status
              </h3>
            </div>

            <div className="p-5 rounded-2xl bg-[#faf6f0] border-2 border-[#b89358] flex flex-col gap-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${patentBadge.bg}`}>
                  <span className="material-symbols-outlined text-[16px]">{patentBadge.icon}</span>
                  <span>{patentBadge.label}</span>
                </span>
                {project.patentDetails?.grantDate && (
                  <span className="text-xs text-[#6b5c47] font-semibold">
                    Effective: {project.patentDetails.grantDate}
                  </span>
                )}
              </div>

              {project.patentDetails && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2">
                  {project.patentDetails.patentNumber && (
                    <div className="p-2.5 rounded-lg bg-white border border-[#e8d3b9]">
                      <span className="text-[#6b5c47] block text-[10px] font-bold uppercase">Patent Number</span>
                      <span className="font-bold text-[#1b1c1a]">{project.patentDetails.patentNumber}</span>
                    </div>
                  )}
                  {project.patentDetails.publicationNumber && (
                    <div className="p-2.5 rounded-lg bg-white border border-[#e8d3b9]">
                      <span className="text-[#6b5c47] block text-[10px] font-bold uppercase">Publication ID</span>
                      <span className="font-bold text-[#1b1c1a]">{project.patentDetails.publicationNumber}</span>
                    </div>
                  )}
                  {project.patentDetails.description && (
                    <div className="sm:col-span-2 p-2.5 rounded-lg bg-white border border-[#e8d3b9]">
                      <span className="text-[#6b5c47] block text-[10px] font-bold uppercase">Patent Abstract</span>
                      <span className="font-semibold text-[#1b1c1a]">{project.patentDetails.description}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </section>

          {/* SECTION 7: DEVELOPER PROFILE (PRESERVED) */}
          <section className="flex flex-col gap-3 pb-6 border-b border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[20px] text-[#d4af37]">badge</span>
              <h3 className="font-headline font-bold text-base uppercase tracking-wider text-[#561922]">
                7. Developer Profile
              </h3>
            </div>

            {project.developer && (
              <div className="p-5 rounded-2xl bg-white border-2 border-[#e8d3b9] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
                <div className="flex items-center gap-4">
                  <img
                    src={project.developer.avatar}
                    alt={project.developer.name}
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-[#d4af37] shadow-sm"
                  />
                  <div className="flex flex-col gap-0.5">
                    <h4 className="font-headline font-bold text-base text-[#1b1c1a]">
                      {project.developer.name}
                    </h4>
                    <span className="text-xs text-[#561922] font-bold">
                      {project.developer.institution}
                    </span>
                    <span className="text-[11px] text-[#534343]">
                      {project.developer.background}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleConnectWithFounder}
                  className="btn-burgundy text-xs py-2.5 px-4 shrink-0 shadow-sm flex items-center gap-2"
                >
                  <span className="material-symbols-outlined text-[18px] text-[#d4af37]">mail</span>
                  <span>Connect with Founder</span>
                </button>
              </div>
            )}
          </section>

          {/* SECTION 8: RATINGS & REVIEWS */}
          <section className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#561922]">
                <span className="material-symbols-outlined text-[20px] text-[#d4af37]">reviews</span>
                <h3 className="font-headline font-bold text-base uppercase tracking-wider text-[#561922]">
                  8. Ratings & Reviews
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setShowReviewForm(!showReviewForm)}
                className="btn-gold text-xs py-1.5 px-3 shadow-2xs"
              >
                <span>{showReviewForm ? 'Close Form' : 'Write a Review'}</span>
              </button>
            </div>

            {/* In-Modal Review Form */}
            {showReviewForm && (
              <form onSubmit={handleReviewSubmit} className="p-4 rounded-xl bg-[#faf6f0] border border-[#d4af37] flex flex-col gap-3 text-xs">
                {reviewSubmitted && (
                  <div className="p-2 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded font-bold">
                    Review submitted and average score recalculated!
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="font-bold text-[#1b1c1a]">Reviewer Name *</label>
                    <input
                      type="text"
                      required
                      value={reviewerName}
                      onChange={(e) => setReviewerName(e.target.value)}
                      placeholder="Your Name"
                      className="p-2 bg-white border border-[#e8d3b9] rounded-lg"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="font-bold text-[#1b1c1a]">Role *</label>
                    <select
                      value={reviewerRole}
                      onChange={(e) => setReviewerRole(e.target.value)}
                      className="p-2 bg-white border border-[#e8d3b9] rounded-lg"
                    >
                      <option value="Investor">Investor</option>
                      <option value="University Professor">University Professor</option>
                      <option value="Senior Hardware Engineer">Senior Hardware Engineer</option>
                    </select>
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-bold text-[#1b1c1a]">Rating Score (Decimal supported: 1.0 - 5.0)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="1.0"
                    max="5.0"
                    value={ratingVal}
                    onChange={(e) => setRatingVal(e.target.value)}
                    className="p-2 bg-white border border-[#e8d3b9] rounded-lg w-32"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-bold text-[#1b1c1a]">Peer Review & Feedback *</label>
                  <textarea
                    required
                    rows="3"
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    placeholder="Provide technical evaluation, unit economic feedback or escrow comments..."
                    className="p-2 bg-white border border-[#e8d3b9] rounded-lg"
                  ></textarea>
                </div>

                <div className="flex justify-end gap-2">
                  <button type="submit" className="btn-burgundy text-xs py-2 px-4 shadow-xs">
                    Submit Audited Review
                  </button>
                </div>
              </form>
            )}

            {/* List of Reviews */}
            <div className="flex flex-col gap-3">
              {(project.reviews || []).map((rev) => (
                <div key={rev.id || Math.random()} className="p-4 rounded-xl bg-white border border-[#e8d3b9] shadow-2xs flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <div className="flex items-center">
                        {renderStars(rev.rating)}
                      </div>
                      <span className="text-xs font-bold text-[#1b1c1a]">
                        {parseFloat(rev.rating).toFixed(1)}
                      </span>
                    </div>
                    <span className="text-[10px] text-[#6b5c47] font-semibold">{rev.date}</span>
                  </div>
                  <p className="text-xs text-[#534343] italic">"{rev.comment}"</p>
                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-[#faf6f0]">
                    <span className="font-bold text-[#1b1c1a]">{rev.reviewerName}</span>
                    <span className="text-[#561922] font-semibold">{rev.role}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

        </div>

        {/* ===================== BOTTOM ACTION BAR ===================== */}
        <div className="p-4 sm:p-5 bg-[#faf6f0] border-t-2 border-[#e8d3b9] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-[#534343]">
            <span className="material-symbols-outlined text-emerald-600 text-[18px]">lock</span>
            <span>Milestone Smart Escrow Protection Active</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-[#e8d3b9] bg-white text-xs font-bold text-[#534343] hover:bg-gray-50 cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={handleConnectWithFounder}
              className="btn-gold text-xs py-2.5 px-5 shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">mail</span>
              <span>Connect with Founder</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

window.ProjectModal = ProjectModal;
