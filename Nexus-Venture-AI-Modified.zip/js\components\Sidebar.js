/**
 * NEXUS VENTURE AI - Left Sidebar Component
 * Permanent vertical sidebar with exactly SIX menu items:
 * 1. Home
 * 2. Explore Projects
 * 3. Submit Project
 * 4. Investor Profile
 * 5. Ratings & Reviews
 * 6. Talk to Nexus Venture
 */

function Sidebar({ activeTab, setActiveTab, currentUser }) {
  const menuItems = [
    { id: 'home', label: 'Home', icon: 'home' },
    { id: 'explore', label: 'Explore Projects', icon: 'travel_explore' },
    { id: 'submit', label: 'Submit Project', icon: 'rocket_launch' },
    { id: 'investor', label: 'Investor Profile', icon: 'account_balance' },
    { id: 'ratings', label: 'Ratings & Reviews', icon: 'star' },
    { id: 'chatbot', label: 'Talk to Nexus Venture', icon: 'smart_toy' }
  ];

  const handleMenuClick = (id) => {
    setActiveTab(id);
  };

  return (
    <aside className="app-sidebar" id="appSidebar">
      {/* Sidebar Header with Logo */}
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <span className="material-symbols-outlined text-[24px]">policy</span>
        </div>
        <div className="flex flex-col">
          <span className="font-headline font-extrabold text-base tracking-tight text-white leading-tight">
            NEXUS VENTURE AI
          </span>
          <span className="text-[10px] text-[#d4af37] font-bold uppercase tracking-wider">
            Innovation Ecosystem
          </span>
        </div>
      </div>

      {/* Exactly SIX Menu Items */}
      <nav className="flex-1 py-4 px-3 flex flex-col justify-between overflow-y-auto">
        <ul className="sidebar-menu flex flex-col gap-1.5">
          {menuItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => handleMenuClick(item.id)}
                  className={`sidebar-item-btn ${isActive ? 'active' : ''}`}
                >
                  <span className={`material-symbols-outlined sidebar-icon text-[20px] ${isActive ? 'text-[#d4af37]' : 'text-[#e8d3b9]'}`}>
                    {item.icon}
                  </span>
                  <span className="font-semibold text-xs sm:text-sm">{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Clean Subtle Footer Info */}
      <div className="p-4 border-t border-[#b89358]/30 flex items-center justify-between text-[11px] text-[#e8d3b9]">
        <span className="font-semibold text-[#f7e7ce]">NEXUS VENTURE AI</span>
        <span className="text-[10px] px-2 py-0.5 rounded bg-[#561922] text-[#d4af37] border border-[#d4af37]">
          v2.4
        </span>
      </div>
    </aside>
  );
}

window.Sidebar = Sidebar;
