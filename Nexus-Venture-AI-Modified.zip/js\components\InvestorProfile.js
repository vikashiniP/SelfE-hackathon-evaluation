/**
 * NEXUS VENTURE AI - Investor Profile Component
 * Features:
 * - Login-based visibility: "Update My Investor Profile" hidden from general visitors,
 *   visible only when an investor is logged in.
 * - Single-letter & partial-word search across name, company, preferred sectors, ticket range.
 * - Search highlighting with champagne-gold styling.
 * - 6 predefined investment sectors + "Others" option with custom sector input.
 * - Contact Investor form with Reset button & consistent button sizes.
 * - Preserves existing 3 verified investor profiles.
 */

function InvestorProfile({ investors = [], currentUser, onContactInvestor, onUpdateProfile }) {
  const { useState, useMemo } = React;

  const [sectorFilter, setSectorFilter] = useState('All');
  const [searchInput, setSearchInput] = useState('');
  const [activeSearch, setActiveSearch] = useState('');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [contactingInvestor, setContactingInvestor] = useState(null);

  // Six predefined investment sectors
  const predefinedSectors = [
    'Agriculture',
    'Environment',
    'Healthcare',
    'Education',
    'Technology',
    'Business'
  ];

  // Investor Profile Form State
  const [profileForm, setProfileForm] = useState({
    name: currentUser ? currentUser.name : 'Dr. Ananya Sen',
    company: currentUser && currentUser.organization ? currentUser.organization : 'Aethel MedTech Angels',
    designation: 'Managing Partner & Lead Allocator',
    background: 'Former healthcare operator and venture syndicate lead with 16 years of early-stage medical device investment experience.',
    experience: '16+ Years in DeepTech & MedTech Seed Allocation',
    areasOfInterest: 'Wearable Biosensors, Robotics, Point-of-Care Diagnostics',
    preferredSectors: ['Healthcare', 'Technology'],
    otherSectorText: '',
    hasOtherSector: false,
    previousInvestments: 'Deployed ₹14.5 Cr across 9 medical device startups with 3 Series A follow-ons.',
    pastProjectDetails: 'Lead seed investor in NeuroScan and EndoSense Devices.',
    fundingRange: '₹25,00,000 – ₹1,50,00,000 per project',
    returnRateContext: 'Reported portfolio IRR of 28.4% across 7-year realized vintage with milestone-based tranche disbursements.',
    email: currentUser ? currentUser.email : 'ananya.sen@aethelangels.vc',
    phone: '+91 98100 11223'
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Contact modal state inside component
  const [contactForm, setContactForm] = useState({
    senderName: currentUser ? currentUser.name : '',
    senderEmail: currentUser ? currentUser.email : '',
    subject: '',
    message: ''
  });
  const [contactSuccess, setContactSuccess] = useState(false);

  // Check if current user is logged in as an investor
  const isAuthorizedInvestor = Boolean(
    currentUser && currentUser.isLoggedIn && (currentUser.role === 'Investor' || currentUser.role === 'investor')
  );

  // Trigger search handler
  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchInput(val);
    setActiveSearch(val.trim());
  };

  // Coordinated search supporting single-letter, partial-word, and cross-field matches
  const filteredInvestors = useMemo(() => {
    return investors.filter((inv) => {
      // Sector filter
      if (sectorFilter !== 'All' && !(inv.preferredSectors || []).includes(sectorFilter)) {
        return false;
      }

      // Single-letter and partial-word search
      if (activeSearch !== '') {
        const q = activeSearch.toLowerCase();
        const matchName = (inv.name || '').toLowerCase().includes(q);
        const matchCompany = (inv.company || '').toLowerCase().includes(q);
        const matchRange = (inv.fundingRange || '').toLowerCase().includes(q);
        const matchSectors = (inv.preferredSectors || []).some((sec) => sec.toLowerCase().includes(q));
        const matchInterest = (inv.areasOfInterest || '').toLowerCase().includes(q);

        if (!matchName && !matchCompany && !matchRange && !matchSectors && !matchInterest) {
          return false;
        }
      }

      return true;
    });
  }, [investors, sectorFilter, activeSearch]);

  // Highlight helper
  const highlightMatch = (text, query) => {
    if (!text) return '';
    if (!query || !query.trim()) return text;

    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);

    return parts.map((part, index) => {
      if (part.toLowerCase() === query.toLowerCase()) {
        return (
          <mark key={index} className="bg-[#f7e7ce] text-[#561922] font-extrabold px-0.5 rounded">
            {part}
          </mark>
        );
      }
      return part;
    });
  };

  const handleSectorToggle = (sector) => {
    setProfileForm((prev) => {
      const current = prev.preferredSectors || [];
      if (current.includes(sector)) {
        return { ...prev, preferredSectors: current.filter((s) => s !== sector) };
      } else {
        return { ...prev, preferredSectors: [...current, sector] };
      }
    });
  };

  const handleProfileSubmit = (e) => {
    e.preventDefault();
    const finalSectors = [...profileForm.preferredSectors];
    if (profileForm.hasOtherSector && profileForm.otherSectorText.trim()) {
      finalSectors.push(profileForm.otherSectorText.trim());
    }

    if (onUpdateProfile) {
      onUpdateProfile({ ...profileForm, preferredSectors: finalSectors });
    }
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      setIsEditingProfile(false);
    }, 1500);
  };

  // Open Contact modal
  const handleOpenContact = (inv) => {
    setContactingInvestor(inv);
    setContactForm({
      senderName: currentUser ? currentUser.name : '',
      senderEmail: currentUser ? currentUser.email : '',
      subject: `Investment Collaboration Inquiry for ${inv.name}`,
      message: ''
    });
    setContactSuccess(false);
  };

  // Contact form submission
  const handleContactSubmit = (e) => {
    e.preventDefault();
    if (!contactForm.senderName.trim() || !contactForm.senderEmail.trim() || !contactForm.message.trim()) return;

    setContactSuccess(true);
    setTimeout(() => {
      setContactSuccess(false);
      setContactingInvestor(null);
    }, 2000);
  };

  // Contact form reset
  const handleContactReset = () => {
    setContactForm({
      senderName: '',
      senderEmail: '',
      subject: contactingInvestor ? `Investment Collaboration Inquiry for ${contactingInvestor.name}` : '',
      message: ''
    });
  };

  return (
    <div className="w-full flex flex-col gap-8 pb-16">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="gold-badge mb-1">Institutional Capital Network</div>
          <h1 className="font-headline font-bold text-2xl sm:text-3xl lg:text-4xl text-[#1b1c1a]">
            Investor Profiles & Allocators
          </h1>
          <p className="text-xs sm:text-sm text-[#534343] mt-0.5">
            Connect with verified angels, syndicates, and VCs looking for patent-backed startups in your sector.
          </p>
        </div>

        {/* Update My Investor Profile: Visible ONLY to Authenticated Investors */}
        {isAuthorizedInvestor ? (
          <button
            type="button"
            onClick={() => setIsEditingProfile(!isEditingProfile)}
            className="btn-gold text-xs py-2.5 px-4 shrink-0 shadow-xs self-start sm:self-auto flex items-center gap-1.5"
          >
            <span className="material-symbols-outlined text-[18px]">
              {isEditingProfile ? 'visibility' : 'edit_square'}
            </span>
            <span>{isEditingProfile ? 'View Directory' : 'Update My Investor Profile'}</span>
          </button>
        ) : (
          <div className="px-3 py-1.5 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] text-[11px] text-[#6b5c47] font-semibold self-start sm:self-auto">
            <span>Public Investor Directory</span>
          </div>
        )}
      </div>

      {/* Profile Editor (Visible only when investor toggles edit) */}
      {isAuthorizedInvestor && isEditingProfile && (
        <div className="bg-white border-2 border-[#d4af37] rounded-3xl p-6 sm:p-8 shadow-md flex flex-col gap-5 animate-scaleUp">
          <div className="flex items-center justify-between border-b border-[#e8d3b9] pb-3">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[24px]">manage_accounts</span>
              <h2 className="font-headline font-bold text-xl text-[#1b1c1a]">
                Update Your Investor Profile
              </h2>
            </div>
            <span className="text-xs text-[#6b5c47] font-semibold">
              Ecosystem Accreditation Portal
            </span>
          </div>

          {savedSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2">
              <span className="material-symbols-outlined text-emerald-600">check_circle</span>
              <span>Your investor profile has been successfully updated and saved!</span>
            </div>
          )}

          <form onSubmit={handleProfileSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="flex flex-col gap-1">
              <label className="font-bold text-[#1b1c1a]">Investor Full Name *</label>
              <input
                type="text"
                required
                value={profileForm.name}
                onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                className="p-2.5 bg-[#faf6f0] border rounded-xl"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-bold text-[#1b1c1a]">Company / Firm Name *</label>
              <input
                type="text"
                required
                value={profileForm.company}
                onChange={(e) => setProfileForm({ ...profileForm, company: e.target.value })}
                className="p-2.5 bg-[#faf6f0] border rounded-xl"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-bold text-[#1b1c1a]">Designation / Role *</label>
              <input
                type="text"
                required
                value={profileForm.designation}
                onChange={(e) => setProfileForm({ ...profileForm, designation: e.target.value })}
                className="p-2.5 bg-[#faf6f0] border rounded-xl"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="font-bold text-[#1b1c1a]">Typical Ticket Range *</label>
              <input
                type="text"
                required
                value={profileForm.fundingRange}
                onChange={(e) => setProfileForm({ ...profileForm, fundingRange: e.target.value })}
                placeholder="₹25,00,000 – ₹1,50,00,000"
                className="p-2.5 bg-[#faf6f0] border rounded-xl"
              />
            </div>

            {/* Predefined 6 Sectors + Others Option */}
            <div className="sm:col-span-2 flex flex-col gap-2 pt-2 border-t border-[#e8d3b9]">
              <label className="font-bold text-[#1b1c1a]">
                Preferred Investment Sectors (Choose from 6 Sectors or enter Others)
              </label>
              <div className="flex flex-wrap gap-2">
                {predefinedSectors.map((sec) => {
                  const isChecked = (profileForm.preferredSectors || []).includes(sec);
                  return (
                    <button
                      key={sec}
                      type="button"
                      onClick={() => handleSectorToggle(sec)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                        isChecked
                          ? 'bg-[#561922] text-[#f7e7ce] border-[#d4af37]'
                          : 'bg-[#faf6f0] text-[#534343] border-[#e8d3b9]'
                      }`}
                    >
                      {sec}
                    </button>
                  );
                })}
              </div>

              {/* Others Option */}
              <div className="flex items-center gap-3 pt-2">
                <label className="flex items-center gap-1.5 font-bold text-xs text-[#561922] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={profileForm.hasOtherSector}
                    onChange={(e) => setProfileForm({ ...profileForm, hasOtherSector: e.target.checked })}
                    className="accent-[#561922]"
                  />
                  <span>Others (Additional Sectors)</span>
                </label>

                {profileForm.hasOtherSector && (
                  <input
                    type="text"
                    value={profileForm.otherSectorText}
                    onChange={(e) => setProfileForm({ ...profileForm, otherSectorText: e.target.value })}
                    placeholder="Enter custom sector (e.g. Quantum Computing, Clean Mobility)..."
                    className="p-2 bg-white border border-[#d4af37] rounded-xl text-xs flex-1"
                  />
                )}
              </div>
            </div>

            <div className="sm:col-span-2 flex justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => setIsEditingProfile(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-[#534343] bg-gray-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-gold text-xs py-2 px-5 shadow-sm"
              >
                Save Profile Changes
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search & Sector Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#faf6f0] border-2 border-[#e8d3b9]">
        {/* Single-Letter / Partial-Word Search Bar */}
        <div className="relative flex-1">
          <span className="material-symbols-outlined absolute left-3 top-2.5 text-[#b89358] text-[20px]">
            search
          </span>
          <input
            type="text"
            value={searchInput}
            onChange={handleSearchChange}
            placeholder="Search investors by name, firm, sector, ticket size, or letter (e.g. 'H')..."
            className="w-full pl-9 pr-8 py-2 bg-white border border-[#e8d3b9] rounded-xl text-xs text-[#1b1c1a] focus:outline-none focus:border-[#561922]"
          />
          {searchInput && (
            <button
              type="button"
              onClick={() => { setSearchInput(''); setActiveSearch(''); }}
              className="absolute right-2.5 top-2.5 text-gray-400 hover:text-gray-600"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          )}
        </div>

        {/* Sector Filter Dropdown */}
        <div className="flex items-center gap-2 text-xs shrink-0">
          <label htmlFor="investor-sector-filter" className="font-bold text-[#1b1c1a]">Sector:</label>
          <select
            id="investor-sector-filter"
            value={sectorFilter}
            onChange={(e) => setSectorFilter(e.target.value)}
            className="p-2 bg-white border border-[#e8d3b9] rounded-xl text-xs font-semibold text-[#1b1c1a]"
          >
            <option value="All">All Sectors ({investors.length})</option>
            {predefinedSectors.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Three Preserved Investor Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredInvestors.map((inv) => (
          <div
            key={inv.id}
            className="bg-white border-2 border-[#e8d3b9] hover:border-[#b89358] rounded-3xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-5"
          >
            <div className="flex flex-col gap-4">
              {/* Header: Avatar, Name & Firm */}
              <div className="flex items-center gap-4">
                <img
                  src={inv.avatar}
                  alt={inv.name}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-[#d4af37] shadow-xs"
                />
                <div className="flex flex-col min-w-0">
                  <h3 className="font-headline font-bold text-base text-[#1b1c1a] truncate">
                    {highlightMatch(inv.name, activeSearch)}
                  </h3>
                  <span className="text-xs font-bold text-[#561922] truncate">
                    {highlightMatch(inv.company, activeSearch)}
                  </span>
                  <span className="text-[11px] text-[#6b5c47] truncate">
                    {inv.designation}
                  </span>
                </div>
              </div>

              {/* Bio summary */}
              <p className="text-xs text-[#534343] line-clamp-3 leading-relaxed">
                {inv.background}
              </p>

              {/* Investment Ticket Range */}
              <div className="p-3 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col gap-0.5">
                <span className="text-[10px] uppercase font-bold text-[#b89358] tracking-wider">
                  Typical Investment Ticket
                </span>
                <span className="text-xs font-extrabold text-[#561922]">
                  {highlightMatch(inv.fundingRange, activeSearch)}
                </span>
              </div>

              {/* Preferred Sectors Tags */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] uppercase font-bold text-[#6b5c47] tracking-wider">
                  Preferred Sectors
                </span>
                <div className="flex flex-wrap gap-1">
                  {(inv.preferredSectors || []).map((sec) => (
                    <span
                      key={sec}
                      className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#faf6f0] text-[#561922] border border-[#d4af37]"
                    >
                      {highlightMatch(sec, activeSearch)}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Contact Investor Button */}
            <div className="pt-3 border-t border-[#e8d3b9] flex justify-end">
              <button
                type="button"
                onClick={() => handleOpenContact(inv)}
                className="btn-burgundy text-xs py-2 px-4 shadow-xs flex items-center gap-1.5 w-full justify-center"
              >
                <span className="material-symbols-outlined text-[16px] text-[#d4af37]">mail</span>
                <span>Contact Investor</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* ===================== CONTACT INVESTOR MODAL WITH RESET BUTTON ===================== */}
      {contactingInvestor && (
        <div className="modal-overlay" onClick={() => setContactingInvestor(null)}>
          <div className="modal-dialog max-w-lg" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header-burgundy">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#d4af37] text-[22px]">mail</span>
                <h3 className="font-headline font-bold text-lg text-white">
                  Contact Investor
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setContactingInvestor(null)}
                className="w-8 h-8 rounded-full bg-[#561922] text-white flex items-center justify-center border border-[#d4af37]"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <div className="p-6">
              {contactSuccess ? (
                <div className="p-5 bg-emerald-50 border-2 border-emerald-300 rounded-xl text-center flex flex-col items-center gap-2 text-emerald-950">
                  <span className="material-symbols-outlined text-emerald-600 text-[36px]">mark_email_read</span>
                  <span className="font-bold text-sm">Inquiry Dispatched</span>
                  <span className="text-xs text-emerald-800">
                    Your contact request has been registered for <strong>{contactingInvestor.name}</strong>.
                  </span>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="flex flex-col gap-4 text-xs">
                  <div className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#561922]">account_balance</span>
                    <span className="text-xs font-bold text-[#1b1c1a]">
                      Recipient: {contactingInvestor.name} ({contactingInvestor.company})
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex flex-col gap-1">
                      <label className="font-bold text-[#1b1c1a]">Your Name *</label>
                      <input
                        type="text"
                        required
                        value={contactForm.senderName}
                        onChange={(e) => setContactForm({ ...contactForm, senderName: e.target.value })}
                        placeholder="Founder Name"
                        className="p-2.5 bg-[#faf6f0] border rounded-xl"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="font-bold text-[#1b1c1a]">Your Email Address *</label>
                      <input
                        type="email"
                        required
                        value={contactForm.senderEmail}
                        onChange={(e) => setContactForm({ ...contactForm, senderEmail: e.target.value })}
                        placeholder="founder@startup.com"
                        className="p-2.5 bg-[#faf6f0] border rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="font-bold text-[#1b1c1a]">Subject Line</label>
                    <input
                      type="text"
                      value={contactForm.subject}
                      onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                      className="p-2.5 bg-[#faf6f0] border rounded-xl font-semibold"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="font-bold text-[#1b1c1a]">Message / Collaboration Proposal *</label>
                    <textarea
                      required
                      rows="4"
                      value={contactForm.message}
                      onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                      placeholder="Specify your startup stage, patent status, and capital requirement..."
                      className="p-2.5 bg-[#faf6f0] border rounded-xl text-xs"
                    ></textarea>
                  </div>

                  {/* Equal Sized Action Buttons: Reset, Cancel, Send */}
                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e8d3b9]">
                    <button
                      type="button"
                      onClick={handleContactReset}
                      className="w-28 py-2.5 rounded-xl text-xs font-bold text-[#561922] bg-[#faf6f0] border border-[#b89358] hover:bg-[#e8d3b9] text-center"
                    >
                      Reset
                    </button>
                    <button
                      type="button"
                      onClick={() => setContactingInvestor(null)}
                      className="w-28 py-2.5 rounded-xl text-xs font-bold text-[#534343] bg-gray-100 hover:bg-gray-200 text-center"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="w-36 py-2.5 rounded-xl text-xs font-bold bg-[#d4af37] text-[#561922] hover:bg-[#e5c158] border border-[#b89358] shadow-xs text-center"
                    >
                      Send Message
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

window.InvestorProfile = InvestorProfile;
