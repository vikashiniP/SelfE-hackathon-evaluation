/**
 * NEXUS VENTURE AI - Dedicated Chatbot Page Component
 * "Talk to Nexus Venture" Navigation Section
 * Serves as the clean, dedicated integration area for the upcoming AI Chatbot source code.
 */

function ChatbotPage({ onNavigateExplore, onOpenSubmit }) {
  return (
    <div className="w-full flex flex-col gap-8 pb-16">
      
      {/* Header Banner */}
      <div className="flex flex-col gap-2 border-b-2 border-[#e8d3b9] pb-5">
        <div className="gold-badge">Official AI Advisory Portal</div>
        <h1 className="font-headline font-bold text-2xl sm:text-3xl lg:text-4xl text-[#1b1c1a] flex items-center gap-3">
          <span className="material-symbols-outlined text-[34px] text-[#561922]">smart_toy</span>
          <span>Talk to Nexus Venture</span>
        </h1>
        <p className="text-xs sm:text-sm text-[#534343]">
          Dedicated sovereign intelligence interface for technical due diligence, patent timestamping checks, and startup-investor matching.
        </p>
      </div>

      {/* Main Chatbot Staging Interface */}
      <div className="bg-white border-2 border-[#d4af37] rounded-3xl p-6 sm:p-10 shadow-md flex flex-col gap-6">
        
        {/* Portal Status Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#faf6f0] border border-[#e8d3b9]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#561922] text-[#d4af37] flex items-center justify-center border border-[#d4af37] shrink-0">
              <span className="material-symbols-outlined text-[22px]">hub</span>
            </div>
            <div>
              <span className="text-xs font-bold text-[#1b1c1a] block">AI Chatbot Integration Gateway</span>
              <span className="text-[11px] text-[#6b5c47]">Prepared for upcoming modular AI source code integration</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-[10px] font-bold bg-[#ffdadb] text-[#561922] border border-[#d4af37] uppercase tracking-wider">
              Ready for Chatbot Code
            </span>
          </div>
        </div>

        {/* Clean Staged Chat Workspace Container */}
        <div className="border-2 border-dashed border-[#b89358] rounded-2xl p-8 sm:p-12 flex flex-col items-center justify-center text-center gap-4 bg-[#fbf9f6] min-h-[380px]">
          <div className="w-16 h-16 rounded-full bg-[#561922] text-[#d4af37] border-2 border-[#d4af37] flex items-center justify-center shadow-md">
            <span className="material-symbols-outlined text-[32px]">forum</span>
          </div>

          <div className="max-w-md flex flex-col gap-2">
            <h3 className="font-headline font-bold text-xl text-[#1b1c1a]">
              Nexus Venture AI Chatbot Interface
            </h3>
            <p className="text-xs text-[#534343] leading-relaxed">
              This dedicated page is prepared to receive your custom AI chatbot source code. No simulated or fake APIs are attached. All navigation anchors and container structures are in place.
            </p>
          </div>

          {/* Quick Helpful Links */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={onNavigateExplore}
              className="btn-gold text-xs py-2.5 px-4 shadow-xs"
            >
              <span className="material-symbols-outlined text-[16px]">travel_explore</span>
              <span>Explore Projects Directory</span>
            </button>

            <button
              type="button"
              onClick={onOpenSubmit}
              className="btn-burgundy text-xs py-2.5 px-4 shadow-xs"
            >
              <span className="material-symbols-outlined text-[16px] text-[#d4af37]">rocket_launch</span>
              <span>Submit Startup Project</span>
            </button>
          </div>
        </div>

        {/* Technical Integration Specs Notice */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col gap-1">
            <span className="text-xs font-bold text-[#561922] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-[#d4af37]">aspect_ratio</span>
              <span>Full-Page Layout</span>
            </span>
            <span className="text-[11px] text-[#534343]">
              Non-floating, dedicated responsive view with zero screen obstruction.
            </span>
          </div>

          <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col gap-1">
            <span className="text-xs font-bold text-[#561922] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-[#d4af37]">palette</span>
              <span>Luxury Theme Harmony</span>
            </span>
            <span className="text-[11px] text-[#534343]">
              Pre-aligned with Burgundy & Champagne Gold design variables.
            </span>
          </div>

          <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col gap-1">
            <span className="text-xs font-bold text-[#561922] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-[#d4af37]">code_blocks</span>
              <span>Direct Hook Ready</span>
            </span>
            <span className="text-[11px] text-[#534343]">
              Ready for immediate drop-in replacement with your chatbot source code.
            </span>
          </div>
        </div>

      </div>

    </div>
  );
}

window.ChatbotPage = ChatbotPage;
