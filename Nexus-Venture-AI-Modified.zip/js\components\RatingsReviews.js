/**
 * NEXUS VENTURE AI - Ratings & Reviews Component
 * Requirements:
 * - Public viewing: Accessible to everyone without login.
 * - No public "Post Review" option displayed to general unauthenticated visitors.
 * - Who can review whom:
 *   A. Investors can rate and review startups/projects.
 *   B. Startup developers can rate and review investors.
 * - Eligibility checks: Only authenticated & eligible users can submit.
 *   Shows clean backend verification readiness notices.
 * - Entire rating card is clickable and navigates to the project in Explore Projects.
 * - Full decimal rating support (e.g. 4.3, 4.7, 3.8, 4.5).
 */

function RatingsReviews({ reviews = [], projects = [], onSelectProject, onAddReview, currentUser }) {
  const { useState, useMemo } = React;

  const [searchTerm, setSearchTerm] = useState('');
  const [showSubmitModal, setShowSubmitModal] = useState(false);

  // Review Form State
  const [targetType, setTargetType] = useState('project'); // 'project' | 'investor'
  const [selectedTargetId, setSelectedTargetId] = useState(projects[0] ? projects[0].id : '');
  const [reviewerName, setReviewerName] = useState(currentUser ? currentUser.name : '');
  const [reviewerOrg, setReviewerOrg] = useState(currentUser && currentUser.organization ? currentUser.organization : '');
  const [decimalRating, setDecimalRating] = useState('4.5');
  const [feedbackText, setFeedbackText] = useState('');
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState('');

  // Eligibility: User must be logged in as Investor or Startup Developer
  const isInvestor = Boolean(currentUser && currentUser.isLoggedIn && (currentUser.role === 'Investor' || currentUser.role === 'investor'));
  const isDeveloper = Boolean(currentUser && currentUser.isLoggedIn && (currentUser.role === 'Startup Developer' || currentUser.role === 'developer'));
  const canSubmitReviews = isInvestor || isDeveloper;

  // Star rendering helper supporting any decimal rating
  const renderStars = (rating) => {
    const stars = [];
    const num = typeof rating === 'number' ? rating : parseFloat(rating) || 4.5;
    const fullStars = Math.floor(num);
    const hasHalfStar = (num % 1) >= 0.25 && (num % 1) <= 0.75;

    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(
          <span key={i} className="material-symbols-outlined text-[16px] text-amber-500 fill-current">
            star
          </span>
        );
      } else if (i === fullStars + 1 && hasHalfStar) {
        stars.push(
          <span key={i} className="material-symbols-outlined text-[16px] text-amber-500 fill-current">
            star_half
          </span>
        );
      } else {
        stars.push(
          <span key={i} className="material-symbols-outlined text-[16px] text-gray-300">
            star
          </span>
        );
      }
    }
    return stars;
  };

  // Coordinated dynamic search across project, reviewer, comment, and sector
  const filteredReviews = useMemo(() => {
    if (!searchTerm.trim()) return reviews;
    const q = searchTerm.toLowerCase();

    return reviews.filter((rev) => {
      const matchProject = (rev.projectName || '').toLowerCase().includes(q);
      const matchSector = (rev.projectSector || '').toLowerCase().includes(q);
      const matchComment = (rev.comment || '').toLowerCase().includes(q);
      const matchReviewer = (rev.reviewerName || '').toLowerCase().includes(q);
      const matchRole = (rev.role || '').toLowerCase().includes(q);

      return matchProject || matchSector || matchComment || matchReviewer || matchRole;
    });
  }, [reviews, searchTerm]);

  const handleSubmitReview = (e) => {
    e.preventDefault();
    if (!reviewerName.trim() || !feedbackText.trim() || !selectedTargetId) {
      setSubmitError('Please complete all required review fields.');
      return;
    }

    const ratingNum = parseFloat(decimalRating);
    if (isNaN(ratingNum) || ratingNum < 1.0 || ratingNum > 5.0) {
      setSubmitError('Please enter a valid decimal rating between 1.0 and 5.0 (e.g. 4.3, 4.7).');
      return;
    }

    if (onAddReview) {
      onAddReview(selectedTargetId, {
        reviewerName: reviewerName.trim(),
        role: isInvestor ? 'Accredited Investor' : 'Startup Developer',
        rating: ratingNum,
        comment: feedbackText.trim(),
        date: new Date().toISOString().split('T')[0]
      });
    }

    setSubmitSuccess(true);
    setSubmitError('');
    setTimeout(() => {
      setSubmitSuccess(false);
      setShowSubmitModal(false);
      setFeedbackText('');
    }, 1800);
  };

  const handleCardClick = (projectId) => {
    const proj = projects.find((p) => p.id === projectId);
    if (proj && onSelectProject) {
      onSelectProject(proj);
    }
  };

  return (
    <div className="w-full flex flex-col gap-8 pb-16">
      
      {/* Header with Search Box on the Right Side */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-4 border-b-2 border-[#e8d3b9]">
        <div className="flex flex-col gap-1 max-w-xl">
          <div className="gold-badge mb-1">Audited Community Feedback</div>
          <h1 className="font-headline font-bold text-2xl sm:text-3xl lg:text-4xl text-[#1b1c1a]">
            Ratings & Reviews
          </h1>
          <p className="text-xs sm:text-sm text-[#534343] mt-0.5">
            Public directory of verified technical evaluations and due-diligence feedback.
          </p>
        </div>

        {/* Dynamic Project Search on the Right */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative min-w-[280px] sm:w-80">
            <span className="absolute left-3 top-2.5 text-[#b89358] material-symbols-outlined text-[20px]">
              search
            </span>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search reviews by project, keyword, or sector..."
              className="w-full pl-9 pr-8 py-2.5 bg-white border-2 border-[#e8d3b9] rounded-xl text-xs text-[#1b1c1a] focus:outline-none focus:border-[#561922] shadow-2xs"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-2.5 text-gray-400 hover:text-gray-600"
              >
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            )}
          </div>

          {/* Conditional Review Submission: Shown only to logged-in eligible reviewers */}
          {canSubmitReviews ? (
            <button
              type="button"
              onClick={() => {
                setShowSubmitModal(true);
                setTargetType(isInvestor ? 'project' : 'investor');
              }}
              className="btn-burgundy text-xs py-2.5 px-4 shrink-0 shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px] text-[#d4af37]">rate_review</span>
              <span>{isInvestor ? 'Rate a Startup' : 'Rate an Investor'}</span>
            </button>
          ) : (
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] text-[11px] text-[#6b5c47] font-semibold">
              <span className="material-symbols-outlined text-[16px] text-[#561922]">verified</span>
              <span>Audited Public View</span>
            </div>
          )}
        </div>
      </div>

      {/* Public Transparency Protocol Notice */}
      <div className="p-4 rounded-2xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-[#561922] font-semibold">
          <span className="material-symbols-outlined text-[#d4af37] text-[20px]">policy</span>
          <span>
            <strong>Two-Way Review Governance:</strong> Accredited Investors can rate & review startups; Startup Developers can rate & review investors.
          </span>
        </div>
        <span className="text-[11px] text-[#6b5c47]">
          Decimal ratings (e.g. 4.3, 4.7) supported & verified.
        </span>
      </div>

      {/* 3-Column Review Cards Grid (Each Card is Clickable to open Project Details) */}
      {filteredReviews.length === 0 ? (
        <div className="rounded-2xl border-2 border-dashed border-[#e8d3b9] p-12 text-center flex flex-col items-center gap-3 bg-white">
          <span className="material-symbols-outlined text-[#b89358] text-[36px]">reviews</span>
          <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">No reviews match your query</h3>
          <p className="text-xs text-[#534343]">
            Try adjusting your search keywords or clear your query to view all approved reviews.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredReviews.map((rev) => {
            return (
              <div
                key={rev.id || Math.random()}
                onClick={() => handleCardClick(rev.projectId)}
                className="bg-white border-2 border-[#e8d3b9] hover:border-[#d4af37] hover:shadow-lg rounded-2xl p-5 shadow-xs flex flex-col justify-between gap-4 transition-all duration-200 cursor-pointer select-none group"
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') handleCardClick(rev.projectId);
                }}
              >
                <div className="flex flex-col gap-3">
                  {/* Card Header: Star Rating & Review Date */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <div className="flex items-center">
                        {renderStars(rev.rating)}
                      </div>
                      <span className="text-xs font-extrabold text-[#1b1c1a]">
                        {parseFloat(rev.rating).toFixed(1)}
                      </span>
                    </div>

                    <span className="text-[11px] text-[#6b5c47] font-semibold">
                      {rev.date}
                    </span>
                  </div>

                  {/* Associated Project Tag */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-[#561922] truncate max-w-[200px] group-hover:text-[#3c0b12]" title={rev.projectName}>
                      Startup: {rev.projectName}
                    </span>
                    {rev.projectSector && (
                      <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-[#faf6f0] text-[#6b5c47] border border-[#e8d3b9]">
                        {rev.projectSector}
                      </span>
                    )}
                  </div>

                  {/* Written Review */}
                  <p className="text-xs sm:text-sm text-[#534343] leading-relaxed italic">
                    "{rev.comment}"
                  </p>
                </div>

                {/* Card Footer: Reviewer Info & Click Indicator */}
                <div className="pt-3 border-t border-[#e8d3b9] flex items-center justify-between gap-2">
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-bold text-[#1b1c1a] truncate">
                      {rev.reviewerName}
                    </span>
                    <span className="text-[10px] text-[#561922] font-semibold truncate">
                      {rev.role}
                    </span>
                  </div>

                  <span className="text-[11px] font-bold text-[#d4af37] group-hover:text-[#b89358] flex items-center gap-1">
                    <span>View Project</span>
                    <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Review Submission Modal Dialog (Only for authenticated eligible accounts) */}
      {showSubmitModal && (
        <div className="modal-overlay" onClick={() => setShowSubmitModal(false)}>
          <div className="modal-dialog max-w-lg" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header-burgundy">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#d4af37] text-[22px]">rate_review</span>
                <h3 className="font-headline font-bold text-lg text-white">
                  {isInvestor ? 'Rate & Review Startup' : 'Rate & Review Investor'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSubmitModal(false)}
                className="w-8 h-8 rounded-full bg-[#561922] text-white flex items-center justify-center border border-[#d4af37]"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <div className="p-6">
              {submitSuccess ? (
                <div className="p-5 bg-emerald-50 border-2 border-emerald-300 rounded-xl text-center flex flex-col items-center gap-2 text-emerald-950">
                  <span className="material-symbols-outlined text-emerald-600 text-[36px]">check_circle</span>
                  <span className="font-bold text-sm">Review Submitted Successfully</span>
                  <span className="text-xs text-emerald-800">
                    Your decimal rating and feedback have been audited and added to the community directory.
                  </span>
                </div>
              ) : (
                <form onSubmit={handleSubmitReview} className="flex flex-col gap-4 text-xs">
                  {submitError && (
                    <div className="p-2.5 bg-red-50 border border-red-300 text-red-700 rounded-xl font-semibold">
                      {submitError}
                    </div>
                  )}

                  {/* Review Target Selection */}
                  <div className="flex flex-col gap-1">
                    <label className="font-bold text-[#1b1c1a]">Select Startup to Review *</label>
                    <select
                      value={selectedTargetId}
                      onChange={(e) => setSelectedTargetId(e.target.value)}
                      className="p-2.5 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs font-semibold"
                    >
                      {projects.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({p.sector})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex flex-col gap-1">
                      <label className="font-bold text-[#1b1c1a]">Your Name *</label>
                      <input
                        type="text"
                        required
                        value={reviewerName}
                        onChange={(e) => setReviewerName(e.target.value)}
                        placeholder="Your Full Name"
                        className="p-2.5 bg-[#faf6f0] border rounded-xl"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="font-bold text-[#1b1c1a]">Organization / Firm</label>
                      <input
                        type="text"
                        value={reviewerOrg}
                        onChange={(e) => setReviewerOrg(e.target.value)}
                        placeholder="Investment Syndicate / Lab"
                        className="p-2.5 bg-[#faf6f0] border rounded-xl"
                      />
                    </div>
                  </div>

                  {/* Decimal Rating Support */}
                  <div className="flex flex-col gap-1">
                    <label className="font-bold text-[#1b1c1a]">
                      Decimal Rating Score (1.0 to 5.0, e.g. 4.3, 4.7, 3.8) *
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="number"
                        step="0.1"
                        min="1.0"
                        max="5.0"
                        required
                        value={decimalRating}
                        onChange={(e) => setDecimalRating(e.target.value)}
                        className="p-2.5 bg-[#faf6f0] border rounded-xl font-bold text-sm w-32"
                      />
                      <div className="flex items-center gap-1">
                        {renderStars(parseFloat(decimalRating) || 4.5)}
                        <span className="font-bold text-xs text-[#561922] ml-1">
                          {(parseFloat(decimalRating) || 4.5).toFixed(1)} / 5.0
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="font-bold text-[#1b1c1a]">Written Review & Feedback *</label>
                    <textarea
                      required
                      rows="4"
                      value={feedbackText}
                      onChange={(e) => setFeedbackText(e.target.value)}
                      placeholder="Detail the technical milestones, build cost feasibility, or due diligence comments..."
                      className="p-2.5 bg-[#faf6f0] border rounded-xl text-xs"
                    ></textarea>
                  </div>

                  <p className="text-[11px] text-[#6b5c47] italic">
                    Backend verification notice: Submitted reviews undergo cryptographic audit to verify authorized institutional representation.
                  </p>

                  <div className="flex items-center justify-end gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowSubmitModal(false)}
                      className="px-4 py-2 rounded-xl text-xs font-bold text-[#534343] bg-gray-100"
                    >
                      Cancel
                    </button>
                    <button type="submit" className="btn-gold text-xs py-2 px-5 shadow-xs">
                      Post Verified Review
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

window.RatingsReviews = RatingsReviews;
