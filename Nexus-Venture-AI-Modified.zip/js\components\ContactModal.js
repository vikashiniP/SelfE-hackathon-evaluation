/**
 * NEXUS VENTURE AI - Contact Modal Component
 * Enables secure communication between Founders and Investors without exposing
 * private phone numbers or personal emails without permission.
 */

function ContactModal({ recipient, currentUser, onClose }) {
  if (!recipient) return null;

  const { useState } = React;

  const [senderName, setSenderName] = useState(currentUser ? currentUser.name : '');
  const [senderEmail, setSenderEmail] = useState(currentUser ? currentUser.email : '');
  const [subject, setSubject] = useState(
    recipient.sector
      ? `Investment Inquiry regarding ${recipient.name}`
      : `Syndicate Inquiry to ${recipient.name}`
  );
  const [message, setMessage] = useState('');
  const [sentSuccess, setSentSuccess] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!senderName.trim() || !senderEmail.trim() || !message.trim()) return;

    setSentSuccess(true);
    setTimeout(() => {
      setSentSuccess(false);
      onClose();
    }, 2000);
  };

  const recipientLabel = recipient.developer
    ? `Founder: ${recipient.developer.name} (${recipient.name})`
    : `Investor: ${recipient.name} (${recipient.company || 'Venture Syndicate'})`;

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-dialog max-w-lg" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header-burgundy">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#d4af37] text-[22px]">mail</span>
            <h3 className="font-headline font-bold text-lg text-white">
              Connect Securely
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#561922] text-white flex items-center justify-center border border-[#d4af37]"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        <div className="p-6">
          {sentSuccess ? (
            <div className="p-5 bg-emerald-50 border-2 border-emerald-300 rounded-xl text-center flex flex-col items-center gap-2 text-emerald-950">
              <span className="material-symbols-outlined text-emerald-600 text-[36px]">mark_email_read</span>
              <span className="font-bold text-sm">Inquiry Dispatched!</span>
              <span className="text-xs text-emerald-800">
                Your cryptographic contact request has been routed. The recipient will be notified securely on <strong>NEXUS VENTURE AI</strong>.
              </span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-xs">
              <div className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl flex items-center gap-2">
                <span className="material-symbols-outlined text-[#561922]">person</span>
                <span className="text-xs font-bold text-[#1b1c1a]">Recipient: {recipientLabel}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex flex-col gap-1">
                  <label className="font-bold text-[#1b1c1a]">Your Name *</label>
                  <input
                    type="text"
                    required
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    placeholder="Your Name"
                    className="p-2.5 bg-[#faf6f0] border rounded-xl"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="font-bold text-[#1b1c1a]">Your Email Address *</label>
                  <input
                    type="email"
                    required
                    value={senderEmail}
                    onChange={(e) => setSenderEmail(e.target.value)}
                    placeholder="your.email@domain.com"
                    className="p-2.5 bg-[#faf6f0] border rounded-xl"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-bold text-[#1b1c1a]">Subject Line</label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="p-2.5 bg-[#faf6f0] border rounded-xl font-semibold"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-bold text-[#1b1c1a]">Message / Proposed Collaboration *</label>
                <textarea
                  required
                  rows="4"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Introduce yourself, specify tranche allocations or due diligence questions..."
                  className="p-2.5 bg-[#faf6f0] border rounded-xl text-xs"
                ></textarea>
              </div>

              <p className="text-[11px] text-[#6b5c47] italic">
                Nexus Venture AI protects founder and investor confidentiality. Contact data is shared upon mutual handshake acceptance.
              </p>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-[#534343]"
                >
                  Cancel
                </button>
                <button type="submit" className="btn-gold text-xs py-2 px-5">
                  Send Secure Inquiry
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

window.ContactModal = ContactModal;

