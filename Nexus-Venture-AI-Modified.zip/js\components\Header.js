/**
 * NEXUS VENTURE AI - Top Header Component
 * Contains:
 * - Prominent stylish website branding: NEXUS VENTURE AI
 * - Tagline: "Where Innovation Meets Investment."
 * - Two frontend buttons in top right: "Login" and "Create Account"
 *   (Champagne-gold and burgundy theme, consistent sizing & spacing)
 */

function Header({ onLoginClick, onCreateAccountClick, onToggleMobileSidebar }) {
  return (
    <header className="top-header">
      {/* Left: Mobile Toggle & Brand */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onToggleMobileSidebar}
          className="mobile-menu-trigger p-2 rounded-xl border-2 border-[#e8d3b9] bg-[#faf6f0] text-[#561922] lg:hidden hover:bg-white"
          aria-label="Toggle Navigation Menu"
        >
          <span className="material-symbols-outlined text-[22px]">menu</span>
        </button>

        <div className="header-brand">
          <div className="header-title flex items-center gap-2">
            <span className="text-[#561922] font-black tracking-tight">NEXUS VENTURE AI</span>
            <span className="hidden md:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#f7e7ce] text-[#561922] border border-[#d4af37] text-[10px] font-bold tracking-wider uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-ping"></span>
              Live Escrow Network
            </span>
          </div>
          <span className="header-tagline">
            Where Innovation Meets Investment.
          </span>
        </div>
      </div>

      {/* Center: Startup Tech Badges / Metrics (Desktop) */}
      <div className="hidden xl:flex items-center gap-6">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#faf6f0] border border-[#e8d3b9]">
          <span className="material-symbols-outlined text-[18px] text-[#561922]">verified</span>
          <div className="text-[11px] leading-tight">
            <span className="font-bold text-[#1b1c1a]">Patent Priority Vault</span>
            <span className="block text-[#6b5c47]">WIPO & IPO Timestamps</span>
          </div>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#faf6f0] border border-[#e8d3b9]">
          <span className="material-symbols-outlined text-[18px] text-[#d4af37]">account_balance_wallet</span>
          <div className="text-[11px] leading-tight">
            <span className="font-bold text-[#1b1c1a]">₹ Escrow Safeguard</span>
            <span className="block text-[#6b5c47]">Milestone Verification</span>
          </div>
        </div>
      </div>

      {/* Right: Frontend Action Buttons (Login & Create Account) */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onLoginClick}
          className="min-w-[110px] py-2.5 px-4 rounded-xl font-bold text-xs bg-[#561922] text-[#f7e7ce] border-2 border-[#d4af37] hover:bg-[#3c0b12] hover:text-[#ffffff] transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[16px] text-[#d4af37]">login</span>
          <span>Login</span>
        </button>

        <button
          type="button"
          onClick={onCreateAccountClick}
          className="min-w-[130px] py-2.5 px-4 rounded-xl font-bold text-xs bg-[#d4af37] text-[#561922] border-2 border-[#b89358] hover:bg-[#e5c158] hover:border-[#d4af37] transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[16px] text-[#561922]">person_add</span>
          <span>Create Account</span>
        </button>
      </div>
    </header>
  );
}

window.Header = Header;
