/**
 * NEXUS VENTURE AI - Network Illustration Component
 * Visualizes the sovereign deeptech innovation ecosystem:
 * Founders (DeepTech), Institutional Investors (Syndicates), Smart Escrow & Public Nodes.
 * Responds interactively to activeAccountType ('startup' | 'investor' | 'public').
 */

function NetworkIllustration({ activeAccountType = 'startup' }) {
  const isStartup = activeAccountType === 'startup';
  const isInvestor = activeAccountType === 'investor';
  const isPublic = activeAccountType === 'public';

  return (
    <div className="w-full bg-[#3c0b12] border-2 border-[#b89358] rounded-3xl p-5 shadow-lg flex flex-col gap-4 text-white relative overflow-hidden">
      {/* Background Subtle Luxury Watermark */}
      <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-[#722f37]/30 blur-2xl pointer-events-none"></div>
      <div className="absolute -left-12 -bottom-12 w-48 h-48 rounded-full bg-[#d4af37]/20 blur-2xl pointer-events-none"></div>

      {/* Header bar */}
      <div className="flex items-center justify-between relative z-10 border-b border-[#e8d3b9]/20 pb-3">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-[#d4af37] animate-pulse"></span>
          <span className="text-xs font-bold uppercase tracking-wider text-[#f7e7ce]">
            Sovereign Innovation Ledger
          </span>
        </div>
        <span className="text-[11px] font-semibold text-[#e8d3b9] px-2.5 py-0.5 rounded-full bg-[#561922] border border-[#b89358]/40">
          Live Ecosystem Mesh
        </span>
      </div>

      {/* Interactive SVG Diagram */}
      <div className="relative w-full h-56 sm:h-64 flex items-center justify-center">
        <svg viewBox="0 0 500 300" className="w-full h-full">
          {/* Connector Lines between nodes */}
          <line x1="120" y1="80" x2="250" y2="150" stroke="#d4af37" strokeWidth={isStartup ? '3' : '1.5'} strokeDasharray={isStartup ? 'none' : '4,4'} strokeOpacity="0.8" />
          <line x1="380" y1="80" x2="250" y2="150" stroke="#e5c158" strokeWidth={isInvestor ? '3' : '1.5'} strokeDasharray={isInvestor ? 'none' : '4,4'} strokeOpacity="0.8" />
          <line x1="250" y1="240" x2="250" y2="150" stroke="#f7e7ce" strokeWidth={isPublic ? '3' : '1.5'} strokeDasharray={isPublic ? 'none' : '4,4'} strokeOpacity="0.8" />
          <line x1="120" y1="80" x2="380" y2="80" stroke="#b89358" strokeWidth="1" strokeDasharray="3,3" strokeOpacity="0.5" />

          {/* Central Smart Escrow Hub */}
          <g transform="translate(250, 150)">
            <circle r="36" fill="#561922" stroke="#d4af37" strokeWidth="3" />
            <circle r="42" fill="none" stroke="#e5c158" strokeWidth="1" strokeDasharray="2,3" className="animate-spin" style={{ animationDuration: '20s' }} />
            <text textAnchor="middle" y="-6" fill="#f7e7ce" fontSize="9" fontWeight="bold">SMART ESCROW</text>
            <text textAnchor="middle" y="8" fill="#d4af37" fontSize="8">LEDGER</text>
            <text textAnchor="middle" y="20" fill="#ffffff" fontSize="7" opacity="0.8">₹ Milestone Gated</text>
          </g>

          {/* Node 1: Startup & Founders (Left) */}
          <g transform="translate(120, 80)" className="cursor-pointer">
            <circle r={isStartup ? '34' : '28'} fill={isStartup ? '#722f37' : '#561922'} stroke={isStartup ? '#ffffff' : '#d4af37'} strokeWidth={isStartup ? '3' : '1.5'} />
            {isStartup && <circle r="40" fill="none" stroke="#d4af37" strokeWidth="2" strokeDasharray="3,3" />}
            <text textAnchor="middle" y="-4" fill="#ffffff" fontSize="9" fontWeight="bold">DEEPTECH</text>
            <text textAnchor="middle" y="8" fill="#f7e7ce" fontSize="8">FOUNDERS</text>
            <text textAnchor="middle" y="19" fill="#d4af37" fontSize="7">BOM & Patents</text>
          </g>

          {/* Node 2: Institutional Investors (Right) */}
          <g transform="translate(380, 80)" className="cursor-pointer">
            <circle r={isInvestor ? '34' : '28'} fill={isInvestor ? '#722f37' : '#561922'} stroke={isInvestor ? '#ffffff' : '#d4af37'} strokeWidth={isInvestor ? '3' : '1.5'} />
            {isInvestor && <circle r="40" fill="none" stroke="#e5c158" strokeWidth="2" strokeDasharray="3,3" />}
            <text textAnchor="middle" y="-4" fill="#ffffff" fontSize="9" fontWeight="bold">ACCREDITED</text>
            <text textAnchor="middle" y="8" fill="#f7e7ce" fontSize="8">INVESTORS</text>
            <text textAnchor="middle" y="19" fill="#d4af37" fontSize="7">Syndicate LPs</text>
          </g>

          {/* Node 3: Public & Researchers (Bottom) */}
          <g transform="translate(250, 240)" className="cursor-pointer">
            <circle r={isPublic ? '32' : '26'} fill={isPublic ? '#722f37' : '#561922'} stroke={isPublic ? '#ffffff' : '#d4af37'} strokeWidth={isPublic ? '3' : '1.5'} />
            {isPublic && <circle r="38" fill="none" stroke="#f7e7ce" strokeWidth="2" strokeDasharray="3,3" />}
            <text textAnchor="middle" y="-3" fill="#ffffff" fontSize="9" fontWeight="bold">COMMUNITY</text>
            <text textAnchor="middle" y="9" fill="#f7e7ce" fontSize="8">& ACADEMIA</text>
            <text textAnchor="middle" y="19" fill="#d4af37" fontSize="7">Peer Audits</text>
          </g>
        </svg>

        {/* Live Active Status Badge */}
        <div className="absolute bottom-2 left-2 px-3 py-1 bg-[#2b060d]/80 border border-[#d4af37] rounded-lg text-[10px] text-[#f7e7ce] flex items-center gap-1.5 backdrop-blur-xs">
          <span className="material-symbols-outlined text-[13px] text-[#d4af37]">hub</span>
          <span>Role Focus: <strong>{isStartup ? 'Startup Founders' : isInvestor ? 'Accredited Investors' : 'Public Researchers'}</strong></span>
        </div>
      </div>

      {/* Description caption */}
      <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#e8d3b9]/20 text-[10px] text-[#f7e7ce] text-center">
        <div className={`p-1.5 rounded-lg border ${isStartup ? 'bg-[#722f37] border-[#d4af37]' : 'bg-[#561922]/50 border-transparent'}`}>
          <div className="font-bold text-white">Startup R&D</div>
          <div className="text-[9px] text-[#e8d3b9]">Patents & BOM</div>
        </div>
        <div className={`p-1.5 rounded-lg border ${isInvestor ? 'bg-[#722f37] border-[#d4af37]' : 'bg-[#561922]/50 border-transparent'}`}>
          <div className="font-bold text-white">Investor Syndicate</div>
          <div className="text-[9px] text-[#e8d3b9]">Escrow Safety</div>
        </div>
        <div className={`p-1.5 rounded-lg border ${isPublic ? 'bg-[#722f37] border-[#d4af37]' : 'bg-[#561922]/50 border-transparent'}`}>
          <div className="font-bold text-white">Public Ecosystem</div>
          <div className="text-[9px] text-[#e8d3b9]">Ideas & Reviews</div>
        </div>
      </div>
    </div>
  );
}

window.NetworkIllustration = NetworkIllustration;

