/**
 * NEXUS VENTURE AI - Submit Project Dedicated Page Component
 * Full-page navigation view (activeTab === 'submit')
 * Complete implementation of:
 * - Section 1: Project Name & Description (preserved)
 * - Section 2: Project Images with (+) file upload & URL input
 * - Section 3: Project Video (YouTube & video links supported, description optional)
 * - Section 4: Technical Details & Parts List (preserved)
 * - Section 5: Cost & Funding (₹ formatting)
 * - Section 6: Patent Document Upload (conditional on 4 patent statuses)
 * - Section 7: Developer Information
 * - Section 8: Mandatory Originality Declaration Checkbox
 * - Bottom Right: Equal-dimension Submit, Reset, and Cancel buttons (champagne gold & burgundy)
 */

function SubmitProjectPage({ onProjectSubmitted, onCancel, currentUser }) {
  const { useState, useRef } = React;

  const initialFormState = {
    // Section 1
    title: '',
    sector: 'Technology',
    stage: 'MVP / Early Product',
    summary: '',
    description: '',
    benefitsText: '',

    // Section 2: Images
    representativeImageUrl: '',
    prototypeImageUrl: '',
    representativeImageFile: null,
    representativeImagePreview: null,
    prototypeImageFile: null,
    prototypeImagePreview: null,

    // Section 3: Video
    videoUrl: '',
    videoDescription: '',

    // Section 4: Tech specs
    languagesText: 'Python, C++',
    frameworksText: 'PyTorch, FastAPI, React',
    frontend: 'React Web Application, Tailwind CSS',
    backend: 'FastAPI, PostgreSQL, Docker',
    hardwarePartsText: 'ESP32-S3, Custom 4-Layer PCB, High-Precision Sensors',

    // Section 5: Cost & Funding
    buildCost: '₹ 1,50,000',
    targetFunding: '₹ 25,00,000',
    costExplanation: 'Prototyping sensor calibration, custom PCB fabrication, and firmware development.',
    costBreakdown: 'Sensors: ₹60,000 | Fabrication: ₹40,000 | Testing: ₹30,000 | QA: ₹20,000',

    // Section 6: Patent Status & Uploads
    patentStatus: 'Patent Applied',
    patentNumber: '',
    grantDate: '',
    applicationNumber: '',
    publicationNumber: '',
    filingDate: '',
    patentDescription: '',
    patentGrantedDoc: null,
    patentAppDoc: null,
    patentAppProofDoc: null,
    patentPubDoc: null,
    patentPubProofDoc: null,

    // Section 7: Developer info
    devName: currentUser ? currentUser.name : '',
    devEmail: currentUser ? currentUser.email : '',
    devPhone: '+91 98450 11223',
    institution: currentUser && currentUser.organization ? currentUser.organization : 'IIT Madras Research Park',
    background: 'DeepTech hardware innovator specializing in autonomous embedded systems.',
    team: '3 Core Engineers (Hardware, Embedded Firmware, Backend)',

    // Section 8: Declaration
    declaration: false
  };

  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  // File input refs for visible (+) uploads
  const repImageInputRef = useRef(null);
  const protoImageInputRef = useRef(null);
  const patentGrantedRef = useRef(null);
  const patentAppDocRef = useRef(null);
  const patentAppProofRef = useRef(null);
  const patentPubDocRef = useRef(null);
  const patentPubProofRef = useRef(null);

  const sectors = ['Agriculture', 'Environment', 'Healthcare', 'Education', 'Technology', 'Business'];
  const stages = [
    'Idea / Concept',
    'MVP / Early Product',
    'Full Project Ready',
    'Field Tested with Users'
  ];
  const patentOptions = [
    { id: 'No Patent', label: 'No Patent' },
    { id: 'Patent Applied', label: 'Patent Applied' },
    { id: 'Published Patent', label: 'Published Patent' },
    { id: 'Patent Granted', label: 'Patent Granted' }
  ];

  // Reliable input change handler
  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  // Live Image Upload Handler with validation
  const handleImageFileChange = (field, previewField, file) => {
    if (!file) return;

    // Basic file validation
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!validTypes.includes(file.type)) {
      alert('Please select a valid image file (JPEG, PNG, WebP, or GIF).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('Image file size must be less than 5 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      setFormData((prev) => ({
        ...prev,
        [field]: file,
        [previewField]: e.target.result
      }));
    };
    reader.readAsDataURL(file);
  };

  // Patent document file upload handler with validation
  const handleDocFileChange = (field, file) => {
    if (!file) return;

    const validTypes = ['application/pdf', 'image/jpeg', 'image/png', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!validTypes.includes(file.type) && !file.name.match(/\.(pdf|jpg|jpeg|png|doc|docx)$/i)) {
      alert('Please upload a valid document format (PDF, PNG, JPEG, or DOC/DOCX).');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      alert('Document size must be less than 15 MB.');
      return;
    }

    setFormData((prev) => ({ ...prev, [field]: file }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  // Form validation
  const validateForm = () => {
    const errs = {};

    // Section 1
    if (!formData.title.trim()) errs.title = 'Project Title is required.';
    if (!formData.summary.trim()) errs.summary = 'One-Sentence Summary is required.';
    if (!formData.description.trim()) errs.description = 'Full Description is required.';

    // Section 3: Video URL
    if (formData.videoUrl.trim()) {
      const urlPattern = /^(http|https):\/\/[^ "]+$/;
      if (!urlPattern.test(formData.videoUrl.trim())) {
        errs.videoUrl = 'Please enter a valid video link (e.g. YouTube or video host URL).';
      }
    }

    // Section 5
    if (!formData.buildCost.trim()) errs.buildCost = 'Build cost in ₹ is required.';
    if (!formData.targetFunding.trim()) errs.targetFunding = 'Target funding in ₹ is required.';

    // Section 6: Patent Document Validation
    if (formData.patentStatus === 'Patent Applied') {
      if (!formData.patentAppDoc) {
        errs.patentAppDoc = 'Original Patent Application document is required.';
      }
      if (!formData.patentAppProofDoc) {
        errs.patentAppProofDoc = 'Supporting Application Proof document is required.';
      }
    } else if (formData.patentStatus === 'Published Patent') {
      if (!formData.patentPubDoc) {
        errs.patentPubDoc = 'Original Published Patent document is required.';
      }
      if (!formData.patentPubProofDoc) {
        errs.patentPubProofDoc = 'Relevant Supporting Proof is required.';
      }
    } else if (formData.patentStatus === 'Patent Granted') {
      if (!formData.patentGrantedDoc) {
        errs.patentGrantedDoc = 'Original Granted Patent document is required.';
      }
    }

    // Section 7
    if (!formData.devName.trim()) errs.devName = 'Developer Name is required.';
    if (!formData.devEmail.trim()) errs.devEmail = 'Developer Email is required.';

    // Section 8: Declaration
    if (!formData.declaration) {
      errs.declaration = 'You must confirm the originality and authorization declaration before submitting.';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) {
      window.scrollTo({ top: 400, behavior: 'smooth' });
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const newProject = {
        id: `proj-${Date.now()}`,
        name: formData.title.trim(),
        sector: formData.sector,
        stage: formData.stage,
        summary: formData.summary.trim(),
        fullDescription: formData.description.trim(),
        benefits: formData.benefitsText
          ? formData.benefitsText.split('\n').map((b) => b.trim()).filter(Boolean)
          : ['Demonstrated laboratory working model', 'Sovereign milestone escrow gating', 'Milestone verifiable BOM cost'],
        image: formData.representativeImagePreview || formData.representativeImageUrl || 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80',
        prototypeImage: formData.prototypeImagePreview || formData.prototypeImageUrl || 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80',
        videoUrl: formData.videoUrl.trim() || 'https://www.youtube.com/embed/ScMzIvxBSi4',
        videoDescription: formData.videoDescription.trim() || 'Working prototype demonstration.',
        languages: formData.languagesText.split(',').map((l) => l.trim()).filter(Boolean),
        frameworks: formData.frameworksText.split(',').map((f) => f.trim()).filter(Boolean),
        frontend: formData.frontend.trim(),
        backend: formData.backend.trim(),
        hardwareParts: formData.hardwarePartsText.split(',').map((p) => p.trim()).filter(Boolean),
        buildCost: formData.buildCost.trim(),
        targetFunding: formData.targetFunding.trim(),
        costExplanation: formData.costExplanation.trim(),
        costBreakdown: formData.costBreakdown.trim(),
        patentStatus: formData.patentStatus,
        patentDetails: {
          patentNumber: formData.patentNumber || 'PENDING-AUDIT',
          grantDate: formData.grantDate || '',
          description: formData.patentDescription || 'Patent documents submitted for backend IP verification.'
        },
        developer: {
          name: formData.devName.trim(),
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
          role: 'Startup Developer',
          institution: formData.institution.trim() || 'Independent Tech Founder',
          background: formData.background.trim(),
          email: formData.devEmail.trim(),
          phone: formData.devPhone.trim(),
          team: formData.team.trim()
        },
        rating: 5.0,
        reviewsCount: 1,
        reviews: []
      };

      if (window.NexusDB) {
        window.NexusDB.addProject(newProject);
      }

      setIsSubmitting(false);
      setSubmittedSuccess(true);

      setTimeout(() => {
        if (onProjectSubmitted) {
          onProjectSubmitted(newProject);
        }
      }, 1600);
    }, 1200);
  };

  // Reset Handler
  const handleReset = () => {
    const confirmReset = window.confirm('Are you sure you want to clear all entered details in the form?');
    if (confirmReset) {
      setFormData(initialFormState);
      setErrors({});
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="w-full flex flex-col gap-8 pb-16">
      
      {/* Page Title & Intro Banner */}
      <div className="flex flex-col gap-2 border-b-2 border-[#e8d3b9] pb-4">
        <div className="gold-badge">Developer Portal – Dedicated Submission Page</div>
        <h1 className="font-headline font-bold text-2xl sm:text-3xl lg:text-4xl text-[#1b1c1a]">
          Submit Your Startup Project
        </h1>
        <p className="text-xs sm:text-sm text-[#534343]">
          Fill in your project specifications, upload live prototype photos and patent documentation. Your project will be displayed on NEXUS VENTURE AI for accredited investors.
        </p>
      </div>

      {submittedSuccess ? (
        <div className="p-10 text-center flex flex-col items-center gap-4 bg-emerald-50 border-2 border-emerald-400 rounded-3xl shadow-sm">
          <span className="material-symbols-outlined text-emerald-600 text-[54px]">check_circle</span>
          <h2 className="font-headline font-bold text-2xl sm:text-3xl text-emerald-950">
            Startup Successfully Submitted!
          </h2>
          <p className="text-xs sm:text-sm text-emerald-800 max-w-lg leading-relaxed">
            Your project, working model specifications, and patent documentation have been registered in the <strong>NEXUS VENTURE AI</strong> system. Redirecting you to the Explore Projects directory...
          </p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} noValidate className="bg-white border-2 border-[#e8d3b9] rounded-3xl p-6 sm:p-10 shadow-sm flex flex-col gap-10">
          
          {/* ==================== SECTION 1: PROJECT NAME & DESCRIPTION ==================== */}
          <section className="flex flex-col gap-4 pb-8 border-b-2 border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[24px] text-[#d4af37]">assignment</span>
              <h3 className="font-headline font-bold text-base sm:text-lg uppercase tracking-wider text-[#561922]">
                Section 1 – Project Name & Description
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div className="sm:col-span-3 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Project Title *</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  placeholder="e.g. BioVolt Microbial Fuel Cell Generator"
                  className={`p-3 bg-[#faf6f0] border rounded-xl text-xs sm:text-sm ${errors.title ? 'border-red-500 bg-red-50' : 'border-[#e8d3b9]'}`}
                />
                {errors.title && <span className="text-[11px] text-red-600 font-bold">{errors.title}</span>}
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Sector *</label>
                <select
                  value={formData.sector}
                  onChange={(e) => handleInputChange('sector', e.target.value)}
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs font-semibold"
                >
                  {sectors.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>

              <div className="sm:col-span-2 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Current Development Stage *</label>
                <select
                  value={formData.stage}
                  onChange={(e) => handleInputChange('stage', e.target.value)}
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs font-semibold"
                >
                  {stages.map((st) => <option key={st} value={st}>{st}</option>)}
                </select>
              </div>

              <div className="sm:col-span-3 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">One-Sentence Summary *</label>
                <input
                  type="text"
                  required
                  value={formData.summary}
                  onChange={(e) => handleInputChange('summary', e.target.value)}
                  placeholder="Concise 1-line value proposition for angel & venture investors..."
                  className={`p-3 bg-[#faf6f0] border rounded-xl text-xs ${errors.summary ? 'border-red-500' : 'border-[#e8d3b9]'}`}
                />
                {errors.summary && <span className="text-[11px] text-red-600 font-bold">{errors.summary}</span>}
              </div>

              <div className="sm:col-span-3 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Full Description (in simple words) *</label>
                <textarea
                  required
                  rows="4"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="Explain what the product is, what exact real-world problem it solves, and how it works..."
                  className={`p-3 bg-[#faf6f0] border rounded-xl text-xs ${errors.description ? 'border-red-500' : 'border-[#e8d3b9]'}`}
                ></textarea>
                {errors.description && <span className="text-[11px] text-red-600 font-bold">{errors.description}</span>}
              </div>

              <div className="sm:col-span-3 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Key Benefits for Users (one benefit per line)</label>
                <textarea
                  rows="3"
                  value={formData.benefitsText}
                  onChange={(e) => handleInputChange('benefitsText', e.target.value)}
                  placeholder="Benefit 1: Reduces operational energy cost by 50%&#10;Benefit 2: Operates 100% offline in rural clinics&#10;Benefit 3: Low cost replacement cartridges"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                ></textarea>
              </div>
            </div>
          </section>

          {/* ==================== SECTION 2: LIVE IMAGE UPLOAD & URLS ==================== */}
          <section className="flex flex-col gap-4 pb-8 border-b-2 border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[24px] text-[#d4af37]">photo_library</span>
              <h3 className="font-headline font-bold text-base sm:text-lg uppercase tracking-wider text-[#561922]">
                Section 2 – Project Images & Live Uploads
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              {/* Representative Image Box */}
              <div className="p-4 rounded-2xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col gap-3">
                <span className="text-xs font-bold text-[#1b1c1a]">1. Representative Project Image</span>
                
                {/* Upload Button with Visible (+) */}
                <input
                  type="file"
                  ref={repImageInputRef}
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handleImageFileChange('representativeImageFile', 'representativeImagePreview', e.target.files[0])}
                />
                
                <button
                  type="button"
                  onClick={() => repImageInputRef.current && repImageInputRef.current.click()}
                  className="w-full py-3 px-4 rounded-xl border-2 border-dashed border-[#b89358] bg-white hover:bg-[#f7e7ce]/40 transition-all text-xs font-bold text-[#561922] flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px] text-[#d4af37]">add_photo_alternate</span>
                  <span>+ Select Image from Computer</span>
                </button>

                {formData.representativeImagePreview && (
                  <div className="relative h-36 w-full rounded-xl overflow-hidden border-2 border-[#d4af37] bg-black">
                    <img src={formData.representativeImagePreview} alt="Representative Preview" className="w-full h-full object-cover" />
                    <span className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold bg-[#561922] text-[#f7e7ce]">Selected Local File</span>
                  </div>
                )}

                <div className="flex flex-col gap-1 mt-1">
                  <label className="text-[11px] font-semibold text-[#6b5c47]">Or Enter Image Link (URL):</label>
                  <input
                    type="url"
                    value={formData.representativeImageUrl}
                    onChange={(e) => handleInputChange('representativeImageUrl', e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="p-2.5 bg-white border border-[#e8d3b9] rounded-xl text-xs"
                  />
                </div>
              </div>

              {/* Prototype Image Box */}
              <div className="p-4 rounded-2xl bg-[#faf6f0] border border-[#e8d3b9] flex flex-col gap-3">
                <span className="text-xs font-bold text-[#1b1c1a]">2. Hardware / Prototype Photo</span>

                <input
                  type="file"
                  ref={protoImageInputRef}
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handleImageFileChange('prototypeImageFile', 'prototypeImagePreview', e.target.files[0])}
                />

                <button
                  type="button"
                  onClick={() => protoImageInputRef.current && protoImageInputRef.current.click()}
                  className="w-full py-3 px-4 rounded-xl border-2 border-dashed border-[#b89358] bg-white hover:bg-[#f7e7ce]/40 transition-all text-xs font-bold text-[#561922] flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px] text-[#d4af37]">add_photo_alternate</span>
                  <span>+ Select Prototype Photo</span>
                </button>

                {formData.prototypeImagePreview && (
                  <div className="relative h-36 w-full rounded-xl overflow-hidden border-2 border-[#d4af37] bg-black">
                    <img src={formData.prototypeImagePreview} alt="Prototype Preview" className="w-full h-full object-cover" />
                    <span className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold bg-[#561922] text-[#f7e7ce]">Selected Local File</span>
                  </div>
                )}

                <div className="flex flex-col gap-1 mt-1">
                  <label className="text-[11px] font-semibold text-[#6b5c47]">Or Enter Prototype Photo Link (URL):</label>
                  <input
                    type="url"
                    value={formData.prototypeImageUrl}
                    onChange={(e) => handleInputChange('prototypeImageUrl', e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="p-2.5 bg-white border border-[#e8d3b9] rounded-xl text-xs"
                  />
                </div>
              </div>

            </div>
          </section>

          {/* ==================== SECTION 3: WORKING MODEL VIDEO ==================== */}
          <section className="flex flex-col gap-4 pb-8 border-b-2 border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[24px] text-[#d4af37]">smart_display</span>
              <h3 className="font-headline font-bold text-base sm:text-lg uppercase tracking-wider text-[#561922]">
                Section 3 – Working Model Video
              </h3>
            </div>

            <p className="text-xs text-[#534343]">
              Provide a direct link to the actual demonstration video of your project (YouTube, Vimeo, or direct video URL). The video must relate specifically to the submitted project.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Project Demonstration Video URL</label>
                <input
                  type="url"
                  value={formData.videoUrl}
                  onChange={(e) => handleInputChange('videoUrl', e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=... or other supported video link"
                  className={`p-3 bg-[#faf6f0] border rounded-xl text-xs ${errors.videoUrl ? 'border-red-500' : 'border-[#e8d3b9]'}`}
                />
                {errors.videoUrl && <span className="text-[11px] text-red-600 font-bold">{errors.videoUrl}</span>}
              </div>

              <div className="sm:col-span-2 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Video Description (Optional)</label>
                <input
                  type="text"
                  value={formData.videoDescription}
                  onChange={(e) => handleInputChange('videoDescription', e.target.value)}
                  placeholder="Optional brief note on what investors will observe during the demo..."
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>
            </div>
          </section>

          {/* ==================== SECTION 4: TECHNICAL DETAILS & PARTS LIST ==================== */}
          <section className="flex flex-col gap-4 pb-8 border-b-2 border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[24px] text-[#d4af37]">memory</span>
              <h3 className="font-headline font-bold text-base sm:text-lg uppercase tracking-wider text-[#561922]">
                Section 4 – Technical Details & Parts List
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Programming Languages (comma-separated)</label>
                <input
                  type="text"
                  value={formData.languagesText}
                  onChange={(e) => handleInputChange('languagesText', e.target.value)}
                  placeholder="C, Python, C++, Verilog"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Software & Frameworks (comma-separated)</label>
                <input
                  type="text"
                  value={formData.frameworksText}
                  onChange={(e) => handleInputChange('frameworksText', e.target.value)}
                  placeholder="ROS2, TensorFlow Lite, FastAPI, Docker"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Frontend Technologies</label>
                <input
                  type="text"
                  value={formData.frontend}
                  onChange={(e) => handleInputChange('frontend', e.target.value)}
                  placeholder="React, Tailwind CSS, Leaflet GIS"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Backend Technologies</label>
                <input
                  type="text"
                  value={formData.backend}
                  onChange={(e) => handleInputChange('backend', e.target.value)}
                  placeholder="FastAPI, PostgreSQL, MQTT Broker"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>

              <div className="sm:col-span-2 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Hardware Parts List (Sensors, MCUs, Circuits)</label>
                <textarea
                  rows="2"
                  value={formData.hardwarePartsText}
                  onChange={(e) => handleInputChange('hardwarePartsText', e.target.value)}
                  placeholder="STM32WB55, ADS1298 Front-End, Monocrystalline Solar Cell, 3-Axis Gyroscope"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                ></textarea>
              </div>
            </div>
          </section>

          {/* ==================== SECTION 5: COST & FUNDING ==================== */}
          <section className="flex flex-col gap-4 pb-8 border-b-2 border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[24px] text-[#d4af37]">currency_rupee</span>
              <h3 className="font-headline font-bold text-base sm:text-lg uppercase tracking-wider text-[#561922]">
                Section 5 – Project Cost & Funding (in Indian Rupees ₹)
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Total Project Build Cost (₹) *</label>
                <input
                  type="text"
                  required
                  value={formData.buildCost}
                  onChange={(e) => handleInputChange('buildCost', e.target.value)}
                  placeholder="₹ 1,85,000"
                  className={`p-3 bg-[#faf6f0] border rounded-xl text-xs font-bold ${errors.buildCost ? 'border-red-500' : 'border-[#e8d3b9]'}`}
                />
                {errors.buildCost && <span className="text-[11px] text-red-600 font-bold">{errors.buildCost}</span>}
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Target Funding Required (₹) *</label>
                <input
                  type="text"
                  required
                  value={formData.targetFunding}
                  onChange={(e) => handleInputChange('targetFunding', e.target.value)}
                  placeholder="₹ 35,00,000"
                  className={`p-3 bg-[#faf6f0] border rounded-xl text-xs font-bold ${errors.targetFunding ? 'border-red-500' : 'border-[#e8d3b9]'}`}
                />
                {errors.targetFunding && <span className="text-[11px] text-red-600 font-bold">{errors.targetFunding}</span>}
              </div>

              <div className="sm:col-span-2 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Brief Explanation of Estimated Cost</label>
                <input
                  type="text"
                  value={formData.costExplanation}
                  onChange={(e) => handleInputChange('costExplanation', e.target.value)}
                  placeholder="Hardware BOM accounts for ₹1.2L; prototyping test rigs account for ₹65k."
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>

              <div className="sm:col-span-2 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Optional Cost Breakdown</label>
                <input
                  type="text"
                  value={formData.costBreakdown}
                  onChange={(e) => handleInputChange('costBreakdown', e.target.value)}
                  placeholder="Sensors: ₹50k | PCB: ₹35k | Testing: ₹40k | Gateway: ₹25k"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>
            </div>
          </section>

          {/* ==================== SECTION 6: PATENT DOCUMENT UPLOADS ==================== */}
          <section className="flex flex-col gap-4 pb-8 border-b-2 border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[24px] text-[#d4af37]">policy</span>
              <h3 className="font-headline font-bold text-base sm:text-lg uppercase tracking-wider text-[#561922]">
                Section 6 – Patent & Intellectual Property Status
              </h3>
            </div>

            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Select Patent Status (4 Options) *</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                  {patentOptions.map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleInputChange('patentStatus', opt.id)}
                      className={`p-3 rounded-xl border-2 text-xs font-bold text-center transition-all ${
                        formData.patentStatus === opt.id
                          ? 'bg-[#561922] text-[#f7e7ce] border-[#d4af37] shadow-sm'
                          : 'bg-[#faf6f0] text-[#534343] border-[#e8d3b9] hover:bg-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Status A: No Patent */}
              {formData.patentStatus === 'No Patent' && (
                <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9] text-xs text-[#534343] flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#b89358]">info</span>
                  <span>No patent document is required for open innovations or early concept stages.</span>
                </div>
              )}

              {/* Status B: Patent Applied */}
              {formData.patentStatus === 'Patent Applied' && (
                <div className="p-5 rounded-2xl bg-[#faf6f0] border-2 border-[#b89358] flex flex-col gap-4">
                  <span className="text-xs font-bold text-[#561922] uppercase tracking-wider">
                    Patent Applied Requirements (Mandatory Uploads)
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Document 1: Patent Application Document */}
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-bold text-[#1b1c1a]">Original Patent Application Document *</label>
                      <input
                        type="file"
                        ref={patentAppDocRef}
                        accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                        className="hidden"
                        onChange={(e) => handleDocFileChange('patentAppDoc', e.target.files[0])}
                      />
                      <button
                        type="button"
                        onClick={() => patentAppDocRef.current && patentAppDocRef.current.click()}
                        className={`p-3 rounded-xl border-2 border-dashed bg-white text-xs font-bold flex items-center justify-center gap-2 ${errors.patentAppDoc ? 'border-red-500 text-red-600' : 'border-[#b89358] text-[#561922]'}`}
                      >
                        <span className="material-symbols-outlined text-[18px]">upload_file</span>
                        <span>{formData.patentAppDoc ? formData.patentAppDoc.name : '+ Upload Patent Application'}</span>
                      </button>
                      {errors.patentAppDoc && <span className="text-[11px] text-red-600 font-bold">{errors.patentAppDoc}</span>}
                    </div>

                    {/* Document 2: Supporting Application Proof */}
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-bold text-[#1b1c1a]">Supporting Application Proof *</label>
                      <input
                        type="file"
                        ref={patentAppProofRef}
                        accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                        className="hidden"
                        onChange={(e) => handleDocFileChange('patentAppProofDoc', e.target.files[0])}
                      />
                      <button
                        type="button"
                        onClick={() => patentAppProofRef.current && patentAppProofRef.current.click()}
                        className={`p-3 rounded-xl border-2 border-dashed bg-white text-xs font-bold flex items-center justify-center gap-2 ${errors.patentAppProofDoc ? 'border-red-500 text-red-600' : 'border-[#b89358] text-[#561922]'}`}
                      >
                        <span className="material-symbols-outlined text-[18px]">verified</span>
                        <span>{formData.patentAppProofDoc ? formData.patentAppProofDoc.name : '+ Upload Filing Proof'}</span>
                      </button>
                      {errors.patentAppProofDoc && <span className="text-[11px] text-red-600 font-bold">{errors.patentAppProofDoc}</span>}
                    </div>
                  </div>
                </div>
              )}

              {/* Status C: Published Patent */}
              {formData.patentStatus === 'Published Patent' && (
                <div className="p-5 rounded-2xl bg-[#faf6f0] border-2 border-[#b89358] flex flex-col gap-4">
                  <span className="text-xs font-bold text-[#561922] uppercase tracking-wider">
                    Published Patent Requirements (Mandatory Uploads)
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-bold text-[#1b1c1a]">Original Published Patent Document *</label>
                      <input
                        type="file"
                        ref={patentPubDocRef}
                        accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                        className="hidden"
                        onChange={(e) => handleDocFileChange('patentPubDoc', e.target.files[0])}
                      />
                      <button
                        type="button"
                        onClick={() => patentPubDocRef.current && patentPubDocRef.current.click()}
                        className={`p-3 rounded-xl border-2 border-dashed bg-white text-xs font-bold flex items-center justify-center gap-2 ${errors.patentPubDoc ? 'border-red-500 text-red-600' : 'border-[#b89358] text-[#561922]'}`}
                      >
                        <span className="material-symbols-outlined text-[18px]">upload_file</span>
                        <span>{formData.patentPubDoc ? formData.patentPubDoc.name : '+ Upload Published Patent'}</span>
                      </button>
                      {errors.patentPubDoc && <span className="text-[11px] text-red-600 font-bold">{errors.patentPubDoc}</span>}
                    </div>

                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-bold text-[#1b1c1a]">Relevant Supporting Proof *</label>
                      <input
                        type="file"
                        ref={patentPubProofRef}
                        accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                        className="hidden"
                        onChange={(e) => handleDocFileChange('patentPubProofDoc', e.target.files[0])}
                      />
                      <button
                        type="button"
                        onClick={() => patentPubProofRef.current && patentPubProofRef.current.click()}
                        className={`p-3 rounded-xl border-2 border-dashed bg-white text-xs font-bold flex items-center justify-center gap-2 ${errors.patentPubProofDoc ? 'border-red-500 text-red-600' : 'border-[#b89358] text-[#561922]'}`}
                      >
                        <span className="material-symbols-outlined text-[18px]">verified</span>
                        <span>{formData.patentPubProofDoc ? formData.patentPubProofDoc.name : '+ Upload Journal/Gazette Proof'}</span>
                      </button>
                      {errors.patentPubProofDoc && <span className="text-[11px] text-red-600 font-bold">{errors.patentPubProofDoc}</span>}
                    </div>
                  </div>
                </div>
              )}

              {/* Status D: Patent Granted */}
              {formData.patentStatus === 'Patent Granted' && (
                <div className="p-5 rounded-2xl bg-[#faf6f0] border-2 border-[#b89358] flex flex-col gap-4">
                  <span className="text-xs font-bold text-[#561922] uppercase tracking-wider">
                    Patent Granted Requirement (Mandatory Upload)
                  </span>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Original Granted Patent Document *</label>
                    <input
                      type="file"
                      ref={patentGrantedRef}
                      accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                      className="hidden"
                      onChange={(e) => handleDocFileChange('patentGrantedDoc', e.target.files[0])}
                    />
                    <button
                      type="button"
                      onClick={() => patentGrantedRef.current && patentGrantedRef.current.click()}
                      className={`p-3 rounded-xl border-2 border-dashed bg-white text-xs font-bold flex items-center justify-center gap-2 ${errors.patentGrantedDoc ? 'border-red-500 text-red-600' : 'border-[#b89358] text-[#561922]'}`}
                    >
                      <span className="material-symbols-outlined text-[18px]">verified_user</span>
                      <span>{formData.patentGrantedDoc ? formData.patentGrantedDoc.name : '+ Upload Official Granted Patent Certificate'}</span>
                    </button>
                    {errors.patentGrantedDoc && <span className="text-[11px] text-red-600 font-bold">{errors.patentGrantedDoc}</span>}
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* ==================== SECTION 7: DEVELOPER INFORMATION ==================== */}
          <section className="flex flex-col gap-4 pb-8 border-b-2 border-[#e8d3b9]">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[24px] text-[#d4af37]">badge</span>
              <h3 className="font-headline font-bold text-base sm:text-lg uppercase tracking-wider text-[#561922]">
                Section 7 – Developer Information
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Developer Name *</label>
                <input
                  type="text"
                  required
                  value={formData.devName}
                  onChange={(e) => handleInputChange('devName', e.target.value)}
                  placeholder="Dr. Siddharth Verma"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
                {errors.devName && <span className="text-[11px] text-red-600 font-bold">{errors.devName}</span>}
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Email Address *</label>
                <input
                  type="email"
                  required
                  value={formData.devEmail}
                  onChange={(e) => handleInputChange('devEmail', e.target.value)}
                  placeholder="founder@aeropulse.health"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
                {errors.devEmail && <span className="text-[11px] text-red-600 font-bold">{errors.devEmail}</span>}
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Phone Number</label>
                <input
                  type="tel"
                  value={formData.devPhone}
                  onChange={(e) => handleInputChange('devPhone', e.target.value)}
                  placeholder="+91 98450 12890"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>

              <div className="sm:col-span-2 flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">College / Institution / Company</label>
                <input
                  type="text"
                  value={formData.institution}
                  onChange={(e) => handleInputChange('institution', e.target.value)}
                  placeholder="IIT Kharagpur AgTech Incubator / AIIMS Delhi"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-[#1b1c1a]">Team Size & Composition</label>
                <input
                  type="text"
                  value={formData.team}
                  onChange={(e) => handleInputChange('team', e.target.value)}
                  placeholder="4 Engineers, 1 Agronomist"
                  className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                />
              </div>
            </div>
          </section>

          {/* ==================== SECTION 8: DECLARATION & BOTTOM RIGHT EQUAL BUTTONS ==================== */}
          <section className="flex flex-col gap-6">
            
            {/* Mandatory Originality Declaration Checkbox */}
            <div className={`p-4 rounded-2xl border-2 transition-all ${errors.declaration ? 'border-red-500 bg-red-50' : 'border-[#d4af37] bg-[#faf6f0]'}`}>
              <label className="flex items-start gap-3 text-xs sm:text-sm text-[#1b1c1a] cursor-pointer select-none leading-relaxed">
                <input
                  type="checkbox"
                  checked={formData.declaration}
                  onChange={(e) => handleInputChange('declaration', e.target.checked)}
                  className="w-5 h-5 mt-0.5 rounded text-[#561922] accent-[#561922] shrink-0"
                />
                <span>
                  <strong>I confirm that all information, documents, images, videos and other materials submitted by me are genuine and that I have the necessary rights and authorization to submit them. I understand that fake, duplicated or misleading information may result in rejection and appropriate action under the platform's rules.</strong>
                </span>
              </label>
              {errors.declaration && <p className="text-[11px] text-red-600 font-bold mt-2 ml-8">{errors.declaration}</p>}
            </div>

            {/* Bottom Right Equal Dimensions Action Buttons */}
            {/* Exactly: Cancel, Reset, Submit with equal width/height, champagne-gold and burgundy colors */}
            <div className="flex flex-wrap items-center justify-end gap-4 pt-4 border-t-2 border-[#e8d3b9]">
              
              {/* Cancel Button */}
              <button
                type="button"
                onClick={onCancel}
                className="w-36 h-12 rounded-xl font-bold text-xs sm:text-sm bg-[#faf6f0] text-[#561922] border-2 border-[#b89358] hover:bg-[#e8d3b9] transition-all flex items-center justify-center cursor-pointer text-center"
              >
                <span>Cancel</span>
              </button>

              {/* Reset Button */}
              <button
                type="button"
                onClick={handleReset}
                className="w-36 h-12 rounded-xl font-bold text-xs sm:text-sm bg-[#faf6f0] text-[#561922] border-2 border-[#b89358] hover:bg-[#e8d3b9] transition-all flex items-center justify-center cursor-pointer text-center"
              >
                <span>Reset Form</span>
              </button>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-44 h-12 rounded-xl font-bold text-xs sm:text-sm bg-[#d4af37] text-[#561922] border-2 border-[#e5c158] hover:bg-[#e5c158] transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer text-center"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-4 h-4 border-2 border-[#561922] border-t-transparent rounded-full animate-spin"></span>
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[18px]">publish</span>
                    <span>Submit Project</span>
                  </>
                )}
              </button>

            </div>

          </section>

        </form>
      )}

    </div>
  );
}

window.SubmitProjectPage = SubmitProjectPage;

