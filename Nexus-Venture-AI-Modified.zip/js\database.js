/**
 * NEXUS VENTURE AI - Central Database Engine & LocalStorage Manager
 * Stores and manages Projects, Investors, Reviews, and Public Ideas.
 * Uses localStorage for persistent browser-based storage with pre-seeded demo data.
 */

const DB_STORAGE_KEY_PROJECTS = 'nexus_venture_ai_projects';
const DB_STORAGE_KEY_INVESTORS = 'nexus_venture_ai_investors';
const DB_STORAGE_KEY_REVIEWS = 'nexus_venture_ai_reviews';
const DB_STORAGE_KEY_IDEAS = 'nexus_venture_ai_ideas';
const DB_STORAGE_KEY_USER = 'nexus_venture_ai_current_user';

// Initial realistic projects representing all 6 sectors & 4 stages
const INITIAL_PROJECTS = [
  {
    id: 'proj-1',
    name: 'AgriSense IoT',
    sector: 'Agriculture',
    stage: 'Field Tested with Users',
    summary: 'Autonomous multispectral drone & soil-probe network optimizing irrigation and yield prediction in arid soil zones.',
    fullDescription: 'AgriSense combines solar-powered soil nitrogen-phosphorus-potassium (NPK) telemetry probes with autonomous low-altitude multispectral drone mapping. Farmers receive predictive moisture maps and automated micro-drip pump activation schedules via cellular telemetry without requiring internet access on the farm.',
    benefits: [
      'Reduces irrigation water consumption by 42% across dryland crops.',
      'Prevents fertilizer over-saturation, cutting input costs by ₹14,000 per acre.',
      'Detects fungal crop infestations 9 days before visible leaf discoloration.'
    ],
    image: 'https://images.unsplash.com/photo-1586771107445-d3ca888129ff?w=800&auto=format&fit=crop&q=80',
    prototypeImage: 'https://images.unsplash.com/photo-1592982537447-7440770cbfc9?w=800&auto=format&fit=crop&q=80',
    supportingImages: [
      'https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: 'https://www.youtube.com/embed/ScMzIvxBSi4',
    videoDescription: 'Live field deployment testing soil probes across 15 acres of groundnut farms in Anantapur district, demonstrating telemetry packet transmission over LoRaWAN.',
    languages: ['Python', 'C++', 'Embedded C', 'JavaScript'],
    frameworks: ['PyTorch Mobile', 'FastAPI', 'FreeRTOS', 'Tailwind CSS'],
    frontend: 'HTML5, React Micro-dashboard, Leaflet GIS Maps',
    backend: 'FastAPI, TimescaleDB, MQTT Broker',
    hardwareParts: ['ESP32-S3 Microcontroller', 'NPK Soil Sensor Probe', 'SX1276 LoRa Transceiver', 'Multispectral Camera Module', '6W Monocrystalline Solar Panel'],
    buildCost: '₹1,85,000',
    targetFunding: '₹35,00,000',
    costExplanation: 'Hardware BOM accounts for ₹1.2L per cluster unit; firmware calibration and drone airframe assembly total ₹65k.',
    costBreakdown: 'Sensors & MCU: ₹65,000 | LoRa Gateway: ₹40,000 | Drone Frame & Gimbal: ₹50,000 | Battery & Enclosure: ₹30,000',
    patentStatus: 'Granted Patent',
    patentDetails: {
      patentNumber: 'IN-389124-B',
      grantDate: '2024-08-14',
      publicationNumber: 'IN202341019821A',
      description: 'System and Apparatus for Autonomous In-Situ Soil Micro-Nutrient Telemetry via Solar LoRa Mesh'
    },
    developer: {
      name: 'Rohan Deshmukh & Team',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      role: 'Startup Developer (Lead Embedded Engineer)',
      institution: 'IIT Kharagpur AgTech Incubator',
      background: 'Final Year Agricultural & Food Engineering student with 3 IEEE publications in precision irrigation.',
      email: 'rohan.agrisense@iitkgp.ac.in',
      phone: '+91 98450 12890',
      team: '4 Core Members (2 Hardware Engineers, 1 ML Researcher, 1 Agronomist)'
    },
    rating: 4.5,
    reviewsCount: 14,
    reviews: [
      {
        id: 'rev-1',
        reviewerName: 'Dr. K. Swaminathan',
        role: 'University Professor (Agronomy)',
        rating: 4.5,
        date: '2026-10-18',
        comment: 'Rigorous experimental design. The LoRa mesh reliability in rural micro-climates solves the last-mile telemetry bottleneck for smallholder farmers.'
      },
      {
        id: 'rev-2',
        reviewerName: 'Aavishkaar Seed Capital',
        role: 'Investor (AgriTech Partner)',
        rating: 5.0,
        date: '2026-10-29',
        comment: 'Outstanding unit economics. The prototype demonstrates a verifiable path to sub-₹15,000 farm station costs with patent-protected sensor calibration.'
      }
    ]
  },
  {
    id: 'proj-2',
    name: 'CardioPulse AI',
    sector: 'Healthcare',
    stage: 'Full Project Ready',
    summary: 'Ultra-portable 12-lead ECG patch with real-time arrhythmia detection model running on edge microcontrollers.',
    fullDescription: 'CardioPulse AI is an ultra-low power wearable biosensor patch designed for community health workers and rural clinics. It captures clinical-grade 12-lead ECG signals, performs on-chip arrhythmia inference with 98.4% sensitivity, and alerts cardiac specialists within 3 seconds over 4G/NB-IoT.',
    benefits: [
      'Eliminates diagnostic delays for acute myocardial infarction in non-urban dispensaries.',
      'Medical-grade ECG signal processing at 1/10th the cost of conventional cart ECG machines.',
      '7-day continuous battery life on a single wireless coin-cell charge.'
    ],
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80',
    prototypeImage: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&auto=format&fit=crop&q=80',
    supportingImages: [
      'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: 'https://www.youtube.com/embed/ScMzIvxBSi4',
    videoDescription: 'Clinical trial demonstration validating automated ST-elevation detection against standard hospital 12-lead machines.',
    languages: ['C', 'Python', 'Rust', 'TypeScript'],
    frameworks: ['TensorFlow Lite Micro', 'Edge Impulse SDK', 'Next.js', 'PostgreSQL'],
    frontend: 'React Web Portal, DICOM Viewer, Tailwind CSS',
    backend: 'Node.js, HL7/FHIR Compliant API, Redis',
    hardwareParts: ['Analog Front-End ADS1298', 'STM32WB55 Dual-Core MCU', 'Biocompatible Hydrogel Electrodes', 'Qi Wireless Receiver Coil'],
    buildCost: '₹2,40,000',
    targetFunding: '₹50,0,000',
    costExplanation: 'Prototyping involves custom flexible PCB manufacturing, medical-grade biocompatibility test rigs, and micro-controller samples.',
    costBreakdown: 'Flexible PCB & Tooling: ₹90,000 | ADS1298 ICs & Passives: ₹55,000 | Regulatory Testing Rigs: ₹50,000 | Software/Firmware QA: ₹45,000',
    patentStatus: 'Published Patent Application',
    patentDetails: {
      applicationNumber: '202341058291',
      publicationNumber: 'IN202341058291A',
      publicationDate: '2024-03-22',
      description: 'Method and System for Low-Latency Cardiac Anomaly Inference on Ultra-Low Power Dual-Core Microcontrollers'
    },
    developer: {
      name: 'Dr. Siddharth Verma & Priya Nair',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
      role: 'Startup Developer (Biomedical Innovator)',
      institution: 'AIIMS & IIT Delhi MedTech Collaborative',
      background: 'Biomedical engineering researchers with 4 years clinical signal processing experience.',
      email: 'siddharth@aeropulse.health',
      phone: '+91 97110 54321',
      team: '3 Hardware Engineers, 2 Cardiologist Advisors'
    },
    rating: 4.8,
    reviewsCount: 22,
    reviews: [
      {
        id: 'rev-3',
        reviewerName: 'Dr. Ananya Sen',
        role: 'Investor (Lead Syndicate Partner)',
        rating: 5.0,
        date: '2026-10-25',
        comment: 'High clinical relevance and formidable IP moat. The on-device inference drastically reduces cloud bandwidth and meets HIPAA/CDSCO compliance.'
      },
      {
        id: 'rev-4',
        reviewerName: 'Vikram Joshi',
        role: 'Fellow Student Developer',
        rating: 4.5,
        date: '2026-11-01',
        comment: 'Extremely well-documented schematic and firmware structure. Inspiring use of STM32WB BLE stack.'
      }
    ]
  },
  {
    id: 'proj-3',
    name: 'AquaPurify Solid-State Filter',
    sector: 'Environment',
    stage: 'MVP / Early Product',
    summary: 'Zero-power graphene oxide nanostructured membrane removing heavy metals and arsenic from rural groundwater.',
    fullDescription: 'AquaPurify uses a low-cost graphene-sand matrix synthesized from agricultural rice-husk silica waste. The gravity-fed filter removes 99.7% of arsenic, lead, and microbial pathogens without requiring electricity or chemical disinfection cartridges.',
    benefits: [
      'Operates completely on gravitational head, requiring 0 Watts electrical energy.',
      'Filters 250 liters of clean drinking water daily per household module.',
      'Filter cartridge utilizes upcycled biomass, lowering replacement cost to ₹180.'
    ],
    image: 'https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=800&auto=format&fit=crop&q=80',
    prototypeImage: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80',
    supportingImages: [
      'https://images.unsplash.com/photo-1576086213369-97a306d36557?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: 'https://www.youtube.com/embed/ScMzIvxBSi4',
    videoDescription: 'Chemical laboratory spectrographic testing showing heavy metal filtration before and after passage through graphene oxide sand matrix.',
    languages: ['MATLAB', 'Python'],
    frameworks: ['COMSOL Multiphysics', 'LabVIEW'],
    frontend: 'Interactive Quality Assessment Web Portal',
    backend: 'Flask Microservice, SQLite',
    hardwareParts: ['Nanostructured Graphene-Sand Matrix', 'Food-Grade Recycled Polypropylene Column', 'Turbidity Spectrophotometer Check', 'Gravity Feed Regulator Valve'],
    buildCost: '₹95,000',
    targetFunding: '₹20,00,000',
    costExplanation: 'Material synthesis autoclave, laboratory spectrographic testing at NABL accredited labs, and mold tooling for gravity housings.',
    costBreakdown: 'Material Synthesis: ₹35,000 | NABL Lab Certification: ₹30,000 | Prototype Housings: ₹18,000 | Test Sensors: ₹12,000',
    patentStatus: 'Patent Applied – Pending',
    patentDetails: {
      applicationNumber: '202411032190',
      filingDate: '2024-05-10',
      description: 'Process for Synthesizing High-Surface-Area Graphene Oxide from Agro-Waste for Arsenic Chelation'
    },
    developer: {
      name: 'Sneha Banerjee',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80',
      role: 'Startup Developer (Chemical & Materials Engineer)',
      institution: 'Jadavpur University School of Environmental Studies',
      background: 'Postgraduate researcher focusing on water toxicology in the Bengal Delta region.',
      email: 'sneha.banerjee@jadavpur.edu',
      phone: '+91 94330 98765',
      team: '2 Materials Chemists, 1 Field Implementation Lead'
    },
    rating: 4.0,
    reviewsCount: 9,
    reviews: [
      {
        id: 'rev-5',
        reviewerName: 'Prof. Debabrata Roy',
        role: 'University Teacher (Chemical Eng.)',
        rating: 4.0,
        date: '2026-10-12',
        comment: 'Promising adsorbent matrix. Scaling will require automated packing of filter columns to prevent channeling.'
      }
    ]
  },
  {
    id: 'proj-4',
    name: 'Codex EduVR Learning Studio',
    sector: 'Education',
    stage: 'Full Project Ready',
    summary: 'Low-cost offline virtual science lab simulation kit running on standard school tablets and budget cardboard VR.',
    fullDescription: 'Codex replaces expensive physical science laboratory apparatus for rural schools with interactive physics, chemistry, and biology 3D virtual experiments. Operates completely without internet on low-cost devices and includes automated gamified student progress tracking.',
    benefits: [
      'Gives 100% of rural students access to dangerous/expensive chemistry and physics experiments.',
      'Works 100% offline via local micro-server synchronization.',
      'Reduces annual school lab budget burden by 85%.'
    ],
    image: 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=800&auto=format&fit=crop&q=80',
    prototypeImage: 'https://images.unsplash.com/photo-1592478411213-6153e4ebc07d?w=800&auto=format&fit=crop&q=80',
    supportingImages: [
      'https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: 'https://www.youtube.com/embed/ScMzIvxBSi4',
    videoDescription: 'Students at a district high school carrying out optics refraction and titration experiments using the offline VR headset.',
    languages: ['C#', 'TypeScript', 'GLSL', 'Python'],
    frameworks: ['Unity 3D', 'WebXR', 'React Native', 'Node.js'],
    frontend: 'Unity WebGL / React Native Tablet Shell',
    backend: 'Offline SQLite Sync Engine, Docker Micro-Server',
    hardwareParts: ['Raspberry Pi 4 Local Micro-Server', 'Custom Cardboard Biconvex Lenses', 'BLE Gesture Input Wand', '64GB Fast MicroSD Cache'],
    buildCost: '₹1,20,000',
    targetFunding: '₹18,00,000',
    costExplanation: 'Creation of 45 verified CBSE & ICSE syllabus laboratory 3D simulations, BLE gesture controller prototyping, and pilot classroom kits.',
    costBreakdown: '3D Asset Production: ₹45,000 | Unity Dev & Physics Engine: ₹40,000 | Hardware Controller Tooling: ₹25,000 | Pilot School Kits: ₹10,000',
    patentStatus: 'No Patent',
    patentDetails: {
      description: 'Open educational technology innovation protected under Creative Commons and registered educational copyright.'
    },
    developer: {
      name: 'Aditya Raj & Meera Nair',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
      role: 'Startup Developer (EdTech & XR Creators)',
      institution: 'BITS Pilani Innovation Hub',
      background: 'Computer Science graduates passionate about bridging STEM education inequality across Indian schools.',
      email: 'aditya.codex@bits-pilani.ac.in',
      phone: '+91 99801 45672',
      team: '3 Unity Developers, 2 Curriculum Experts'
    },
    rating: 4.5,
    reviewsCount: 16,
    reviews: [
      {
        id: 'rev-6',
        reviewerName: 'Sanjay Varma',
        role: 'Investor (Social Impact Fund)',
        rating: 4.5,
        date: '2026-10-22',
        comment: 'Incredible classroom engagement metrics. The offline micro-server approach solves the harsh reality of rural school bandwidth.'
      },
      {
        id: 'rev-7',
        reviewerName: 'Sunita Raman',
        role: 'University Teacher (Physics)',
        rating: 5.0,
        date: '2026-10-30',
        comment: 'The ray-optics simulator accurately replicates focal length variations. A genuinely revolutionary teaching aid.'
      }
    ]
  },
  {
    id: 'proj-5',
    name: 'NeuralGrid Edge Micro-Inverter',
    sector: 'Technology',
    stage: 'Field Tested with Users',
    summary: 'GaN-based smart rooftop solar micro-inverter with autonomous AI frequency regulation and anti-islanding safety.',
    fullDescription: 'NeuralGrid replaces bulky central solar inverters with individual panel micro-inverters built with Gallium Nitride (GaN) semiconductors. A local neural network dynamically regulates grid frequency deviations in real-time, boosting rooftop solar yield by 27% under partial shading.',
    benefits: [
      'Increases lifetime rooftop solar output by 27% under urban building shade.',
      'GaN power switching yields 98.7% peak conversion efficiency.',
      'Plug-and-play modular expansion without rewiring the building electrical panel.'
    ],
    image: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?w=800&auto=format&fit=crop&q=80',
    prototypeImage: 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=800&auto=format&fit=crop&q=80',
    supportingImages: [
      'https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: 'https://www.youtube.com/embed/ScMzIvxBSi4',
    videoDescription: 'Oscilloscope testing demonstrating GaN switching waveforms under variable irradiance and grid fault isolation.',
    languages: ['C', 'Verilog', 'Python'],
    frameworks: ['Texas Instruments C2000 SDK', 'MATLAB Simulink', 'PyQt Dashboard'],
    frontend: 'React Web & Mobile Telemetry Dashboard',
    backend: 'Golang Telemetry Broker, InfluxDB, WebSockets',
    hardwareParts: ['GaN Power MOSFETs (EPC2050)', 'TI TMS320F280049 Microcontroller', 'Current Transducer (LEM HO 15-P)', 'Custom Planar Transformer'],
    buildCost: '₹3,10,000',
    targetFunding: '₹75,00,000',
    costExplanation: 'High-power GaN components, high-frequency planar magnetic design, and power analyzer safety qualification.',
    costBreakdown: 'GaN Transistors & Gate Drivers: ₹1,10,000 | Planar Transformers & Magnetics: ₹75,000 | Precision Power Analyzer Testing: ₹65,000 | 4-Layer Heavy Copper PCBs: ₹60,000',
    patentStatus: 'Granted Patent',
    patentDetails: {
      patentNumber: 'IN-410928-B',
      grantDate: '2025-01-20',
      publicationNumber: 'IN202321045112A',
      description: 'Distributed GaN Micro-Inverter Architecture with Hardware-Accelerated Autonomous Grid Synchronization'
    },
    developer: {
      name: 'Nikhil Kashyap & Team',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
      role: 'Startup Developer (Power Electronics Lead)',
      institution: 'IISc Bangalore Power Engineering Lab',
      background: 'PhD researchers in wide-bandgap power semiconductor applications and grid-tied distributed energy.',
      email: 'nikhil.neuralgrid@iisc.ac.in',
      phone: '+91 98800 23456',
      team: '4 Core Power Electronics Engineers, 1 Grid Compliance Specialist'
    },
    rating: 4.8,
    reviewsCount: 18,
    reviews: [
      {
        id: 'rev-8',
        reviewerName: 'Rajesh Gopinath',
        role: 'Investor (CleanTech Venture Partner)',
        rating: 5.0,
        date: '2026-10-15',
        comment: 'World-class hardware engineering. The planar transformer density and GaN switching efficiency place this on par with global benchmarks like Enphase.'
      }
    ]
  },
  {
    id: 'proj-6',
    name: 'LedgerFlow Smart Escrow B2B',
    sector: 'Business',
    stage: 'MVP / Early Product',
    summary: 'Automated milestone-linked invoice factoring and escrow protocol protecting SME suppliers from delayed receivables.',
    fullDescription: 'LedgerFlow eliminates the chronic 90-day MSME payment cycle in supply chains through cryptographic milestone smart contracts. Upon digital proof of logistics delivery, funds held in bank escrow accounts automatically unlock directly to vendor bank accounts.',
    benefits: [
      'Cuts working capital credit costs for manufacturing MSMEs by up to 60%.',
      'Automates contract milestone verification using GPS e-Way bill data.',
      'Guarantees zero-risk collateralized invoice clearing.'
    ],
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80',
    prototypeImage: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&auto=format&fit=crop&q=80',
    supportingImages: [
      'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=800&auto=format&fit=crop&q=80'
    ],
    videoUrl: 'https://www.youtube.com/embed/ScMzIvxBSi4',
    videoDescription: 'Demonstration of smart contract execution triggered by automated GST e-Way bill logistics delivery verification.',
    languages: ['Solidity', 'Go', 'TypeScript', 'SQL'],
    frameworks: ['Hyperledger Besu', 'NestJS', 'Next.js', 'PostgreSQL'],
    frontend: 'React Web Application, Tailwind CSS, Web3 Modal',
    backend: 'NestJS REST API, Banking Open-API Webhooks, Redis',
    hardwareParts: ['Hardware Security Module (HSM Key Store)', 'Server Gateway Node'],
    buildCost: '₹1,50,000',
    targetFunding: '₹40,00,000',
    costExplanation: 'Smart contract security audits by certified audit firms, banking API integration sandboxes, and MSME compliance legal structuring.',
    costBreakdown: 'Security Audit: ₹60,000 | Open-Banking Sandbox Fees: ₹40,000 | Legal Structuring: ₹30,000 | Cloud Infrastructure: ₹20,000',
    patentStatus: 'Patent Applied – Pending',
    patentDetails: {
      applicationNumber: '202421018933',
      filingDate: '2024-06-18',
      description: 'System for Dynamic Milestone-Gated Escrow Liquidation Linked to Multi-Modal Logistics Verifications'
    },
    developer: {
      name: 'Kavita Menon & Arjun Shah',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&auto=format&fit=crop&q=80',
      role: 'Startup Developer (FinTech Founders)',
      institution: 'IIM Ahmedabad & IIT Bombay FinTech Cell',
      background: 'Founders with banking operations and distributed ledger systems experience.',
      email: 'kavita@ledgerflow.finance',
      phone: '+91 98200 87654',
      team: '2 Blockchain Engineers, 1 Regulatory Compliance Counsel'
    },
    rating: 4.5,
    reviewsCount: 11,
    reviews: [
      {
        id: 'rev-9',
        reviewerName: 'Suresh Singhania',
        role: 'Investor (Angel Syndicate)',
        rating: 4.5,
        date: '2026-10-28',
        comment: 'Solves the #1 pain point of Indian manufacturing MSMEs—delayed payments. Strong regulatory mapping to RBI guidelines.'
      }
    ]
  }
];

// Initial verified investor profiles
const INITIAL_INVESTORS = [
  {
    id: 'inv-1',
    name: 'Dr. Ananya Sen',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80',
    company: 'Aethel MedTech Angels & Syndicate',
    designation: 'Managing Partner & Lead Allocator',
    background: 'Former cardiac surgeon and healthcare venture partner with 16 years of early-stage medical device investment experience.',
    experience: '16+ Years in DeepTech & MedTech Seed Allocation',
    areasOfInterest: 'Wearable Biosensors, Surgical Robotics, Point-of-Care Diagnostics, AI in Pathology',
    preferredSectors: ['Healthcare', 'Technology'],
    previousInvestments: 'Deployed ₹14.5 Cr across 9 medical device startups with 3 successful follow-on Series A rounds.',
    pastProjectDetails: 'Lead seed investor in NeuroScan (acquired) and EndoSense Devices.',
    fundingRange: '₹25,00,000 – ₹1,50,00,000 per project',
    returnRateContext: 'Reported portfolio IRR of 28.4% across 7-year realized vintage with milestone-based tranche disbursements.',
    verified: true,
    email: 'ananya.sen@aethelangels.vc',
    phone: '+91 98100 11223'
  },
  {
    id: 'inv-2',
    name: 'Rajesh Gopinath',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&auto=format&fit=crop&q=80',
    company: 'Prithvi CleanTech Fund',
    designation: 'Founding General Partner',
    background: 'Ex-BHEL senior power engineer turned impact investor focusing on grid electronics, agritech, and energy storage.',
    experience: '12+ Years Venture Capital & Industrial Energy Systems',
    areasOfInterest: 'Solar Inverters, Grid Batteries, Agro-Waste Materials, Precision Drip Irrigation',
    preferredSectors: ['Agriculture', 'Environment', 'Technology'],
    previousInvestments: 'Funded 14 deep-engineering startups with focus on patent-backed hardware and hardware-enabled SaaS.',
    pastProjectDetails: 'Early backer of SuryaGrid IoT and BioPellet Energy.',
    fundingRange: '₹35,00,000 – ₹2,00,00,000 per startup',
    returnRateContext: 'Reported 3.2x MOIC on early climate-tech cohorts, emphasizing tangible patent protection.',
    verified: true,
    email: 'rajesh@prithvifund.in',
    phone: '+91 98400 33445'
  },
  {
    id: 'inv-3',
    name: 'Suresh Singhania',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&auto=format&fit=crop&q=80',
    company: 'Apex B2B Syndicate',
    designation: 'Principal Angel & Industrialist',
    background: 'Third-generation industrialist managing manufacturing supply chains and logistics infrastructure across Western India.',
    experience: '20+ Years Industrial Operations & Angel Investments',
    areasOfInterest: 'FinTech Escrow, Supply Chain Telemetry, Industrial Automation, Smart Warehousing',
    preferredSectors: ['Business', 'Technology', 'Education'],
    previousInvestments: 'Angel investor in 21 Indian startups with focus on MSME cash-flow automation and industrial IoT.',
    pastProjectDetails: 'Invested in FreightPulse and RoboAssembly Systems.',
    fundingRange: '₹15,00,000 – ₹80,00,000',
    returnRateContext: 'Historical angel portfolio return of 22% annualized with strong emphasis on supplier working capital.',
    verified: true,
    email: 'suresh@singhaniaholdings.com',
    phone: '+91 98220 55667'
  }
];

// Initial Public Ideas
const INITIAL_IDEAS = [
  {
    id: 'idea-1',
    name: 'Vikas Sharma',
    email: 'vikas.sharma@gmail.com',
    title: 'Smart Solar-Powered Grain Moisture Bag with RFID',
    sector: 'Agriculture',
    problem: 'Farmers lose 15-20% of harvested grain to fungal rot inside standard burlap bags due to undetected trapped moisture.',
    solution: 'A reusable hermetic grain storage bag woven with conductive moisture threads connected to a ₹15 passive RFID chip read by any smartphone NFC.',
    benefits: 'Prevents aflatoxin contamination and informs farmers precisely when grain is dry enough for market sale.',
    date: '2026-10-31'
  },
  {
    id: 'idea-2',
    name: 'Meenakshi Sundaram',
    email: 'meenakshi.s@outlook.com',
    title: 'Low-Cost Audio-Tactile Braille Converter for Village Schools',
    sector: 'Education',
    problem: 'Visually impaired students in regional schools lack access to expensive electronic refreshable Braille displays costing ₹1,50,000+.',
    solution: 'A 6-pin solenoid Braille finger pad that translates Tamil and Hindi text from mobile phones via camera OCR.',
    benefits: 'Costs under ₹3,500 to assemble and empowers blind students to read textbooks independently.',
    date: '2026-11-02'
  }
];

// Default demo user for the platform
const DEFAULT_USER = {
  name: 'Dr. Siddharth Verma',
  email: 'siddharth@aeropulse.health',
  role: 'Startup Developer',
  accountType: 'startup',
  accountTypeLabel: 'Founders & R&D',
  organization: 'AeroPulse MedTech Inc.',
  avatar: null,
  isLoggedIn: true
};

class NexusDatabase {
  constructor() {
    this.initDatabase();
  }

  initDatabase() {
    if (!localStorage.getItem(DB_STORAGE_KEY_PROJECTS)) {
      localStorage.setItem(DB_STORAGE_KEY_PROJECTS, JSON.stringify(INITIAL_PROJECTS));
    }
    if (!localStorage.getItem(DB_STORAGE_KEY_INVESTORS)) {
      localStorage.setItem(DB_STORAGE_KEY_INVESTORS, JSON.stringify(INITIAL_INVESTORS));
    }
    if (!localStorage.getItem(DB_STORAGE_KEY_IDEAS)) {
      localStorage.setItem(DB_STORAGE_KEY_IDEAS, JSON.stringify(INITIAL_IDEAS));
    }
    if (!localStorage.getItem(DB_STORAGE_KEY_USER)) {
      localStorage.setItem(DB_STORAGE_KEY_USER, JSON.stringify(DEFAULT_USER));
    }
  }

  // --- Projects API ---
  getProjects() {
    try {
      const data = localStorage.getItem(DB_STORAGE_KEY_PROJECTS);
      return data ? JSON.parse(data) : INITIAL_PROJECTS;
    } catch (e) {
      console.error('Failed to read projects from storage', e);
      return INITIAL_PROJECTS;
    }
  }

  getProjectById(id) {
    const projects = this.getProjects();
    return projects.find((p) => p.id === id) || null;
  }

  addProject(project) {
    const projects = this.getProjects();
    const newProject = {
      ...project,
      id: 'proj-' + Date.now(),
      rating: project.rating || 5.0,
      reviewsCount: project.reviewsCount || 1,
      reviews: project.reviews || [
        {
          id: 'rev-' + Date.now(),
          reviewerName: 'Nexus Venture AI Verification Bot',
          role: 'System Review',
          rating: 5.0,
          date: new Date().toISOString().split('T')[0],
          comment: 'Project successfully verified for technical completeness and listed on Nexus Venture AI.'
        }
      ]
    };
    projects.unshift(newProject);
    localStorage.setItem(DB_STORAGE_KEY_PROJECTS, JSON.stringify(projects));
    return newProject;
  }

  // --- Investors API ---
  getInvestors() {
    try {
      const data = localStorage.getItem(DB_STORAGE_KEY_INVESTORS);
      return data ? JSON.parse(data) : INITIAL_INVESTORS;
    } catch (e) {
      console.error('Failed to read investors from storage', e);
      return INITIAL_INVESTORS;
    }
  }

  updateInvestorProfile(investorData) {
    const investors = this.getInvestors();
    const existingIndex = investors.findIndex(
      (inv) => inv.id === investorData.id || inv.email === investorData.email
    );

    if (existingIndex >= 0) {
      investors[existingIndex] = { ...investors[existingIndex], ...investorData };
    } else {
      investors.unshift({
        ...investorData,
        id: 'inv-' + Date.now(),
        verified: false
      });
    }

    localStorage.setItem(DB_STORAGE_KEY_INVESTORS, JSON.stringify(investors));
    return investorData;
  }

  // --- Reviews API ---
  getAllReviews() {
    const projects = this.getProjects();
    const allReviews = [];
    projects.forEach((proj) => {
      if (proj.reviews && Array.isArray(proj.reviews)) {
        proj.reviews.forEach((rev) => {
          allReviews.push({
            ...rev,
            projectId: proj.id,
            projectName: proj.name,
            projectSector: proj.sector,
            projectStage: proj.stage,
            projectImage: proj.image
          });
        });
      }
    });
    // Sort reviews newest first
    return allReviews.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
  }

  addReview(projectId, review) {
    const projects = this.getProjects();
    const project = projects.find((p) => p.id === projectId);
    if (!project) return null;

    if (!project.reviews) project.reviews = [];
    
    const newRev = {
      id: 'rev-' + Date.now(),
      reviewerName: review.reviewerName.trim(),
      role: review.role,
      rating: parseFloat(review.rating),
      date: new Date().toISOString().split('T')[0],
      comment: review.comment.trim()
    };

    project.reviews.unshift(newRev);

    // Recalculate average rating with 1 decimal place
    const totalRating = project.reviews.reduce((acc, r) => acc + (parseFloat(r.rating) || 5), 0);
    project.rating = parseFloat((totalRating / project.reviews.length).toFixed(1));
    project.reviewsCount = project.reviews.length;

    localStorage.setItem(DB_STORAGE_KEY_PROJECTS, JSON.stringify(projects));
    return { project, review: newRev };
  }

  // --- Public Ideas API ---
  getIdeas() {
    try {
      const data = localStorage.getItem(DB_STORAGE_KEY_IDEAS);
      return data ? JSON.parse(data) : INITIAL_IDEAS;
    } catch (e) {
      return INITIAL_IDEAS;
    }
  }

  addIdea(idea) {
    const ideas = this.getIdeas();
    const newIdea = {
      ...idea,
      id: 'idea-' + Date.now(),
      date: new Date().toISOString().split('T')[0]
    };
    ideas.unshift(newIdea);
    localStorage.setItem(DB_STORAGE_KEY_IDEAS, JSON.stringify(ideas));
    return newIdea;
  }

  // --- Current User API ---
  getCurrentUser() {
    try {
      const data = localStorage.getItem(DB_STORAGE_KEY_USER);
      return data ? JSON.parse(data) : DEFAULT_USER;
    } catch (e) {
      return DEFAULT_USER;
    }
  }

  setCurrentUser(user) {
    localStorage.setItem(DB_STORAGE_KEY_USER, JSON.stringify(user));
  }

  // Helper to reset database to initial state
  resetAll() {
    localStorage.setItem(DB_STORAGE_KEY_PROJECTS, JSON.stringify(INITIAL_PROJECTS));
    localStorage.setItem(DB_STORAGE_KEY_INVESTORS, JSON.stringify(INITIAL_INVESTORS));
    localStorage.setItem(DB_STORAGE_KEY_IDEAS, JSON.stringify(INITIAL_IDEAS));
    localStorage.setItem(DB_STORAGE_KEY_USER, JSON.stringify(DEFAULT_USER));
  }
}

// Global database instance
window.NexusDB = new NexusDatabase();

