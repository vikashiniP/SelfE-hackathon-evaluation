/**
 * NEXUS VENTURE AI - Home Page Component
 * Complete implementation of Hero, Features, Vision, Mission, How It Works, and Public Ideas.
 * Luxury two-tone design: Rich Burgundy & Glossy Champagne Gold.
 */

function HomePage({ onExploreClick, onSubmitClick, onOpenIdeaModal }) {
  return (
    <div className="w-full flex flex-col gap-14 pb-16">
      
      {/* ===================== HERO SECTION ===================== */}
      <section className="relative overflow-hidden rounded-3xl bg-[#3c0b12] text-white border-2 border-[#b89358] shadow-xl p-8 sm:p-12 lg:p-16">
        {/* Subtle Luxury Gold & Maroon Decorative Accents */}
        <div className="absolute -right-24 -top-24 w-96 h-96 rounded-full bg-[#561922] opacity-40 blur-3xl pointer-events-none"></div>
        <div className="absolute -left-20 -bottom-20 w-80 h-80 rounded-full bg-[#d4af37] opacity-20 blur-3xl pointer-events-none"></div>

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#561922] border border-[#d4af37] w-fit shadow-xs">
              <span className="material-symbols-outlined text-[16px] text-[#d4af37]">hotel_class</span>
              <span className="text-xs font-bold uppercase tracking-widest text-[#f7e7ce]">
                Sovereign DeepTech & Capital Exchange
              </span>
            </div>

            <h1 className="font-serif-luxury font-extrabold text-3xl sm:text-4xl lg:text-5xl text-[#ffffff] leading-[1.15]">
              Your Ideas Deserve More Than Just Dreams.
            </h1>

            <p className="text-sm sm:text-base text-[#f7e7ce] leading-relaxed max-w-2xl font-normal">
              Every great business begins with an idea. <strong>NEXUS VENTURE AI</strong> connects innovative minds with the right investors, turning promising ideas into real-world opportunities.
            </p>

            {/* Three Equal Sized Action Buttons with Champagne Gold Background and Burgundy Text */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 max-w-2xl">
              <button
                type="button"
                onClick={onExploreClick}
                className="w-full py-3.5 px-4 rounded-xl font-bold text-xs sm:text-sm bg-[#d4af37] text-[#561922] border-2 border-[#e5c158] hover:bg-[#e5c158] transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer text-center"
              >
                <span className="material-symbols-outlined text-[20px] text-[#561922]">travel_explore</span>
                <span>Explore Projects</span>
              </button>

              <button
                type="button"
                onClick={onSubmitClick}
                className="w-full py-3.5 px-4 rounded-xl font-bold text-xs sm:text-sm bg-[#d4af37] text-[#561922] border-2 border-[#e5c158] hover:bg-[#e5c158] transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer text-center"
              >
                <span className="material-symbols-outlined text-[20px] text-[#561922]">rocket_launch</span>
                <span>Submit Project</span>
              </button>

              <button
                type="button"
                onClick={onOpenIdeaModal}
                className="w-full py-3.5 px-4 rounded-xl font-bold text-xs sm:text-sm bg-[#d4af37] text-[#561922] border-2 border-[#e5c158] hover:bg-[#e5c158] transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer text-center"
              >
                <span className="material-symbols-outlined text-[20px] text-[#561922]">lightbulb</span>
                <span>Submit Public Idea</span>
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-[#e8d3b9]/25 text-left">
              <div>
                <div className="text-xl sm:text-2xl font-extrabold text-[#d4af37]">₹18.4 Cr+</div>
                <div className="text-[11px] text-[#e8d3b9] uppercase tracking-wider font-semibold">Active Dealflow</div>
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-extrabold text-[#d4af37]">48+</div>
                <div className="text-[11px] text-[#e8d3b9] uppercase tracking-wider font-semibold">Filed Patents</div>
              </div>
              <div>
                <div className="text-xl sm:text-2xl font-extrabold text-[#d4af37]">100%</div>
                <div className="text-[11px] text-[#e8d3b9] uppercase tracking-wider font-semibold">Escrow Gated</div>
              </div>
            </div>
          </div>

          {/* Right Visual Column */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border-2 border-[#d4af37] shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&auto=format&fit=crop&q=80"
                alt="Startup Innovation Lab"
                className="w-full h-80 sm:h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#2b060d] via-transparent to-transparent"></div>

              {/* Live Badge Over Image */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#2b060d]/85 backdrop-blur-md border border-[#d4af37] flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-[#d4af37] uppercase tracking-wider block">Featured Innovation</span>
                  <span className="text-xs font-bold text-white">Edge Biosensor & Agro-Telemetry</span>
                </div>
                <span className="px-2.5 py-1 rounded-md text-[10px] font-bold bg-[#561922] text-[#f7e7ce] border border-[#d4af37]">
                  Patent Granted
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===================== WEBSITE FEATURES (EMPOWERING EVERY PILLAR) ===================== */}
      {/* Arranged strictly as: Row 1 = 3 equal boxes, Row 2 = 2 equal boxes center-aligned */}
      <section className="flex flex-col gap-8">
        <div className="flex flex-col gap-1 text-center max-w-2xl mx-auto">
          <div className="gold-badge mx-auto">Ecosystem Capabilities</div>
          <h2 className="font-headline font-bold text-2xl sm:text-3xl text-[#1b1c1a]">
            Empowering Every Pillar of Innovation
          </h2>
          <p className="text-xs sm:text-sm text-[#534343]">
            Comprehensive toolsets for developers to showcase working hardware models, investors to conduct technical due diligence, and the public to participate.
          </p>
        </div>

        {/* Row 1: Exactly Three Equal Boxes */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Box 1 */}
          <div className="gloss-gold-card rounded-2xl p-6 flex flex-col justify-between gap-3 h-full border-2 border-[#e8d3b9] bg-white shadow-xs">
            <div className="flex flex-col gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#561922] text-[#d4af37] flex items-center justify-center border border-[#d4af37] shadow-xs">
                <span className="material-symbols-outlined text-[26px]">rocket_launch</span>
              </div>
              <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">1. Pitch Your Innovation</h3>
              <p className="text-xs sm:text-sm text-[#534343] leading-relaxed">
                Allow startup developers to submit their innovative products and showcase their working models, technology and development details.
              </p>
            </div>
          </div>

          {/* Box 2 */}
          <div className="gloss-gold-card rounded-2xl p-6 flex flex-col justify-between gap-3 h-full border-2 border-[#e8d3b9] bg-white shadow-xs">
            <div className="flex flex-col gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#561922] text-[#d4af37] flex items-center justify-center border border-[#d4af37] shadow-xs">
                <span className="material-symbols-outlined text-[26px]">connect_without_contact</span>
              </div>
              <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">2. Connect With Investors</h3>
              <p className="text-xs sm:text-sm text-[#534343] leading-relaxed">
                Help startup developers discover investors interested in their respective project sectors and engage in direct, confidential conversations.
              </p>
            </div>
          </div>

          {/* Box 3 */}
          <div className="gloss-gold-card rounded-2xl p-6 flex flex-col justify-between gap-3 h-full border-2 border-[#e8d3b9] bg-white shadow-xs">
            <div className="flex flex-col gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#561922] text-[#d4af37] flex items-center justify-center border border-[#d4af37] shadow-xs">
                <span className="material-symbols-outlined text-[26px]">insights</span>
              </div>
              <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">3. Discover Opportunities</h3>
              <p className="text-xs sm:text-sm text-[#534343] leading-relaxed">
                Allow investors to explore different projects and evaluate their technical details, costs, development stages, and real-world benefits.
              </p>
            </div>
          </div>
        </div>

        {/* Row 2: Exactly Two Equal Boxes, Centre-Aligned */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto w-full">
          {/* Box 4 */}
          <div className="gloss-gold-card rounded-2xl p-6 flex flex-col justify-between gap-3 h-full border-2 border-[#e8d3b9] bg-white shadow-xs">
            <div className="flex flex-col gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#561922] text-[#d4af37] flex items-center justify-center border border-[#d4af37] shadow-xs">
                <span className="material-symbols-outlined text-[26px]">transform</span>
              </div>
              <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">4. Transform Ideas Into Businesses</h3>
              <p className="text-xs sm:text-sm text-[#534343] leading-relaxed">
                Help ordinary people share innovative ideas and explore ways to turn them into potential startups with technical and funding mentorship.
              </p>
            </div>
          </div>

          {/* Box 5 */}
          <div className="gloss-gold-card rounded-2xl p-6 flex flex-col justify-between gap-3 h-full border-2 border-[#e8d3b9] bg-white shadow-xs">
            <div className="flex flex-col gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#561922] text-[#d4af37] flex items-center justify-center border border-[#d4af37] shadow-xs">
                <span className="material-symbols-outlined text-[26px]">verified</span>
              </div>
              <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">5. Transparent Project Information</h3>
              <p className="text-xs sm:text-sm text-[#534343] leading-relaxed">
                Display verified project information, patent status, hardware bills of materials (BOM), and community feedback to help users make informed decisions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ===================== OUR VISION (CLEAN SIDE-BY-SIDE SECTION) ===================== */}
      {/* Box removed as requested; clean heading, logo-style emblem, meaningful paragraph, and representative image */}
      <section className="py-6 border-y-2 border-[#e8d3b9]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Text & Vision Content */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#561922] text-[#d4af37] flex items-center justify-center border-2 border-[#d4af37] shadow-sm shrink-0">
                <span className="material-symbols-outlined text-[26px]">visibility</span>
              </div>
              <div>
                <span className="text-[11px] font-bold text-[#b89358] tracking-widest uppercase block">
                  Strategic Horizon
                </span>
                <h2 className="font-headline font-bold text-2xl sm:text-3xl text-[#561922]">
                  Our Vision
                </h2>
              </div>
            </div>

            <p className="text-sm sm:text-base text-[#1b1c1a] leading-relaxed font-normal">
              To establish a sovereign, transparent, and transformative innovation ecosystem where deeptech breakthroughs transition seamlessly from laboratory concepts into high-impact enterprises. <strong>NEXUS VENTURE AI</strong> bridges visionary startup founders with accredited global investors through milestone-governed escrow and verified patent timestamping, cultivating enduring technological progress.
            </p>

            <div className="flex items-center gap-4 pt-2">
              <div className="flex items-center gap-2 text-xs font-bold text-[#561922]">
                <span className="material-symbols-outlined text-[#d4af37] text-[18px]">verified</span>
                <span>Milestone-Governed Escrow</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-bold text-[#561922]">
                <span className="material-symbols-outlined text-[#d4af37] text-[18px]">shield</span>
                <span>Verified Patent Priority</span>
              </div>
            </div>
          </div>

          {/* Right Representative Vision Image */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden border-2 border-[#b89358] shadow-md group">
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop&q=80"
                alt="Nexus Venture AI Collaborative Vision"
                className="w-full h-64 sm:h-72 object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#2b060d]/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-3 left-4 right-4 text-white">
                <span className="text-[10px] text-[#d4af37] uppercase tracking-wider font-bold block">Ecosystem Unity</span>
                <span className="text-xs font-semibold text-[#f7e7ce]">Connecting Engineering Intellect with Institutional Capital</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===================== MISSION SECTION (PRESERVED) ===================== */}
      <section className="flex flex-col gap-6">
        <div className="text-center max-w-2xl mx-auto">
          <div className="burgundy-badge mx-auto">Core Purpose</div>
          <h2 className="font-headline font-bold text-2xl sm:text-3xl text-[#1b1c1a] mt-1">
            Our Three-Fold Mission
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Mission 1 */}
          <div className="bg-white border-2 border-[#e8d3b9] hover:border-[#561922] rounded-2xl p-6 shadow-sm flex flex-col gap-3 transition-all">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#ffdadb] text-[#561922] uppercase tracking-wider">
                Mission 1
              </span>
              <span className="material-symbols-outlined text-[#561922] text-[20px]">engineering</span>
            </div>
            <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">
              Empower Startup Developers
            </h3>
            <p className="text-xs sm:text-sm text-[#534343] leading-relaxed">
              Help startup developers receive suitable funding and opportunities to transform their innovative projects into successful products.
            </p>
          </div>

          {/* Mission 2 */}
          <div className="bg-white border-2 border-[#e8d3b9] hover:border-[#b89358] rounded-2xl p-6 shadow-sm flex flex-col gap-3 transition-all">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#f7e7ce] text-[#561922] uppercase tracking-wider">
                Mission 2
              </span>
              <span className="material-symbols-outlined text-[#b89358] text-[20px]">verified_user</span>
            </div>
            <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">
              Build Investor Confidence
            </h3>
            <p className="text-xs sm:text-sm text-[#534343] leading-relaxed">
              Promote transparency by providing project information, patent status, technical specifications and genuine community feedback.
            </p>
          </div>

          {/* Mission 3 */}
          <div className="bg-white border-2 border-[#e8d3b9] hover:border-[#561922] rounded-2xl p-6 shadow-sm flex flex-col gap-3 transition-all">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#faf6f0] text-[#534343] uppercase tracking-wider">
                Mission 3
              </span>
              <span className="material-symbols-outlined text-[#561922] text-[20px]">diversity_3</span>
            </div>
            <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">
              Engage the General Public
            </h3>
            <p className="text-xs sm:text-sm text-[#534343] leading-relaxed">
              Enable public participation by allowing users to explore innovations, submit ideas, rate products and contribute to startup success.
            </p>
          </div>
        </div>
      </section>

      {/* ===================== HOW NEXUS VENTURE AI WORKS (PRESERVED) ===================== */}
      <section className="flex flex-col gap-8 p-8 sm:p-10 rounded-3xl bg-white border-2 border-[#e8d3b9] shadow-sm">
        <div className="text-center max-w-2xl mx-auto">
          <div className="gold-badge mx-auto">Sovereign Architecture</div>
          <h2 className="font-headline font-bold text-2xl sm:text-3xl text-[#1b1c1a] mt-1">
            How NEXUS VENTURE AI Works
          </h2>
          <p className="text-xs sm:text-sm text-[#534343]">
            A transparent four-step protocol governing capital allocation, milestone validation, and patent priority.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="flex flex-col items-center text-center gap-3 p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9]">
            <div className="w-12 h-12 rounded-xl bg-[#561922] text-[#d4af37] font-extrabold flex items-center justify-center text-lg border border-[#d4af37]">
              1
            </div>
            <h4 className="font-headline font-bold text-sm text-[#1b1c1a]">Submit Project</h4>
            <p className="text-xs text-[#534343] leading-relaxed">
              Founders document specifications, BOM parts list, working prototype video and patent status.
            </p>
          </div>

          <div className="flex flex-col items-center text-center gap-3 p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9]">
            <div className="w-12 h-12 rounded-xl bg-[#561922] text-[#d4af37] font-extrabold flex items-center justify-center text-lg border border-[#d4af37]">
              2
            </div>
            <h4 className="font-headline font-bold text-sm text-[#1b1c1a]">Peer & Investor Review</h4>
            <p className="text-xs text-[#534343] leading-relaxed">
              Accredited angels and university faculty examine technical feasibility and submit community reviews.
            </p>
          </div>

          <div className="flex flex-col items-center text-center gap-3 p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9]">
            <div className="w-12 h-12 rounded-xl bg-[#561922] text-[#d4af37] font-extrabold flex items-center justify-center text-lg border border-[#d4af37]">
              3
            </div>
            <h4 className="font-headline font-bold text-sm text-[#1b1c1a]">Milestone Escrow</h4>
            <p className="text-xs text-[#534343] leading-relaxed">
              Capital commitments are locked into escrow vaults and released only upon verified milestone delivery.
            </p>
          </div>

          <div className="flex flex-col items-center text-center gap-3 p-4 rounded-xl bg-[#faf6f0] border border-[#e8d3b9]">
            <div className="w-12 h-12 rounded-xl bg-[#561922] text-[#d4af37] font-extrabold flex items-center justify-center text-lg border border-[#d4af37]">
              4
            </div>
            <h4 className="font-headline font-bold text-sm text-[#1b1c1a]">Product Deployment</h4>
            <p className="text-xs text-[#534343] leading-relaxed">
              Validated hardware and software transition into field deployment and enterprise scaling.
            </p>
          </div>
        </div>
      </section>

      {/* ===================== HAVE AN IDEA? BANNER (PRESERVED) ===================== */}
      <section className="rounded-3xl bg-[#faf6f0] border-2 border-[#b89358] p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
        <div className="flex flex-col gap-2 max-w-xl">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#561922] uppercase tracking-wider">
            <span className="material-symbols-outlined text-[18px] text-[#d4af37]">lightbulb</span>
            <span>Have an Innovative Idea?</span>
          </div>
          <h3 className="font-headline font-bold text-xl sm:text-2xl text-[#1b1c1a]">
            Submit Your Concept in Simple Words
          </h3>
          <p className="text-xs sm:text-sm text-[#534343] leading-relaxed">
            You don&apos;t need a registered company or existing patent to get started. Submit your concept in simple words. Our community of engineers and advisors will review feasible technologies.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenIdeaModal}
          className="btn-gold text-sm py-3 px-6 shrink-0 shadow-md flex items-center gap-2 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[20px]">add_circle</span>
          <span>Submit Your Idea</span>
        </button>
      </section>

    </div>
  );
}

window.HomePage = HomePage;
