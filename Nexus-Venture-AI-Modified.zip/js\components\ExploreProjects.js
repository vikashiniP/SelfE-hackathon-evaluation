/**
 * NEXUS VENTURE AI - Explore Projects Component
 * Multi-filter system: Search box, 6 Sector pills, 4 Stage dropdown, 4 Sorting options.
 * Fixes:
 * - Single-letter and partial-word searches (e.g. typing "H" matches projects)
 * - Search executes on Search button click, Enter key, and typing
 * - Highlight matching letters or words in displayed results with champagne-gold styling
 * - Entire project card is clickable and opens corresponding project details
 */

function ExploreProjects({ projects = [], onSelectProject, openSubmitModal }) {
  const { useState, useMemo } = React;

  const [searchInput, setSearchInput] = useState('');
  const [activeQuery, setActiveQuery] = useState('');
  const [selectedSector, setSelectedSector] = useState('All');
  const [selectedStage, setSelectedStage] = useState('All');
  const [sortBy, setSortBy] = useState('highest_rated');

  const sectors = ['Agriculture', 'Environment', 'Healthcare', 'Education', 'Technology', 'Business'];
  const stages = [
    'Idea / Concept',
    'MVP / Early Product',
    'Full Project Ready',
    'Field Tested with Users'
  ];

  // Helper to trigger search
  const triggerSearch = () => {
    setActiveQuery(searchInput.trim());
  };

  // Helper to handle input change and live typing search
  const handleInputChange = (e) => {
    const val = e.target.value;
    setSearchInput(val);
    setActiveQuery(val.trim());
  };

  // Helper to parse build cost numeric value from string
  const parseCost = (costStr) => {
    if (!costStr) return 0;
    const clean = costStr.toString().replace(/[^0-9]/g, '');
    return parseInt(clean, 10) || 0;
  };

  // Coordinated filtering and sorting supporting single-letter and partial-word search
  const filteredProjects = useMemo(() => {
    return projects.filter((project) => {
      // 1. Sector Filter
      if (selectedSector !== 'All' && project.sector !== selectedSector) {
        return false;
      }

      // 2. Stage Filter
      if (selectedStage !== 'All' && project.stage !== selectedStage) {
        return false;
      }

      // 3. Search query matching across project information
      if (activeQuery !== '') {
        const q = activeQuery.toLowerCase();
        const matchName = (project.name || '').toLowerCase().includes(q);
        const matchSector = (project.sector || '').toLowerCase().includes(q);
        const matchStage = (project.stage || '').toLowerCase().includes(q);
        const matchSummary = (project.summary || '').toLowerCase().includes(q);
        const matchDesc = (project.fullDescription || '').toLowerCase().includes(q);
        const matchDev = (project.developer && project.developer.name ? project.developer.name : '').toLowerCase().includes(q);
        const matchKeywords = (project.languages || []).some((l) => l.toLowerCase().includes(q)) ||
                              (project.frameworks || []).some((f) => f.toLowerCase().includes(q)) ||
                              (project.hardwareParts || []).some((h) => h.toLowerCase().includes(q));

        if (!matchName && !matchSector && !matchStage && !matchSummary && !matchDesc && !matchDev && !matchKeywords) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'highest_rated') {
        return (b.rating || 0) - (a.rating || 0);
      }
      if (sortBy === 'cost_low_to_high') {
        return parseCost(a.buildCost) - parseCost(b.buildCost);
      }
      if (sortBy === 'cost_high_to_low') {
        return parseCost(b.buildCost) - parseCost(a.buildCost);
      }
      if (sortBy === 'recently_published') {
        return (b.id || '').localeCompare(a.id || '');
      }
      return 0;
    });
  }, [projects, activeQuery, selectedSector, selectedStage, sortBy]);

  // Star rendering helper with decimal / half-star support
  const renderStarRating = (rating) => {
    const stars = [];
    const num = typeof rating === 'number' ? rating : parseFloat(rating) || 4.5;
    const fullStars = Math.floor(num);
    const hasHalfStar = (num % 1) >= 0.25 && (num % 1) <= 0.75;

    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(
          <span key={i} className="material-symbols-outlined text-[16px] text-amber-500 fill-current">
            star
          </span>
        );
      } else if (i === fullStars + 1 && hasHalfStar) {
        stars.push(
          <span key={i} className="material-symbols-outlined text-[16px] text-amber-500 fill-current">
            star_half
          </span>
        );
      } else {
        stars.push(
          <span key={i} className="material-symbols-outlined text-[16px] text-gray-300">
            star
          </span>
        );
      }
    }
    return stars;
  };

  // Helper to highlight matching letters or words in results
  const highlightMatch = (text, query) => {
    if (!text) return '';
    if (!query || !query.trim()) return text;

    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);

    return parts.map((part, index) => {
      if (part.toLowerCase() === query.toLowerCase()) {
        return (
          <mark key={index} className="bg-[#f7e7ce] text-[#561922] font-extrabold px-0.5 rounded">
            {part}
          </mark>
        );
      }
      return part;
    });
  };

  // Currency display helper ensuring clean formatting
  const formatDisplayCost = (val) => {
    if (!val) return '₹ 0';
    const num = parseInt(val.toString().replace(/[^0-9]/g, ''), 10);
    if (isNaN(num)) return val;
    return '₹ ' + num.toLocaleString('en-IN');
  };

  return (
    <div className="w-full flex flex-col gap-8 pb-16">
      
      {/* Page Heading & Top Bar */}
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="gold-badge mb-1">Live Dealflow Directory</div>
            <h1 className="font-headline font-bold text-2xl sm:text-3xl lg:text-4xl text-[#1b1c1a]">
              Explore Innovative Startups
            </h1>
            <p className="text-xs sm:text-sm text-[#534343] mt-0.5">
              Discover, evaluate, and connect with patent-backed startup hardware and software projects.
            </p>
          </div>

          <button
            type="button"
            onClick={openSubmitModal}
            className="btn-burgundy text-xs py-2.5 px-4 shrink-0 shadow-sm self-start sm:self-auto flex items-center gap-1.5"
          >
            <span className="material-symbols-outlined text-[18px] text-[#d4af37]">add_circle</span>
            <span>Submit Your Startup</span>
          </button>
        </div>

        {/* Search Box with Search/Explore Button */}
        <div className="w-full bg-white border-2 border-[#e8d3b9] rounded-2xl p-2.5 shadow-xs flex flex-col sm:flex-row items-center gap-2">
          <div className="relative flex-1 w-full flex items-center">
            <span className="absolute left-3 text-[#b89358] material-symbols-outlined text-[22px]">
              search
            </span>
            <input
              type="text"
              value={searchInput}
              onChange={handleInputChange}
              onKeyDown={(e) => {
                if (e.key === 'Enter') triggerSearch();
              }}
              placeholder="Search by single letter (e.g. 'H'), word, sector, or keywords..."
              className="w-full pl-10 pr-10 py-2.5 bg-transparent text-xs sm:text-sm text-[#1b1c1a] focus:outline-none"
            />
            {searchInput && (
              <button
                type="button"
                onClick={() => {
                  setSearchInput('');
                  setActiveQuery('');
                }}
                className="absolute right-3 p-1 text-gray-400 hover:text-gray-600"
                title="Clear search"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={triggerSearch}
            className="btn-gold text-xs py-2.5 px-6 w-full sm:w-auto shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">search</span>
            <span>Search / Explore</span>
          </button>
        </div>
      </div>

      {/* Sector Filter Pills (Exactly 6 sectors + All) */}
      <div className="flex flex-col gap-2">
        <span className="text-[11px] font-bold uppercase tracking-wider text-[#6b5c47]">
          Filter by Sector (6 Sectors)
        </span>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setSelectedSector('All')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
              selectedSector === 'All'
                ? 'bg-[#561922] text-[#f7e7ce] border-[#d4af37] shadow-sm'
                : 'bg-white text-[#534343] border-[#e8d3b9] hover:bg-[#faf6f0]'
            }`}
          >
            All Sectors ({projects.length})
          </button>

          {sectors.map((sec) => {
            const count = projects.filter((p) => p.sector === sec).length;
            const isSelected = selectedSector === sec;
            return (
              <button
                key={sec}
                type="button"
                onClick={() => setSelectedSector(sec)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#561922] text-[#f7e7ce] border-[#d4af37] shadow-sm'
                    : 'bg-white text-[#534343] border-[#e8d3b9] hover:border-[#b89358] hover:bg-[#faf6f0]'
                }`}
              >
                <span>{sec}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? 'bg-[#d4af37] text-[#561922]' : 'bg-[#faf6f0] text-[#6b5c47]'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Stage Dropdown & Sorting Options Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#faf6f0] border-2 border-[#e8d3b9]">
        {/* Stage Filter Dropdown */}
        <div className="flex items-center gap-2 text-xs">
          <label htmlFor="stage-filter-select" className="font-bold text-[#1b1c1a] whitespace-nowrap">
            Project Stage:
          </label>
          <select
            id="stage-filter-select"
            value={selectedStage}
            onChange={(e) => setSelectedStage(e.target.value)}
            className="p-2 bg-white border border-[#e8d3b9] rounded-xl text-xs font-semibold text-[#1b1c1a] focus:outline-none focus:border-[#561922]"
          >
            <option value="All">All Stages</option>
            {stages.map((st) => (
              <option key={st} value={st}>{st}</option>
            ))}
          </select>
        </div>

        {/* Sorting Dropdown */}
        <div className="flex items-center gap-2 text-xs">
          <label htmlFor="sort-filter-select" className="font-bold text-[#1b1c1a] whitespace-nowrap">
            Sort By:
          </label>
          <select
            id="sort-filter-select"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="p-2 bg-white border border-[#e8d3b9] rounded-xl text-xs font-semibold text-[#1b1c1a] focus:outline-none focus:border-[#561922]"
          >
            <option value="highest_rated">Highest Rated</option>
            <option value="cost_low_to_high">Build Cost: Low to High</option>
            <option value="cost_high_to_low">Build Cost: High to Low</option>
            <option value="recently_published">Recently Published</option>
          </select>
        </div>

        {/* Results Counter */}
        <div className="text-xs text-[#6b5c47] font-semibold sm:text-right">
          Showing <strong>{filteredProjects.length}</strong> matching startups
          {activeQuery && (
            <span className="ml-1 text-[#561922] font-bold">
              for query: "{activeQuery}"
            </span>
          )}
        </div>
      </div>

      {/* Desktop 3-Column Project Cards Grid */}
      {filteredProjects.length === 0 ? (
        <div className="rounded-2xl border-2 border-dashed border-[#e8d3b9] p-12 text-center flex flex-col items-center gap-3 bg-white">
          <div className="w-14 h-14 rounded-full bg-[#faf6f0] border border-[#e8d3b9] text-[#b89358] flex items-center justify-center">
            <span className="material-symbols-outlined text-[30px]">travel_explore</span>
          </div>
          <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">No startups matched your filters</h3>
          <p className="text-xs text-[#534343] max-w-md">
            Try adjusting your search keywords, switching sector pills, or setting stage to "All Stages".
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchInput('');
              setActiveQuery('');
              setSelectedSector('All');
              setSelectedStage('All');
            }}
            className="btn-outline-gold text-xs py-2 px-4 mt-2"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => {
            return (
              /* Entire Project Card is Clickable to open Project Details */
              <div
                key={project.id}
                onClick={() => onSelectProject(project)}
                className="gloss-gold-card rounded-2xl flex flex-col justify-between overflow-hidden group hover:shadow-xl hover:border-[#d4af37] transition-all duration-200 border-2 border-[#e8d3b9] bg-white cursor-pointer select-none"
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') onSelectProject(project);
                }}
              >
                {/* Image & Badges Banner */}
                <div className="relative h-48 w-full overflow-hidden bg-[#2b060d]">
                  <img
                    src={project.image}
                    alt={project.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent"></div>

                  {/* Sector Badge (Top-Left) */}
                  <div className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#561922] text-[#f7e7ce] border border-[#d4af37] shadow-xs">
                    {highlightMatch(project.sector, activeQuery)}
                  </div>

                  {/* Stage Badge (Top-Right) */}
                  <div className="absolute top-3 right-3 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-white/95 text-[#1b1c1a] border border-[#e8d3b9] shadow-xs">
                    {project.stage}
                  </div>

                  {/* Build Cost Pill (Bottom-Left) */}
                  <div className="absolute bottom-3 left-3 px-2.5 py-1 rounded-lg bg-[#2b060d]/85 text-[#d4af37] border border-[#d4af37] text-xs font-extrabold backdrop-blur-xs">
                    Build Cost: {formatDisplayCost(project.buildCost)}
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-5 flex flex-col gap-3 flex-1 justify-between">
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-headline font-bold text-lg text-[#1b1c1a] group-hover:text-[#561922] transition-colors">
                        {highlightMatch(project.name, activeQuery)}
                      </h3>
                      {project.patentStatus === 'Granted Patent' && (
                        <span className="material-symbols-outlined text-[18px] text-emerald-600" title="Patent Granted">
                          verified
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-[#534343] line-clamp-2 leading-relaxed">
                      {highlightMatch(project.summary, activeQuery)}
                    </p>
                  </div>

                  {/* Rating & View Details indicator */}
                  <div className="pt-3 border-t border-[#e8d3b9] flex items-center justify-between mt-2">
                    <div className="flex items-center gap-1.5">
                      <div className="flex items-center">
                        {renderStarRating(project.rating || 4.5)}
                      </div>
                      <span className="text-xs font-bold text-[#1b1c1a]">
                        {(project.rating || 4.5).toFixed(1)}
                      </span>
                      <span className="text-[10px] text-[#6b5c47]">
                        ({project.reviewsCount || 1})
                      </span>
                    </div>

                    <span className="btn-burgundy text-xs py-1.5 px-3 shadow-2xs group-hover:bg-[#3c0b12] flex items-center gap-1">
                      <span>View Details</span>
                      <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}

window.ExploreProjects = ExploreProjects;
