/**
 * NEXUS VENTURE AI - Master Application Controller
 * Coordinates:
 * - 6 permanent navigation sections:
 *   1. Home ('home')
 *   2. Explore Projects ('explore')
 *   3. Submit Project ('submit' - Dedicated Full Page)
 *   4. Investor Profile ('investor')
 *   5. Ratings & Reviews ('ratings')
 *   6. Talk to Nexus Venture ('chatbot' - Dedicated Full Page)
 * - Header Login & Create Account frontend action buttons
 * - Completely removed floating chatbot widget
 * - Milestone escrow and modal state managers
 */

function App() {
  const { useState, useEffect } = React;

  // Active navigation tab
  const [activeTab, setActiveTab] = useState('home');

  // Core Data State from Database
  const [projects, setProjects] = useState([]);
  const [investors, setInvestors] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);

  // Modals state
  const [selectedProject, setSelectedProject] = useState(null);
  const [isIdeaModalOpen, setIsIdeaModalOpen] = useState(false);
  const [contactRecipient, setContactRecipient] = useState(null);
  const [authModalMode, setAuthModalMode] = useState(null); // 'login' | 'register' | null

  // Toast notifications
  const [toastMessage, setToastMessage] = useState(null);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Initial load from Database
  useEffect(() => {
    if (window.NexusDB) {
      setProjects(window.NexusDB.getProjects());
      setInvestors(window.NexusDB.getInvestors());
      setReviews(window.NexusDB.getAllReviews());
      setCurrentUser(window.NexusDB.getCurrentUser());
    }
  }, []);

  // Add review handler
  const handleAddReview = (projectId, reviewData) => {
    if (window.NexusDB) {
      const res = window.NexusDB.addReview(projectId, reviewData);
      if (res) {
        setProjects(window.NexusDB.getProjects());
        setReviews(window.NexusDB.getAllReviews());
        if (selectedProject && selectedProject.id === projectId) {
          setSelectedProject(window.NexusDB.getProjectById(projectId));
        }
        showToast('Review posted successfully! Recalculated average rating.');
      }
    }
  };

  // Project submitted handler
  const handleProjectSubmitted = (newProj) => {
    if (window.NexusDB) {
      setProjects(window.NexusDB.getProjects());
    }
    setActiveTab('explore');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    showToast(`"${newProj.name}" has been registered in the NEXUS VENTURE AI directory!`);
  };

  // Public Idea submitted handler
  const handleIdeaSubmitted = (newIdea) => {
    showToast(`Public idea "${newIdea.title}" submitted successfully!`);
  };

  // Investor profile update handler
  const handleUpdateInvestorProfile = (updatedData) => {
    if (window.NexusDB) {
      window.NexusDB.updateInvestorProfile(updatedData);
      setInvestors(window.NexusDB.getInvestors());
      showToast('Investor profile updated and saved to directory.');
    }
  };

  return (
    <div className="app-container">
      
      {/* Permanent Left Sidebar (Exactly 6 Menu Items) */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          const sidebar = document.getElementById('appSidebar');
          if (sidebar) sidebar.classList.remove('open');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        currentUser={currentUser}
      />

      {/* Main Content Area */}
      <div className="main-wrapper">
        
        {/* Horizontal Top Header with Login and Create Account frontend buttons */}
        <Header
          onLoginClick={() => setAuthModalMode('login')}
          onCreateAccountClick={() => setAuthModalMode('register')}
          onToggleMobileSidebar={() => {
            const sidebar = document.getElementById('appSidebar');
            if (sidebar) sidebar.classList.toggle('open');
          }}
        />

        {/* Global Toast Notification */}
        {toastMessage && (
          <div className="fixed top-20 right-6 z-50 p-4 bg-[#561922] text-[#f7e7ce] border-2 border-[#d4af37] rounded-2xl shadow-xl flex items-center gap-3 animate-slideInUp max-w-md">
            <span className="material-symbols-outlined text-[#d4af37] text-[24px]">verified</span>
            <span className="text-xs font-bold leading-relaxed">{toastMessage}</span>
          </div>
        )}

        {/* Frontend Auth Placeholder Modal (As requested: frontend buttons only, code provided later) */}
        {authModalMode && (
          <div className="modal-overlay" onClick={() => setAuthModalMode(null)}>
            <div className="modal-dialog max-w-md" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header-burgundy">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#d4af37] text-[22px]">
                    {authModalMode === 'login' ? 'login' : 'person_add'}
                  </span>
                  <h3 className="font-headline font-bold text-lg text-white">
                    {authModalMode === 'login' ? 'Member Login' : 'Create Account'}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setAuthModalMode(null)}
                  className="w-8 h-8 rounded-full bg-[#561922] text-white flex items-center justify-center border border-[#d4af37]"
                >
                  <span className="material-symbols-outlined text-[18px]">close</span>
                </button>
              </div>

              <div className="p-6 flex flex-col gap-4 text-center">
                <div className="w-14 h-14 rounded-full bg-[#faf6f0] border-2 border-[#d4af37] text-[#561922] flex items-center justify-center mx-auto">
                  <span className="material-symbols-outlined text-[28px]">lock_open</span>
                </div>
                <h4 className="font-headline font-bold text-base text-[#1b1c1a]">
                  {authModalMode === 'login' ? 'Investor & Founder Login Portal' : 'New Account Registration'}
                </h4>
                <p className="text-xs text-[#534343] leading-relaxed">
                  Frontend interface ready. Your custom authentication source code will be integrated here seamlessly once provided.
                </p>
                <button
                  type="button"
                  onClick={() => setAuthModalMode(null)}
                  className="btn-gold text-xs py-2.5 px-6 mx-auto mt-2"
                >
                  Close Window
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Routed Page Content */}
        <main className="p-4 sm:p-8 lg:p-10 max-w-7xl mx-auto w-full">
          {/* Tab 1: Home */}
          {activeTab === 'home' && (
            <HomePage
              onExploreClick={() => { setActiveTab('explore'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              onSubmitClick={() => { setActiveTab('submit'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              onOpenIdeaModal={() => setIsIdeaModalOpen(true)}
            />
          )}

          {/* Tab 2: Explore Projects */}
          {activeTab === 'explore' && (
            <ExploreProjects
              projects={projects}
              onSelectProject={(proj) => setSelectedProject(proj)}
              openSubmitModal={() => { setActiveTab('submit'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
            />
          )}

          {/* Tab 3: Dedicated Submit Project Page */}
          {activeTab === 'submit' && (
            <SubmitProjectPage
              onProjectSubmitted={handleProjectSubmitted}
              onCancel={() => { setActiveTab('explore'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              currentUser={currentUser}
            />
          )}

          {/* Tab 4: Investor Profile */}
          {activeTab === 'investor' && (
            <InvestorProfile
              investors={investors}
              currentUser={currentUser}
              onContactInvestor={(inv) => setContactRecipient(inv)}
              onUpdateProfile={handleUpdateInvestorProfile}
            />
          )}

          {/* Tab 5: Ratings & Reviews */}
          {activeTab === 'ratings' && (
            <RatingsReviews
              reviews={reviews}
              projects={projects}
              currentUser={currentUser}
              onSelectProject={(proj) => setSelectedProject(proj)}
              onAddReview={handleAddReview}
            />
          )}

          {/* Tab 6: Talk to Nexus Venture (Dedicated Chatbot Page) */}
          {activeTab === 'chatbot' && (
            <ChatbotPage
              onNavigateExplore={() => { setActiveTab('explore'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              onOpenSubmit={() => { setActiveTab('submit'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
            />
          )}
        </main>

        {/* Modals */}
        {selectedProject && (
          <ProjectModal
            project={selectedProject}
            onClose={() => setSelectedProject(null)}
            onAddReview={handleAddReview}
          />
        )}

        {isIdeaModalOpen && (
          <IdeaModal
            isOpen={isIdeaModalOpen}
            onClose={() => setIsIdeaModalOpen(false)}
            onIdeaSubmitted={handleIdeaSubmitted}
          />
        )}

        {contactRecipient && (
          <ContactModal
            recipient={contactRecipient}
            currentUser={currentUser}
            onClose={() => setContactRecipient(null)}
          />
        )}

      </div>
    </div>
  );
}

// Immediate mount helper that handles both pre-load and post-load scenarios
function mountNexusApp() {
  const rootElement = document.getElementById('root');
  if (rootElement && window.ReactDOM && window.React) {
    try {
      const root = ReactDOM.createRoot(rootElement);
      root.render(React.createElement(App));
      console.log('NEXUS VENTURE AI mounted successfully!');
    } catch (err) {
      console.error('Mount error:', err);
      rootElement.innerHTML = '<div style="color:#f7e7ce;background:#561922;padding:2rem;border:2px solid #d4af37;border-radius:1rem;margin:2rem auto;max-width:600px;font-family:sans-serif;">' +
        '<h2 style="color:#d4af37;font-size:1.5rem;margin-bottom:0.5rem;">Application Mount Error</h2>' +
        '<p style="font-size:0.9rem;">' + err.message + '</p>' +
        '<pre style="background:#3c0b12;padding:1rem;border-radius:0.5rem;margin-top:1rem;font-size:0.8rem;overflow:auto;">' + err.stack + '</pre>' +
      '</div>';
    }
  }
}

// Ensure execution regardless of when Babel completes transpilation
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', mountNexusApp);
} else {
  mountNexusApp();
}
