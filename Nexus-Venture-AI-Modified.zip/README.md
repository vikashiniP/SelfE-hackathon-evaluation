# NEXUS VENTURE AI

> **Where Innovation Meets Investment**  
> An intermediate deeptech platform connecting Startup Developers, Accredited Investors, and the General Public under sovereign milestone escrow governance.

---

## 🏛️ Luxury Two-Tone Design System

This platform is crafted with a distinctive luxury color palette inspired by prestigious academic and private venture institutions:

- **Rich Burgundy / Deep Maroon:**
  - Darkest Maroon: `#2b060d`
  - Dark Burgundy: `#3c0b12`
  - Deep Burgundy: `#561922`
  - Main Burgundy: `#722f37`
- **Glossy Champagne Gold:**
  - Champagne Gold: `#d4af37`
  - Glossy Accent: `#e5c158`
  - Metallic Gold: `#b89358`
  - Light Champagne: `#f7e7ce`

Both colors are applied as distinct, unblended luxury tones without arbitrary gradients.

---

## 📂 Source Code Structure

All files and components are modularly organized:

```
nexus-venture-ai/
│
├── index.html                   # Main modular application entrypoint (GitHub & Vercel ready)
├── standalone.html              # Self-contained offline bundle (double-click to run anywhere)
├── vercel.json                  # Vercel zero-configuration production routing
├── package.json                 # Repository & npm metadata
├── .gitignore                   # Standard ignore rules
├── README.md                    # Project documentation
│
├── css/
│   └── luxury-theme.css         # Complete custom luxury design styles & variables
│
├── js/
│   ├── app.js                   # Application state router, drawer & modal controller
│   ├── database.js              # Mock database, initial seed data & localStorage sync
│   ├── chatbot.js               # Nexus Venture AI intelligent advisor
│   │
│   └── components/
│       ├── Header.js            # Top bar navigation, live wallet balance, auth buttons
│       ├── Sidebar.js           # Navigation drawer with investor/developer portal links
│       ├── HomePage.js          # Hero, featured startups, metrics & how-it-works
│       ├── ExploreProjects.js   # Filterable startup directory & milestone inspector
│       ├── ProjectModal.js      # Startup detailed investment modal & milestone escrow
│       ├── SubmitProjectModal.js# Multi-step startup funding submission form
│       ├── InvestorProfile.js   # Portfolio tracker, investment returns & transaction log
│       ├── RatingsReviews.js    # Community rating, reviews, & feedback engine
│       ├── IdeaModal.js         # Public concept submission modal
│       ├── ContactModal.js      # Founder & team contact modal
│       ├── LoginPage.js         # Integrated luxury login & registration component
│       └── NetworkIllustration.js # Dynamic venture network visual component
│
└── src/
    └── components/
        └── LoginPage.jsx        # Original React JSX source code for LoginPage
```

---

## 🚀 How to Run Locally

### Option 1: Double-Click (Zero Server Required)
Simply double-click `standalone.html` in your file browser. It opens immediately in any web browser without needing a web server.

### Option 2: Local HTTP Server
Run any local server from this directory:

```bash
# Using Python
python -m http.server 3000

# Using Node / npx
npx serve .
```
Then visit: `http://localhost:3000`

---

## ☁️ Deploy to Vercel (1-Click)

### Via Vercel Web Dashboard:
1. Go to [vercel.com/new](https://vercel.com/new).
2. Drag and drop this folder onto the page.
3. Framework Preset: **Other** (Root directory: `./`).
4. Click **Deploy**.

### Via GitHub:
1. Push this folder to your GitHub repository.
2. Import the repository into Vercel.
3. Deploy!

