/**
 * NEXUS VENTURE AI - Integrated Official Login & Registration Page
 * Preserves 100% of original logic, fields, validation, demo logins, and modals.
 * Enhanced with the luxury Rich Burgundy & Glossy Champagne Gold design system.
 */

function LoginPage({ onLogin, setActiveTab, currentRole, toggleRole }) {
  const { useState, useEffect, useId } = React;

  // Navigation flow: 'login' | 'register'
  const [mode, setMode] = useState('login');

  // Selected Account Type: 'startup' | 'investor' | 'public'
  const [accountType, setAccountType] = useState(
    currentRole === 'developer' || currentRole === 'Startup Developer'
      ? 'startup'
      : currentRole === 'investor' || currentRole === 'Investor'
      ? 'investor'
      : currentRole === 'public' || currentRole === 'Public'
      ? 'public'
      : 'startup'
  );

  // Form State - preserved across account type switches
  const [formData, setFormData] = useState({
    // Common fields
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    country: 'India',
    city: '',
    website: '',

    // Startup-specific fields
    companyName: '',
    industry: 'AI & Autonomous Systems',
    startupStage: 'Seed (Working Prototype / TRL 5-7)',
    contactRole: 'Founder & CEO',

    // Investor-specific fields
    firmName: '',
    investorType: 'Venture Capital (VC)',
    profileUrl: '',
  });

  // UI state
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [termsAgreed, setTermsAgreed] = useState(false);
  
  // Validation & status state
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [typeSwitchToast, setTypeSwitchToast] = useState(null);

  // Modals state
  const [forgotModalOpen, setForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSubmitted, setForgotSubmitted] = useState(false);
  const [termsModalOpen, setTermsModalOpen] = useState(false);
  const [privacyModalOpen, setPrivacyModalOpen] = useState(false);

  // Unique IDs for accessibility
  const emailId = 'login_email_input';
  const passwordId = 'login_pass_input';
  const confirmPasswordId = 'login_conf_pass_input';
  const nameId = 'login_name_input';
  const phoneId = 'login_phone_input';
  const companyId = 'login_company_input';
  const websiteId = 'login_web_input';
  const cityId = 'login_city_input';
  const countryId = 'login_country_input';
  const industryId = 'login_ind_input';
  const stageId = 'login_stage_input';
  const roleId = 'login_role_input';
  const firmId = 'login_firm_input';
  const investorTypeId = 'login_inv_type_input';
  const profileUrlId = 'login_prof_url_input';
  const termsId = 'login_terms_check';
  const rememberId = 'login_rem_check';

  // Account Type Definitions
  const accountTypeDefinitions = {
    startup: {
      id: 'startup',
      title: 'Startup',
      badge: 'Founders & R&D',
      headline: 'DeepTech Founders & Innovators',
      description: 'Raise capital from verified angels & VCs with smart milestone escrow, BOM tracking, and patent priority protection.',
      icon: 'rocket_launch',
      pillBg: 'bg-[#ffdadb]/70',
      pillText: 'text-[#722f37]',
      landingTab: 'explore',
      landingLabel: 'Explore Dealflow & Submit Project',
      defaultEmailPlaceholder: 'founder@deeptech.io',
      demoUser: {
        name: 'Dr. Siddharth Verma',
        email: 'siddharth@aeropulse.health',
        role: 'Startup Developer',
        accountType: 'startup',
        accountTypeLabel: 'Founders & R&D',
        organization: 'AeroPulse MedTech Inc. (Founder & CEO)',
        avatar: null,
      }
    },
    investor: {
      id: 'investor',
      title: 'Investor',
      badge: 'Allocators & LPs',
      headline: 'Institutional VCs & Angels',
      description: 'Access pre-audited deeptech dealflow, technical milestone audits, and deploy syndicate capital under smart escrow safety.',
      icon: 'account_balance',
      pillBg: 'bg-[#f2dcc2]/70',
      pillText: 'text-[#561922]',
      landingTab: 'investor',
      landingLabel: 'Investor Portfolio & Deal Room',
      defaultEmailPlaceholder: 'partner@venturefund.com',
      demoUser: {
        name: 'Dr. Ananya Sen',
        email: 'ananya.sen@aethelangels.vc',
        role: 'Investor',
        accountType: 'investor',
        accountTypeLabel: 'Allocators & LPs',
        organization: 'Aethel MedTech Angels Lead',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80',
      }
    },
    public: {
      id: 'public',
      title: 'Public',
      badge: 'Community & Observers',
      headline: 'Researchers, Talent & Observers',
      description: 'Explore verified deeptech innovations, review milestone releases, track public peer audits, and submit institutional reviews.',
      icon: 'public',
      pillBg: 'bg-[#faf6f0]',
      pillText: 'text-[#534343]',
      landingTab: 'home',
      landingLabel: 'Public Innovation Showcase',
      defaultEmailPlaceholder: 'alex.chen@research.edu',
      demoUser: {
        name: 'Elena Rostova',
        email: 'elena.rostova@stanford.edu',
        role: 'Public',
        accountType: 'public',
        accountTypeLabel: 'Community & Observers',
        organization: 'Stanford Biodesign Research Lab',
        avatar: null,
      }
    }
  };

  const currentTypeMeta = accountTypeDefinitions[accountType];

  // Account switching handler
  const handleAccountTypeChange = (newType) => {
    if (newType === accountType) return;
    setAccountType(newType);
    setErrors({});
    setTypeSwitchToast(`Switched to ${accountTypeDefinitions[newType].title} flow. Your shared details have been preserved.`);
    setTimeout(() => {
      setTypeSwitchToast(null);
    }, 4000);
  };

  // Form field changes
  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value
    }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  // Password criteria computation
  const passwordCriteria = {
    length: formData.password.length >= 8,
    hasUpper: /[A-Z]/.test(formData.password),
    hasNumberOrSymbol: /[0-9!@#$%^&*(),.?":{}|<>]/.test(formData.password),
    matches: mode === 'register' ? (formData.password && formData.password === formData.confirmPassword) : true,
  };

  const getPasswordStrengthScore = () => {
    let score = 0;
    if (formData.password.length >= 8) score++;
    if (formData.password.length >= 12) score++;
    if (passwordCriteria.hasUpper) score++;
    if (passwordCriteria.hasNumberOrSymbol) score++;
    return score;
  };

  // Form validation
  const validateForm = () => {
    const newErrors = {};

    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      newErrors.email = 'Please enter a valid email format (e.g. name@domain.com).';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required.';
    } else if (mode === 'register' && formData.password.length < 8) {
      newErrors.password = 'Password must contain at least 8 characters.';
    }

    if (mode === 'register') {
      if (!formData.fullName.trim()) {
        newErrors.fullName = 'Full name is required.';
      }

      if (!formData.confirmPassword) {
        newErrors.confirmPassword = 'Confirmation password is required.';
      } else if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match.';
      }

      if (!termsAgreed) {
        newErrors.terms = 'You must agree to the Terms of Service & Privacy Policy.';
      }

      if (accountType === 'startup') {
        if (!formData.companyName.trim()) {
          newErrors.companyName = 'Company / Startup name is required.';
        }
        if (!formData.city.trim()) {
          newErrors.city = 'City is required.';
        }
        if (!formData.country.trim()) {
          newErrors.country = 'Country is required.';
        }
        if (!formData.industry) {
          newErrors.industry = 'Industry selection is required.';
        }
        if (!formData.startupStage) {
          newErrors.startupStage = 'Startup stage is required.';
        }
        if (!formData.contactRole.trim()) {
          newErrors.contactRole = 'Your role in the startup is required.';
        }
      }

      if (accountType === 'investor') {
        if (!formData.investorType) {
          newErrors.investorType = 'Investor type is required.';
        }
        if (!formData.city.trim()) {
          newErrors.city = 'City is required.';
        }
        if (!formData.country.trim()) {
          newErrors.country = 'Country is required.';
        }
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Form submit handler
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);

      const targetTab = currentTypeMeta.landingTab;
      const targetRole = accountType === 'startup' ? 'Startup Developer' : accountType === 'investor' ? 'Investor' : 'Public';

      const userObj = {
        name: formData.fullName.trim() || (accountType === 'startup' ? 'DeepTech Founder' : accountType === 'investor' ? 'Accredited Investor' : 'Community Member'),
        email: formData.email.trim(),
        role: targetRole,
        accountType: accountType,
        accountTypeLabel: currentTypeMeta.badge,
        organization: accountType === 'startup' 
          ? formData.companyName || 'Emerging Startup Node'
          : accountType === 'investor' 
            ? formData.firmName || 'Independent Venture Syndicate'
            : 'Public Research & Innovation Network',
        phone: formData.phone || null,
        city: formData.city || null,
        country: formData.country || null,
        website: formData.website || formData.profileUrl || null,
        industry: formData.industry || null,
        stage: formData.startupStage || null,
        investorType: formData.investorType || null,
        avatar: null,
        isLoggedIn: true
      };

      if (toggleRole) toggleRole(targetRole);
      if (onLogin) onLogin(userObj);
      if (setActiveTab) setActiveTab(targetTab);
    }, 600);
  };

  // One-click demo login helper
  const handleDemoLogin = (typeKey) => {
    const demo = accountTypeDefinitions[typeKey].demoUser;
    const targetTab = accountTypeDefinitions[typeKey].landingTab;
    const targetRole = demo.role;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      const user = { ...demo, isLoggedIn: true };
      if (toggleRole) toggleRole(targetRole);
      if (onLogin) onLogin(user);
      if (setActiveTab) setActiveTab(targetTab);
    }, 400);
  };

  // Google OAuth Simulation
  const handleGoogleSignIn = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      const googleUser = {
        name: accountType === 'startup' ? 'Alex Rivera (Founder)' : accountType === 'investor' ? 'Victoria Vance (Angel)' : 'Jordan Taylor (Public)',
        email: `google.user@${accountType}.verified`,
        role: accountType === 'startup' ? 'Startup Developer' : accountType === 'investor' ? 'Investor' : 'Public',
        accountType: accountType,
        accountTypeLabel: currentTypeMeta.badge,
        organization: accountType === 'startup' ? 'Rivera AI Robotics' : accountType === 'investor' ? 'Frontier Syndicate LP' : 'Open Science Lab',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
        isLoggedIn: true
      };

      if (toggleRole) toggleRole(googleUser.role);
      if (onLogin) onLogin(googleUser);
      if (setActiveTab) setActiveTab(currentTypeMeta.landingTab);
    }, 500);
  };

  // Password reset submit
  const handleForgotSubmit = (e) => {
    e.preventDefault();
    if (!forgotEmail) return;
    setForgotSubmitted(true);
    setTimeout(() => {
      setForgotSubmitted(false);
      setForgotModalOpen(false);
      setForgotEmail('');
    }, 3000);
  };

  const countriesList = [
    'India',
    'United States',
    'United Kingdom',
    'Germany',
    'Singapore',
    'Canada',
    'France',
    'Japan',
    'Australia',
    'Switzerland',
    'Israel',
    'United Arab Emirates',
    'Other'
  ];

  const industriesList = [
    'AI & Autonomous Systems',
    'Healthcare & MedTech IoT',
    'ClimateTech & Clean Energy',
    'Robotics & Hardware Engineering',
    'FinTech & Smart Escrow',
    'Quantum Computing & Cryptography',
    'Aerospace & Defense Technologies',
    'Biotechnology & Genomic Sciences',
    'Agriculture & Precision Agronomy',
    'Education & Immersive Learning'
  ];

  const stagesList = [
    'Idea / Concept',
    'MVP / Early Product',
    'Full Project Ready',
    'Field Tested with Users'
  ];

  const rolesList = [
    'Founder & CEO',
    'Co-Founder & CTO',
    'Lead Hardware / Embedded Engineer',
    'Chief Scientific Officer (CSO)',
    'Lead Software / AI Architect',
    'Student Researcher / Innovator'
  ];

  const investorTypesList = [
    'Venture Capital (VC)',
    'Angel Investor / Syndicate Lead',
    'Family Office',
    'Corporate Venture Capital (CVC)',
    'Sovereign Wealth / Institutional LP',
    'DeepTech Accelerator / Incubator'
  ];

  return (
    <div className="w-full max-w-7xl mx-auto py-6 sm:py-8 px-4 sm:px-6 lg:px-8 flex flex-col gap-7 transition-all">
      
      {/* Top Breadcrumb & Flow Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b-2 border-[#e8d3b9]">
        <div className="flex items-center gap-3">
          <div 
            onClick={() => setActiveTab && setActiveTab('home')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-full bg-[#561922] text-[#f7e7ce] flex items-center justify-center shadow-md border-2 border-[#d4af37] group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[22px]">policy</span>
            </div>
            <div>
              <span className="font-headline font-bold text-2xl text-[#561922] tracking-tight group-hover:text-[#722f37] transition-colors">
                NEXUS VENTURE AI
              </span>
              <span className="block text-[11px] text-[#b89358] font-bold uppercase tracking-wider">
                Sovereign DeepTech & Capital Protocol
              </span>
            </div>
          </div>
        </div>

        {/* Global Flow Mode Switcher: Log In vs Create Account */}
        <div className="flex items-center justify-between sm:justify-end gap-3">
          <div 
            role="tablist" 
            aria-label="Authentication Flow Selection"
            className="inline-flex p-1 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-2xl shadow-inner"
          >
            <button
              role="tab"
              aria-selected={mode === 'login'}
              onClick={() => { setMode('login'); setErrors({}); }}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
                mode === 'login'
                  ? 'bg-[#561922] text-[#f7e7ce] border border-[#d4af37] shadow-sm'
                  : 'text-[#534343] hover:text-[#1b1c1a]'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">login</span>
              <span>Log in</span>
            </button>
            <button
              role="tab"
              aria-selected={mode === 'register'}
              onClick={() => { setMode('register'); setErrors({}); }}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
                mode === 'register'
                  ? 'bg-[#561922] text-[#f7e7ce] border border-[#d4af37] shadow-sm'
                  : 'text-[#534343] hover:text-[#1b1c1a]'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">person_add</span>
              <span>Create an account</span>
            </button>
          </div>
        </div>
      </div>

      {/* Account Type Selection Header & Explanation Cards */}
      <section className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#f7e7ce] text-[#561922] border border-[#d4af37] text-[11px] font-bold uppercase tracking-wider">
              <span>Step 1</span>
              <span>•</span>
              <span>Select Your Persona</span>
            </div>
            <h1 className="font-headline font-bold text-2xl sm:text-3xl text-[#1b1c1a] mt-2">
              Choose your account type
            </h1>
            <p className="text-xs sm:text-sm text-[#534343] max-w-2xl mt-1">
              Select how you intend to participate on NEXUS VENTURE AI. Each persona is calibrated to its workflow requirements. You can switch personas at any time without losing entered details.
            </p>
          </div>

          {/* Quick Active Type Pill */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-white border-2 border-[#e8d3b9] shadow-xs">
            <span className="text-xs text-[#6b5c47] font-medium">Active Type:</span>
            <span className="px-2.5 py-0.5 rounded-md text-xs font-bold bg-[#561922] text-[#f7e7ce] border border-[#d4af37]">
              {currentTypeMeta.title}
            </span>
          </div>
        </div>

        {/* The 3 Account Type Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4" role="radiogroup" aria-label="Account Types">
          {Object.values(accountTypeDefinitions).map((type) => {
            const isSelected = accountType === type.id;
            return (
              <div
                key={type.id}
                role="radio"
                aria-checked={isSelected}
                tabIndex={0}
                onClick={() => handleAccountTypeChange(type.id)}
                className={`relative rounded-2xl p-5 border-2 transition-all cursor-pointer flex flex-col justify-between gap-3 text-left group ${
                  isSelected
                    ? 'bg-white border-[#561922] shadow-md ring-4 ring-[#722f37]/15'
                    : 'bg-[#faf6f0] border-[#e8d3b9] hover:border-[#b89358] hover:bg-white'
                }`}
              >
                {/* Active checkmark badge */}
                {isSelected && (
                  <div className="absolute top-4 right-4 w-6 h-6 rounded-full bg-[#561922] text-[#d4af37] border border-[#d4af37] flex items-center justify-center shadow-xs">
                    <span className="material-symbols-outlined text-[16px]">check</span>
                  </div>
                )}

                <div className="flex flex-col gap-2.5">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center transition-transform group-hover:scale-105 border ${
                      isSelected
                        ? 'bg-[#561922] text-[#d4af37] border-[#d4af37] shadow-sm'
                        : 'bg-[#f7e7ce] text-[#561922] border-[#e8d3b9]'
                    }`}>
                      <span className="material-symbols-outlined text-[24px]">{type.icon}</span>
                    </div>

                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="font-headline font-bold text-lg text-[#1b1c1a]">
                          {type.title}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border border-[#e8d3b9] ${type.pillBg} ${type.pillText}`}>
                          {type.badge}
                        </span>
                      </div>
                      <span className="text-[11px] font-semibold text-[#b89358]">
                        {type.headline}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-[#534343] leading-relaxed">
                    {type.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-[#e8d3b9] flex items-center justify-between text-[11px]">
                  <span className="text-[#6b5c47] font-medium">After login directs to:</span>
                  <span className="font-bold text-[#561922] flex items-center gap-0.5">
                    <span>{type.landingLabel}</span>
                    <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Gentle Type Switching Data-Loss-Prevention Toast */}
        {typeSwitchToast && (
          <div className="p-3 bg-[#faf6f0] border-2 border-[#b89358] rounded-xl flex items-center gap-2 text-xs text-[#561922] shadow-xs">
            <span className="material-symbols-outlined text-[#b89358] text-[20px]">verified</span>
            <span className="font-bold">{typeSwitchToast}</span>
          </div>
        )}
      </section>

      {/* Main Dual-Column Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Interactive Network Illustration & Platform Assurance */}
        <div className="lg:col-span-5 flex flex-col gap-5 order-2 lg:order-1">
          <NetworkIllustration activeAccountType={accountType} />

          {/* Institutional Trust & Zero Financial Data Reassurance Card */}
          <div className="bg-white border-2 border-[#e8d3b9] rounded-2xl p-5 shadow-xs flex flex-col gap-3">
            <div className="flex items-center gap-2 text-[#561922]">
              <span className="material-symbols-outlined text-[22px] text-[#d4af37]">verified_user</span>
              <h3 className="font-headline font-bold text-base text-[#1b1c1a]">
                Sovereign Trust & Escrow Guarantee
              </h3>
            </div>

            <p className="text-xs text-[#534343] leading-relaxed">
              NEXUS VENTURE AI connects patent-backed hardware & deeptech innovators with institutional capital. 
              <strong> We never request bank accounts, credit cards, or sensitive net-worth figures during initial registration.</strong> You can explore and collaborate right away.
            </p>

            <div className="grid grid-cols-2 gap-2 pt-2 text-[11px] text-[#534343] border-t border-[#e8d3b9]">
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
                <span>Zero financial disclosure at signup</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
                <span>Patent Priority Sealed</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
                <span>Smart Escrow Ledger</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-emerald-600 text-[16px]">check_circle</span>
                <span>AES-256 Vault Architecture</span>
              </div>
            </div>
          </div>

          {/* Quick Demo Logins Widget */}
          <div className="bg-[#faf6f0] border-2 border-[#d4af37] rounded-2xl p-5 shadow-xs flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-[#561922] flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-[#d4af37]">bolt</span>
                <span>1-Click Instant Demo Logins</span>
              </span>
              <span className="text-[10px] text-[#6b5c47] font-semibold bg-white px-2 py-0.5 rounded border border-[#e8d3b9]">Instant Sandbox</span>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => handleDemoLogin('startup')}
                disabled={isSubmitting}
                className="p-2.5 rounded-xl bg-white hover:bg-[#ffdadb]/40 border-2 border-[#e8d3b9] hover:border-[#561922] text-[11px] font-bold text-[#561922] flex flex-col items-center gap-1 transition-all active:scale-95 shadow-xs"
                title="Log in as Dr. Siddharth Verma (AeroPulse Founder)"
              >
                <span className="material-symbols-outlined text-[18px]">rocket_launch</span>
                <span>Startup Demo</span>
              </button>

              <button
                type="button"
                onClick={() => handleDemoLogin('investor')}
                disabled={isSubmitting}
                className="p-2.5 rounded-xl bg-white hover:bg-[#f7e7ce] border-2 border-[#e8d3b9] hover:border-[#b89358] text-[11px] font-bold text-[#561922] flex flex-col items-center gap-1 transition-all active:scale-95 shadow-xs"
                title="Log in as Dr. Ananya Sen (Lead Syndicate Partner)"
              >
                <span className="material-symbols-outlined text-[18px]">account_balance</span>
                <span>Investor Demo</span>
              </button>

              <button
                type="button"
                onClick={() => handleDemoLogin('public')}
                disabled={isSubmitting}
                className="p-2.5 rounded-xl bg-white hover:bg-[#efeeeb] border-2 border-[#e8d3b9] text-[11px] font-bold text-[#534343] flex flex-col items-center gap-1 transition-all active:scale-95 shadow-xs"
                title="Log in as Elena Rostova (Stanford Research Member)"
              >
                <span className="material-symbols-outlined text-[18px]">public</span>
                <span>Public Demo</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Authentication Card */}
        <div className="lg:col-span-7 bg-white border-2 border-[#e8d3b9] rounded-3xl p-6 sm:p-9 shadow-sm flex flex-col gap-6 order-1 lg:order-2">
          
          {/* Card Header */}
          <div className="flex flex-col gap-1.5 pb-4 border-b-2 border-[#e8d3b9]">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#561922]"></span>
                <span className="text-xs font-bold text-[#561922] uppercase tracking-wider">
                  {mode === 'login' ? 'Authentication Gate' : 'Registration Protocol'}
                </span>
              </div>

              <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#faf6f0] text-[#561922] border border-[#d4af37]">
                Persona: {currentTypeMeta.title}
              </span>
            </div>

            <h2 className="font-headline font-bold text-2xl sm:text-3xl text-[#1b1c1a] mt-1">
              {mode === 'login' ? `Log in as ${currentTypeMeta.title}` : `Create a ${currentTypeMeta.title} Account`}
            </h2>

            <p className="text-xs sm:text-sm text-[#534343]">
              {mode === 'login'
                ? `Enter your security credentials to access your ${currentTypeMeta.title.toLowerCase()} workspace.`
                : accountType === 'public'
                  ? 'Quick 45-second signup open to individuals, students, researchers, and tech observers.'
                  : `Complete your ${currentTypeMeta.title.toLowerCase()} registration. Clearly marked required (*) and optional fields.`}
            </p>
          </div>

          {/* Social Sign-in Button (Google SSO) */}
          <div className="flex flex-col gap-2">
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isSubmitting}
              className="w-full py-3 px-4 bg-white hover:bg-[#faf6f0] border-2 border-[#e8d3b9] hover:border-[#b89358] rounded-xl text-xs sm:text-sm font-bold text-[#1b1c1a] flex items-center justify-center gap-3 transition-all shadow-xs focus:ring-2 focus:ring-[#561922]"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Continue with Google</span>
            </button>

            <div className="flex items-center my-2">
              <div className="flex-1 border-t-2 border-[#e8d3b9]"></div>
              <span className="px-3 text-xs text-[#867273] font-bold uppercase tracking-wider">or continue with email</span>
              <div className="flex-1 border-t-2 border-[#e8d3b9]"></div>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
            
            {/* ===================== REGISTRATION ONLY FIELDS ===================== */}
            {mode === 'register' && (
              <>
                {/* 1. Full Name */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <label htmlFor={nameId} className="text-xs font-bold text-[#1b1c1a]">
                      {accountType === 'startup' ? 'Founder / Primary Contact Full Name' : 'Full Name'}
                      <span className="text-[#ba1a1a] ml-1" aria-hidden="true">*</span>
                    </label>
                    <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
                  </div>
                  <input
                    id={nameId}
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => handleInputChange('fullName', e.target.value)}
                    placeholder={accountType === 'startup' ? 'Dr. Siddharth Verma' : accountType === 'investor' ? 'Dr. Ananya Sen' : 'Elena Rostova'}
                    className={`p-3 bg-[#faf6f0] border-2 rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922] transition-all ${
                      errors.fullName ? 'border-red-500 bg-red-50/40' : 'border-[#e8d3b9]'
                    }`}
                  />
                  {errors.fullName && (
                    <p className="text-[11px] text-[#ba1a1a] flex items-center gap-1">
                      <span className="material-symbols-outlined text-[14px]">error</span>
                      <span>{errors.fullName}</span>
                    </p>
                  )}
                </div>

                {/* 2. Startup-Specific: Company Name & Role */}
                {accountType === 'startup' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center justify-between">
                        <label htmlFor={companyId} className="text-xs font-bold text-[#1b1c1a]">
                          Company Name <span className="text-[#ba1a1a]">*</span>
                        </label>
                        <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
                      </div>
                      <input
                        id={companyId}
                        type="text"
                        required
                        value={formData.companyName}
                        onChange={(e) => handleInputChange('companyName', e.target.value)}
                        placeholder="AeroPulse MedTech Inc."
                        className={`p-3 bg-[#faf6f0] border-2 rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922] transition-all ${
                          errors.companyName ? 'border-red-500 bg-red-50/40' : 'border-[#e8d3b9]'
                        }`}
                      />
                      {errors.companyName && (
                        <p className="text-[11px] text-[#ba1a1a]">{errors.companyName}</p>
                      )}
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center justify-between">
                        <label htmlFor={roleId} className="text-xs font-bold text-[#1b1c1a]">
                          Contact’s Role <span className="text-[#ba1a1a]">*</span>
                        </label>
                        <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
                      </div>
                      <select
                        id={roleId}
                        value={formData.contactRole}
                        onChange={(e) => handleInputChange('contactRole', e.target.value)}
                        className="p-3 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                      >
                        {rolesList.map((r) => (
                          <option key={r} value={r}>{r}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}

                {/* 3. Investor-Specific: Firm/Org Name & Investor Type */}
                {accountType === 'investor' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center justify-between">
                        <label htmlFor={firmId} className="text-xs font-bold text-[#1b1c1a]">
                          Firm or Organization Name
                        </label>
                        <span className="text-[10px] text-[#6b5c47] font-semibold uppercase tracking-wider">(optional)</span>
                      </div>
                      <input
                        id={firmId}
                        type="text"
                        value={formData.firmName}
                        onChange={(e) => handleInputChange('firmName', e.target.value)}
                        placeholder="Aethel MedTech Angels / Apex VC"
                        className="p-3 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center justify-between">
                        <label htmlFor={investorTypeId} className="text-xs font-bold text-[#1b1c1a]">
                          Investor Type <span className="text-[#ba1a1a]">*</span>
                        </label>
                        <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
                      </div>
                      <select
                        id={investorTypeId}
                        value={formData.investorType}
                        onChange={(e) => handleInputChange('investorType', e.target.value)}
                        className="p-3 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                      >
                        {investorTypesList.map((t) => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}

                {/* 4. Startup-Specific: Industry & Stage */}
                {accountType === 'startup' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center justify-between">
                        <label htmlFor={industryId} className="text-xs font-bold text-[#1b1c1a]">
                          Industry / Domain <span className="text-[#ba1a1a]">*</span>
                        </label>
                        <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
                      </div>
                      <select
                        id={industryId}
                        value={formData.industry}
                        onChange={(e) => handleInputChange('industry', e.target.value)}
                        className="p-3 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                      >
                        {industriesList.map((ind) => (
                          <option key={ind} value={ind}>{ind}</option>
                        ))}
                      </select>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center justify-between">
                        <label htmlFor={stageId} className="text-xs font-bold text-[#1b1c1a]">
                          Startup Stage <span className="text-[#ba1a1a]">*</span>
                        </label>
                        <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
                      </div>
                      <select
                        id={stageId}
                        value={formData.startupStage}
                        onChange={(e) => handleInputChange('startupStage', e.target.value)}
                        className="p-3 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                      >
                        {stagesList.map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}

                {/* 5. Geographic Fields: Country & City */}
                {(accountType === 'startup' || accountType === 'investor') && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center justify-between">
                        <label htmlFor={countryId} className="text-xs font-bold text-[#1b1c1a]">
                          Country <span className="text-[#ba1a1a]">*</span>
                        </label>
                        <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
                      </div>
                      <select
                        id={countryId}
                        value={formData.country}
                        onChange={(e) => handleInputChange('country', e.target.value)}
                        className="p-3 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                      >
                        {countriesList.map((c) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center justify-between">
                        <label htmlFor={cityId} className="text-xs font-bold text-[#1b1c1a]">
                          City <span className="text-[#ba1a1a]">*</span>
                        </label>
                        <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
                      </div>
                      <input
                        id={cityId}
                        type="text"
                        required
                        value={formData.city}
                        onChange={(e) => handleInputChange('city', e.target.value)}
                        placeholder="e.g. Bengaluru, Mumbai, Delhi, Boston"
                        className={`p-3 bg-[#faf6f0] border-2 rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922] transition-all ${
                          errors.city ? 'border-red-500 bg-red-50/40' : 'border-[#e8d3b9]'
                        }`}
                      />
                      {errors.city && (
                        <p className="text-[11px] text-[#ba1a1a]">{errors.city}</p>
                      )}
                    </div>
                  </div>
                )}

                {/* 6. Optional Links */}
                {accountType === 'startup' && (
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center justify-between">
                      <label htmlFor={websiteId} className="text-xs font-bold text-[#1b1c1a]">
                        Company Website
                      </label>
                      <span className="text-[10px] text-[#6b5c47] font-semibold uppercase tracking-wider">(optional)</span>
                    </div>
                    <div className="relative flex items-center">
                      <span className="absolute left-3 text-[#b89358] material-symbols-outlined text-[18px]">
                        link
                      </span>
                      <input
                        id={websiteId}
                        type="url"
                        value={formData.website}
                        onChange={(e) => handleInputChange('website', e.target.value)}
                        placeholder="https://aeropulse.health"
                        className="w-full p-3 pl-10 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                      />
                    </div>
                  </div>
                )}

                {accountType === 'investor' && (
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center justify-between">
                      <label htmlFor={profileUrlId} className="text-xs font-bold text-[#1b1c1a]">
                        Website or Professional Profile
                      </label>
                      <span className="text-[10px] text-[#6b5c47] font-semibold uppercase tracking-wider">(optional)</span>
                    </div>
                    <div className="relative flex items-center">
                      <span className="absolute left-3 text-[#b89358] material-symbols-outlined text-[18px]">
                        badge
                      </span>
                      <input
                        id={profileUrlId}
                        type="url"
                        value={formData.profileUrl}
                        onChange={(e) => handleInputChange('profileUrl', e.target.value)}
                        placeholder="https://linkedin.com/in/investor or https://venturefund.com"
                        className="w-full p-3 pl-10 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                      />
                    </div>
                  </div>
                )}
              </>
            )}

            {/* ===================== EMAIL FIELD ===================== */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <label htmlFor={emailId} className="text-xs font-bold text-[#1b1c1a]">
                  {accountType === 'public' ? 'Email Address' : 'Work Email Address'}
                  <span className="text-[#ba1a1a] ml-1" aria-hidden="true">*</span>
                </label>
                <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
              </div>
              <div className="relative flex items-center">
                <span className="absolute left-3 text-[#b89358] material-symbols-outlined text-[18px]">
                  mail
                </span>
                <input
                  id={emailId}
                  type="email"
                  required
                  autoComplete="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder={currentTypeMeta.defaultEmailPlaceholder}
                  className={`w-full p-3 pl-10 bg-[#faf6f0] border-2 rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922] transition-all ${
                    errors.email ? 'border-red-500 bg-red-50/40' : 'border-[#e8d3b9]'
                  }`}
                />
              </div>
              {errors.email && (
                <p className="text-[11px] text-[#ba1a1a] flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">error</span>
                  <span>{errors.email}</span>
                </p>
              )}
            </div>

            {/* ===================== PHONE NUMBER FIELD (Optional) ===================== */}
            {mode === 'register' && (
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <label htmlFor={phoneId} className="text-xs font-bold text-[#1b1c1a]">
                    Phone Number
                  </label>
                  <span className="text-[10px] text-[#6b5c47] font-semibold uppercase tracking-wider">(optional)</span>
                </div>
                <div className="relative flex items-center">
                  <span className="absolute left-3 text-[#b89358] material-symbols-outlined text-[18px]">
                    call
                  </span>
                  <input
                    id={phoneId}
                    type="tel"
                    autoComplete="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    placeholder="+91 98450 12890"
                    className="w-full p-3 pl-10 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                  />
                </div>
              </div>
            )}

            {/* ===================== PASSWORD FIELD ===================== */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <label htmlFor={passwordId} className="text-xs font-bold text-[#1b1c1a]">
                  Password <span className="text-[#ba1a1a]">*</span>
                </label>
                <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
              </div>
              <div className="relative flex items-center">
                <span className="absolute left-3 text-[#b89358] material-symbols-outlined text-[18px]">
                  lock
                </span>
                <input
                  id={passwordId}
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  placeholder={mode === 'login' ? 'Enter your account password' : 'Create a secure password (8+ chars)'}
                  className={`w-full p-3 pl-10 pr-12 bg-[#faf6f0] border-2 rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922] transition-all ${
                    errors.password ? 'border-red-500 bg-red-50/40' : 'border-[#e8d3b9]'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-3 p-1 text-[#6b5c47] hover:text-[#561922]"
                >
                  <span className="material-symbols-outlined text-[20px]">
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </span>
                </button>
              </div>
              {errors.password && (
                <p className="text-[11px] text-[#ba1a1a] flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">error</span>
                  <span>{errors.password}</span>
                </p>
              )}
            </div>

            {/* ===================== CONFIRM PASSWORD FIELD ===================== */}
            {mode === 'register' && (
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <label htmlFor={confirmPasswordId} className="text-xs font-bold text-[#1b1c1a]">
                    Confirm Password <span className="text-[#ba1a1a]">*</span>
                  </label>
                  <span className="text-[10px] font-bold text-[#561922] uppercase tracking-wider">Required</span>
                </div>
                <div className="relative flex items-center">
                  <span className="absolute left-3 text-[#b89358] material-symbols-outlined text-[18px]">
                    lock_reset
                  </span>
                  <input
                    id={confirmPasswordId}
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    autoComplete="new-password"
                    value={formData.confirmPassword}
                    onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                    placeholder="Re-type your password"
                    className={`w-full p-3 pl-10 pr-12 bg-[#faf6f0] border-2 rounded-xl text-xs sm:text-sm text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922] transition-all ${
                      errors.confirmPassword ? 'border-red-500 bg-red-50/40' : 'border-[#e8d3b9]'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    aria-label={showConfirmPassword ? 'Hide confirmation password' : 'Show confirmation password'}
                    className="absolute right-3 p-1 text-[#6b5c47] hover:text-[#561922]"
                  >
                    <span className="material-symbols-outlined text-[20px]">
                      {showConfirmPassword ? 'visibility_off' : 'visibility'}
                    </span>
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="text-[11px] text-[#ba1a1a] flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px]">error</span>
                    <span>{errors.confirmPassword}</span>
                  </p>
                )}
              </div>
            )}

            {/* ===================== PASSWORD REQUIREMENTS CHECKLIST ===================== */}
            {mode === 'register' && formData.password && (
              <div className="p-3 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl flex flex-col gap-2 text-[11px]">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1b1c1a]">Password Requirements</span>
                  <span className="font-bold text-[#561922]">
                    {getPasswordStrengthScore() <= 2 ? 'Weak' : getPasswordStrengthScore() === 3 ? 'Good' : 'Strong'}
                  </span>
                </div>

                <div className="w-full h-2 bg-[#e8d3b9]/50 rounded-full overflow-hidden flex">
                  <div 
                    className={`h-full transition-all duration-300 ${
                      getPasswordStrengthScore() <= 1 ? 'w-1/4 bg-red-500' :
                      getPasswordStrengthScore() === 2 ? 'w-2/4 bg-amber-500' :
                      getPasswordStrengthScore() === 3 ? 'w-3/4 bg-[#d4af37]' :
                      'w-full bg-[#561922]'
                    }`}
                  />
                </div>

                <div className="grid grid-cols-2 gap-1.5 pt-1 text-[#534343]">
                  <div className={`flex items-center gap-1.5 ${passwordCriteria.length ? 'text-emerald-700 font-bold' : ''}`}>
                    <span className="material-symbols-outlined text-[14px]">
                      {passwordCriteria.length ? 'check_circle' : 'radio_button_unchecked'}
                    </span>
                    <span>8+ characters</span>
                  </div>
                  <div className={`flex items-center gap-1.5 ${passwordCriteria.hasUpper ? 'text-emerald-700 font-bold' : ''}`}>
                    <span className="material-symbols-outlined text-[14px]">
                      {passwordCriteria.hasUpper ? 'check_circle' : 'radio_button_unchecked'}
                    </span>
                    <span>1 uppercase letter</span>
                  </div>
                  <div className={`flex items-center gap-1.5 ${passwordCriteria.hasNumberOrSymbol ? 'text-emerald-700 font-bold' : ''}`}>
                    <span className="material-symbols-outlined text-[14px]">
                      {passwordCriteria.hasNumberOrSymbol ? 'check_circle' : 'radio_button_unchecked'}
                    </span>
                    <span>1 number or symbol</span>
                  </div>
                  <div className={`flex items-center gap-1.5 ${passwordCriteria.matches && formData.confirmPassword ? 'text-emerald-700 font-bold' : ''}`}>
                    <span className="material-symbols-outlined text-[14px]">
                      {passwordCriteria.matches && formData.confirmPassword ? 'check_circle' : 'radio_button_unchecked'}
                    </span>
                    <span>Passwords match</span>
                  </div>
                </div>
              </div>
            )}

            {/* ===================== LOGIN HELPERS: Remember Me & Forgot Password ===================== */}
            {mode === 'login' && (
              <div className="flex items-center justify-between text-xs pt-1">
                <label htmlFor={rememberId} className="flex items-center gap-2 text-[#534343] cursor-pointer select-none">
                  <input
                    id={rememberId}
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded text-[#561922] accent-[#561922] cursor-pointer"
                  />
                  <span>Remember me for 30 days</span>
                </label>

                <button
                  type="button"
                  onClick={() => {
                    setForgotEmail(formData.email);
                    setForgotModalOpen(true);
                  }}
                  className="font-bold text-[#561922] hover:text-[#d4af37] underline transition-colors"
                >
                  Forgot password?
                </button>
              </div>
            )}

            {/* ===================== REGISTRATION AGREEMENT CHECKBOX ===================== */}
            {mode === 'register' && (
              <div className="flex flex-col gap-1 pt-1">
                <label htmlFor={termsId} className="flex items-start gap-2.5 text-xs text-[#534343] cursor-pointer select-none leading-relaxed">
                  <input
                    id={termsId}
                    type="checkbox"
                    checked={termsAgreed}
                    onChange={(e) => {
                      setTermsAgreed(e.target.checked);
                      if (errors.terms) {
                        setErrors((prev) => {
                          const next = { ...prev };
                          delete next.terms;
                          return next;
                        });
                      }
                    }}
                    className="w-4 h-4 mt-0.5 rounded text-[#561922] accent-[#561922] shrink-0 cursor-pointer"
                  />
                  <span>
                    I agree to the{' '}
                    <button
                      type="button"
                      onClick={(e) => { e.preventDefault(); setTermsModalOpen(true); }}
                      className="font-bold text-[#561922] underline"
                    >
                      Terms of Service
                    </button>
                    {', '}
                    <button
                      type="button"
                      onClick={(e) => { e.preventDefault(); setPrivacyModalOpen(true); }}
                      className="font-bold text-[#561922] underline"
                    >
                      Privacy Policy
                    </button>
                    {', and sovereign milestone escrow covenants.'}
                  </span>
                </label>
                {errors.terms && (
                  <p className="text-[11px] text-[#ba1a1a] flex items-center gap-1 pl-6">
                    <span className="material-symbols-outlined text-[14px]">error</span>
                    <span>{errors.terms}</span>
                  </p>
                )}
              </div>
            )}

            {/* ===================== SUBMIT BUTTON ===================== */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 mt-2 bg-[#561922] hover:bg-[#3c0b12] text-[#f7e7ce] text-sm font-bold rounded-xl shadow-md border-2 border-[#d4af37] transition-all active:scale-98 flex items-center justify-center gap-2 group cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <span className="w-4 h-4 border-2 border-[#d4af37] border-t-transparent rounded-full animate-spin"></span>
                  <span>{mode === 'login' ? 'Authenticating...' : `Creating ${currentTypeMeta.title} Account...`}</span>
                </>
              ) : (
                <>
                  <span>
                    {mode === 'login' ? `Log in as ${currentTypeMeta.title}` : `Create ${currentTypeMeta.title} Account`}
                  </span>
                  <span className="material-symbols-outlined text-[18px] text-[#d4af37] group-hover:translate-x-1 transition-transform">
                    arrow_forward
                  </span>
                </>
              )}
            </button>
          </form>

          {/* Bottom Card Switcher link */}
          <div className="text-center text-xs text-[#534343] pt-3 border-t-2 border-[#e8d3b9]">
            {mode === 'login' ? (
              <p>
                Don&apos;t have an account yet?{' '}
                <button
                  type="button"
                  onClick={() => { setMode('register'); setErrors({}); }}
                  className="font-bold text-[#561922] hover:text-[#d4af37] underline"
                >
                  Create an account
                </button>
              </p>
            ) : (
              <p>
                Already registered on NEXUS VENTURE AI?{' '}
                <button
                  type="button"
                  onClick={() => { setMode('login'); setErrors({}); }}
                  className="font-bold text-[#561922] hover:text-[#d4af37] underline"
                >
                  Log in to your workspace
                </button>
              </p>
            )}
          </div>

        </div>
      </div>

      {/* Institutional Legal Footer */}
      <footer className="w-full max-w-7xl mx-auto pt-6 pb-2 border-t-2 border-[#e8d3b9] flex flex-wrap items-center justify-between gap-4 text-xs text-[#6b5c47]">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-[#561922] text-[#d4af37] flex items-center justify-center border border-[#d4af37]">
            <span className="material-symbols-outlined text-[14px]">policy</span>
          </div>
          <span className="font-headline font-bold text-xs text-[#1b1c1a]">
            NEXUS VENTURE AI © 2026
          </span>
          <span className="text-[#867273]">|</span>
          <span>Sovereign DeepTech Capital Protocol</span>
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs">
          <button 
            onClick={() => setTermsModalOpen(true)}
            className="hover:text-[#561922] font-semibold"
          >
            Terms of Service
          </button>
          <button 
            onClick={() => setPrivacyModalOpen(true)}
            className="hover:text-[#561922] font-semibold"
          >
            Privacy Policy
          </button>
          <button 
            onClick={() => alert("Escrow Security: All tranche allocations are sealed using multi-sig cryptographic smart contracts with milestone completion audits.")}
            className="hover:text-[#561922] font-semibold"
          >
            Escrow Architecture
          </button>
        </div>
      </footer>

      {/* ===================== MODAL: FORGOT PASSWORD ===================== */}
      {forgotModalOpen && (
        <div 
          className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn"
          role="dialog"
          aria-modal="true"
        >
          <div 
            className="relative w-full max-w-md bg-white border-2 border-[#d4af37] rounded-2xl shadow-2xl p-6 flex flex-col gap-4 animate-scaleUp"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b-2 border-[#e8d3b9] pb-3">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#561922] text-[22px]">lock_reset</span>
                <h3 className="font-headline font-bold text-lg text-[#1b1c1a]">
                  Reset Account Password
                </h3>
              </div>
              <button 
                onClick={() => setForgotModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-[#efeeeb] flex items-center justify-center text-[#6b5c47]"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            {forgotSubmitted ? (
              <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-xl text-xs text-emerald-900 flex items-start gap-3">
                <span className="material-symbols-outlined text-emerald-700 text-[22px] shrink-0">mark_email_read</span>
                <div className="flex flex-col gap-1">
                  <span className="font-bold">Password Reset Dispatched</span>
                  <span>A secure recovery link has been delivered to <strong>{forgotEmail}</strong>. Please check your inbox within 15 minutes.</span>
                </div>
              </div>
            ) : (
              <form onSubmit={handleForgotSubmit} className="flex flex-col gap-3">
                <p className="text-xs text-[#534343] leading-relaxed">
                  Enter your registered institutional or personal email address. We will send a cryptographic recovery token to verify your identity.
                </p>

                <div className="flex flex-col gap-1">
                  <label htmlFor="forgot-email-input" className="text-xs font-bold text-[#1b1c1a]">
                    Email Address <span className="text-[#ba1a1a]">*</span>
                  </label>
                  <input
                    id="forgot-email-input"
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="name@organization.com"
                    className="p-3 bg-[#faf6f0] border-2 border-[#e8d3b9] rounded-xl text-xs text-[#1b1c1a] focus:bg-white focus:outline-none focus:border-[#561922]"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setForgotModalOpen(false)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-[#534343] hover:bg-[#efeeeb]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-[#561922] hover:bg-[#3c0b12] text-[#f7e7ce] text-xs font-bold rounded-xl shadow-xs border border-[#d4af37] flex items-center gap-1.5"
                  >
                    <span>Send Reset Link</span>
                    <span className="material-symbols-outlined text-[16px]">send</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ===================== MODAL: TERMS OF SERVICE ===================== */}
      {termsModalOpen && (
        <div 
          className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn"
          role="dialog"
          aria-modal="true"
        >
          <div 
            className="relative w-full max-w-xl bg-white border-2 border-[#d4af37] rounded-2xl shadow-2xl p-6 flex flex-col gap-4 max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b-2 border-[#e8d3b9] pb-3">
              <h3 className="font-headline font-bold text-xl text-[#561922]">
                NEXUS VENTURE AI Terms of Service
              </h3>
              <button 
                onClick={() => setTermsModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-[#efeeeb] flex items-center justify-center text-[#6b5c47]"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <div className="flex flex-col gap-3 text-xs text-[#534343] leading-relaxed">
              <h4 className="font-bold text-sm text-[#1b1c1a]">1. Ecosystem Roles & Non-Disclosure</h4>
              <p>
                NEXUS VENTURE AI connects patent-backed hardware innovators, institutional investors, and public researchers. All intellectual property submitted to closed syndicates is protected under priority timestamp treaties (WIPO, USPTO, and Indian Patent Office).
              </p>

              <h4 className="font-bold text-sm text-[#1b1c1a]">2. Milestone-Governed Escrow</h4>
              <p>
                Capital allocations made by accredited investors are committed to smart milestone escrow accounts. Funds are only unlocked upon objective verification of technical deliverables and bill of materials (BOM) audits.
              </p>

              <h4 className="font-bold text-sm text-[#1b1c1a]">3. Zero Unsolicited Financial Data Collection</h4>
              <p>
                We do not collect banking details, credit cards, or accredited wealth disclosures during the initial registration phase. Institutional KYC occurs strictly prior to executing smart escrow agreements.
              </p>

              <h4 className="font-bold text-sm text-[#1b1c1a]">4. Public Participation Rights</h4>
              <p>
                Public observers may review open technical briefs, submit community reviews, and track verified development milestones without any financial commitment.
              </p>
            </div>

            <div className="pt-3 border-t-2 border-[#e8d3b9] flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setTermsAgreed(true);
                  setTermsModalOpen(false);
                }}
                className="px-5 py-2.5 bg-[#561922] hover:bg-[#3c0b12] text-[#f7e7ce] text-xs font-bold rounded-xl shadow-xs border border-[#d4af37]"
              >
                I Understand & Agree
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== MODAL: PRIVACY POLICY ===================== */}
      {privacyModalOpen && (
        <div 
          className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn"
          role="dialog"
          aria-modal="true"
        >
          <div 
            className="relative w-full max-w-xl bg-white border-2 border-[#d4af37] rounded-2xl shadow-2xl p-6 flex flex-col gap-4 max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b-2 border-[#e8d3b9] pb-3">
              <h3 className="font-headline font-bold text-xl text-[#561922]">
                Privacy & Cryptographic Custody Policy
              </h3>
              <button 
                onClick={() => setPrivacyModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-[#efeeeb] flex items-center justify-center text-[#6b5c47]"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <div className="flex flex-col gap-3 text-xs text-[#534343] leading-relaxed">
              <h4 className="font-bold text-sm text-[#1b1c1a]">1. Data Minimization by Design</h4>
              <p>
                We adhere strictly to privacy-by-design principles. We only collect the necessary professional contact information needed to facilitate communication and verify ecosystem roles.
              </p>

              <h4 className="font-bold text-sm text-[#1b1c1a]">2. Sovereign Vault Encryption</h4>
              <p>
                Proprietary patent claims, BOM cost sheets, and firm records are encrypted with military-grade AES-256 GCM in transit and at rest.
              </p>

              <h4 className="font-bold text-sm text-[#1b1c1a]">3. No Sale of User Data</h4>
              <p>
                We do not sell, license, or monetize personal identifiable data or institutional deal activity to third-party ad networks.
              </p>
            </div>

            <div className="pt-3 border-t-2 border-[#e8d3b9] flex justify-end">
              <button
                type="button"
                onClick={() => setPrivacyModalOpen(false)}
                className="px-5 py-2.5 bg-[#561922] hover:bg-[#3c0b12] text-[#f7e7ce] text-xs font-bold rounded-xl shadow-xs border border-[#d4af37]"
              >
                Close Policy
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

window.LoginPage = LoginPage;

