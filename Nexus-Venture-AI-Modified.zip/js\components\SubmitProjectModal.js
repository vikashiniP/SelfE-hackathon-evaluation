/**
 * NEXUS VENTURE AI - Developer Portal: Submit Project Modal
 * Follows the 8-Section Developer Portal master prompt specification.
 * Validates, handles image previews, YouTube embeds, conditional patent fields, and ₹ costs.
 */

function SubmitProjectModal({ isOpen, onClose, onProjectSubmitted, currentUser }) {
  if (!isOpen) return null;

  const { useState } = React;

  // Form State
  const [formData, setFormData] = useState({
    // Section 1: Project Name & Description
    title: '',
    sector: 'Technology',
    stage: 'MVP / Early Product',
    summary: '',
    description: '',
    benefitsText: '',

    // Section 2: Images
    representativeImage: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80',
    prototypeImage: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80',
    supportingImagesText: '',

    // Section 3: Video
    videoUrl: 'https://www.youtube.com/embed/ScMzIvxBSi4',
    videoDescription: '',

    // Section 4: Technical Details
    languagesText: 'Python, C++',
    frameworksText: 'PyTorch, FastAPI, React',
    frontend: 'React Web Application, Tailwind CSS',
    backend: 'FastAPI, PostgreSQL, Docker',
    hardwarePartsText: 'ESP32-S3, Custom 4-Layer PCB, High-Precision Sensors',

    // Section 5: Cost & Funding
    buildCost: '₹1,50,000',
    targetFunding: '₹25,00,000',
    costExplanation: 'Prototyping sensor calibration, custom PCB fabrication, and firmware development.',
    costBreakdown: 'Components: ₹60,000 | Fabrication: ₹40,000 | Testing: ₹30,000 | Firmware QA: ₹20,000',

    // Section 6: Patent Status
    patentStatus: 'Patent Applied – Pending',
    patentNumber: '',
    grantDate: '',
    applicationNumber: '202411098214',
    publicationNumber: '',
    publicationDate: '',
    filingDate: '2024-04-12',
    patentDescription: '',

    // Section 7: Developer Information
    devName: currentUser ? currentUser.name : '',
    devEmail: currentUser ? currentUser.email : '',
    devPhone: '+91 98450 11223',
    institution: currentUser && currentUser.organization ? currentUser.organization : 'IIT Madras Research Park',
    background: 'DeepTech hardware innovator specializing in autonomous embedded systems.',
    team: '3 Core Engineers (Hardware, Embedded Firmware, Backend)',

    // Section 8: Declaration
    declaration: false
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState(false);

  const sectors = ['Agriculture', 'Environment', 'Healthcare', 'Education', 'Technology', 'Business'];
  const stages = [
    'Idea / Concept',
    'MVP / Early Product',
    'Full Project Ready',
    'Field Tested with Users'
  ];
  const patentOptions = [
    'Granted Patent',
    'Published Patent Application',
    'Patent Applied – Pending',
    'No Patent'
  ];

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const validate = () => {
    const errs = {};
    if (!formData.title.trim()) errs.title = 'Project title is required.';
    if (!formData.summary.trim()) errs.summary = 'One-sentence summary is required.';
    if (!formData.description.trim()) errs.description = 'Full description is required.';
    if (!formData.buildCost.trim()) errs.buildCost = 'Build cost in ₹ is required.';
    if (!formData.targetFunding.trim()) errs.targetFunding = 'Target funding in ₹ is required.';
    if (!formData.devName.trim()) errs.devName = 'Developer name is required.';
    if (!formData.devEmail.trim()) errs.devEmail = 'Developer email is required.';
    if (!formData.declaration) errs.declaration = 'You must confirm the submission declaration.';

    // Patent conditional checks
    if (formData.patentStatus === 'Granted Patent' && !formData.patentNumber.trim()) {
      errs.patentNumber = 'Granted Patent number is required.';
    }
    if (formData.patentStatus === 'Published Patent Application' && !formData.publicationNumber.trim()) {
      errs.publicationNumber = 'Publication number is required.';
    }
    if (formData.patentStatus === 'Patent Applied – Pending' && !formData.applicationNumber.trim()) {
      errs.applicationNumber = 'Patent Application number is required.';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    setTimeout(() => {
      // Split comma/newline text inputs
      const benefits = formData.benefitsText
        ? formData.benefitsText.split('\n').map((b) => b.trim()).filter(Boolean)
        : ['Autonomous local edge execution', '90% lower operational bill of materials', 'Patented sensor telemetry'];

      const languages = formData.languagesText
        ? formData.languagesText.split(',').map((l) => l.trim()).filter(Boolean)
        : ['Python', 'C++'];

      const frameworks = formData.frameworksText
        ? formData.frameworksText.split(',').map((f) => f.trim()).filter(Boolean)
        : ['FastAPI', 'React'];

      const hardwareParts = formData.hardwarePartsText
        ? formData.hardwarePartsText.split(',').map((h) => h.trim()).filter(Boolean)
        : ['ESP32', 'Custom PCB'];

      const newProject = {
        name: formData.title.trim(),
        sector: formData.sector,
        stage: formData.stage,
        summary: formData.summary.trim(),
        fullDescription: formData.description.trim(),
        benefits: benefits,
        image: formData.representativeImage.trim(),
        prototypeImage: formData.prototypeImage.trim(),
        supportingImages: [formData.representativeImage, formData.prototypeImage],
        videoUrl: formData.videoUrl.trim(),
        videoDescription: formData.videoDescription.trim(),
        languages: languages,
        frameworks: frameworks,
        frontend: formData.frontend.trim(),
        backend: formData.backend.trim(),
        hardwareParts: hardwareParts,
        buildCost: formData.buildCost.startsWith('₹') ? formData.buildCost.trim() : `₹${formData.buildCost.trim()}`,
        targetFunding: formData.targetFunding.startsWith('₹') ? formData.targetFunding.trim() : `₹${formData.targetFunding.trim()}`,
        costExplanation: formData.costExplanation.trim(),
        costBreakdown: formData.costBreakdown.trim(),
        patentStatus: formData.patentStatus,
        patentDetails: {
          patentNumber: formData.patentNumber,
          grantDate: formData.grantDate,
          applicationNumber: formData.applicationNumber,
          publicationNumber: formData.publicationNumber,
          publicationDate: formData.publicationDate,
          filingDate: formData.filingDate,
          description: formData.patentDescription || formData.title
        },
        developer: {
          name: formData.devName.trim(),
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
          role: 'Startup Developer',
          institution: formData.institution.trim(),
          background: formData.background.trim(),
          email: formData.devEmail.trim(),
          phone: formData.devPhone.trim(),
          team: formData.team.trim()
        }
      };

      const saved = window.NexusDB.addProject(newProject);
      setIsSubmitting(false);
      setSuccessMessage(true);

      setTimeout(() => {
        setSuccessMessage(false);
        if (onProjectSubmitted) onProjectSubmitted(saved);
        onClose();
      }, 1800);
    }, 700);
  };

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-dialog max-w-4xl" onClick={(e) => e.stopPropagation()}>
        
        {/* Modal Burgundy Header */}
        <div className="modal-header-burgundy">
          <div className="flex flex-col">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#d4af37] uppercase tracking-wider">
              <span className="material-symbols-outlined text-[18px]">terminal</span>
              <span>DEVELOPER PORTAL</span>
            </div>
            <h2 className="font-headline font-bold text-xl sm:text-2xl text-white">
              Submit Your Startup Project
            </h2>
            <p className="text-xs text-[#f7e7ce] mt-0.5">
              Fill in your project information, parts list and costs in Indian Rupees (₹). Your project will be displayed on the website for investors to explore.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#561922] hover:bg-[#722f37] border border-[#d4af37] text-white flex items-center justify-center cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Modal Scrollable Form */}
        <div className="modal-body-scroll">
          {successMessage ? (
            <div className="p-8 text-center flex flex-col items-center gap-4 bg-emerald-50 border-2 border-emerald-400 rounded-2xl">
              <span className="material-symbols-outlined text-emerald-600 text-[48px]">check_circle</span>
              <h3 className="font-headline font-bold text-2xl text-emerald-900">
                Startup Successfully Submitted!
              </h3>
              <p className="text-sm text-emerald-800 max-w-md">
                Your project details, bill of materials, and patent status have been verified and added to the <strong>NEXUS VENTURE AI</strong> Explore Projects directory.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-8">
              
              {/* SECTION 1: PROJECT NAME & DESCRIPTION */}
              <div className="flex flex-col gap-4 pb-6 border-b border-[#e8d3b9]">
                <div className="flex items-center gap-2 text-[#561922]">
                  <span className="material-symbols-outlined text-[22px] text-[#d4af37]">assignment</span>
                  <h3 className="font-headline font-bold text-base uppercase tracking-wider">
                    Section 1 – Project Name & Description
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="sm:col-span-3 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Project Title *</label>
                    <input
                      type="text"
                      required
                      value={formData.title}
                      onChange={(e) => handleInputChange('title', e.target.value)}
                      placeholder="e.g. BioVolt Microbial Fuel Cell Generator"
                      className={`p-3 bg-[#faf6f0] border rounded-xl text-xs sm:text-sm ${errors.title ? 'border-red-500 bg-red-50' : 'border-[#e8d3b9]'}`}
                    />
                    {errors.title && <span className="text-[11px] text-red-600 font-bold">{errors.title}</span>}
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Sector *</label>
                    <select
                      value={formData.sector}
                      onChange={(e) => handleInputChange('sector', e.target.value)}
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    >
                      {sectors.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>

                  <div className="sm:col-span-2 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Current Development Stage *</label>
                    <select
                      value={formData.stage}
                      onChange={(e) => handleInputChange('stage', e.target.value)}
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    >
                      {stages.map((st) => <option key={st} value={st}>{st}</option>)}
                    </select>
                  </div>

                  <div className="sm:col-span-3 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">One-Sentence Summary *</label>
                    <input
                      type="text"
                      required
                      value={formData.summary}
                      onChange={(e) => handleInputChange('summary', e.target.value)}
                      placeholder="Concise 1-line value proposition for angel & venture investors..."
                      className={`p-3 bg-[#faf6f0] border rounded-xl text-xs ${errors.summary ? 'border-red-500' : 'border-[#e8d3b9]'}`}
                    />
                    {errors.summary && <span className="text-[11px] text-red-600 font-bold">{errors.summary}</span>}
                  </div>

                  <div className="sm:col-span-3 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Full Description (in simple words) *</label>
                    <textarea
                      required
                      rows="4"
                      value={formData.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                      placeholder="Explain what the product is, what exact real-world problem it solves, and how it works..."
                      className={`p-3 bg-[#faf6f0] border rounded-xl text-xs ${errors.description ? 'border-red-500' : 'border-[#e8d3b9]'}`}
                    ></textarea>
                    {errors.description && <span className="text-[11px] text-red-600 font-bold">{errors.description}</span>}
                  </div>

                  <div className="sm:col-span-3 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Key Benefits for Users (one benefit per line)</label>
                    <textarea
                      rows="3"
                      value={formData.benefitsText}
                      onChange={(e) => handleInputChange('benefitsText', e.target.value)}
                      placeholder="Benefit 1: Reduces operational energy cost by 50%&#10;Benefit 2: Operates 100% offline&#10;Benefit 3: Low cost replacement cartridges"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    ></textarea>
                  </div>
                </div>
              </div>

              {/* SECTION 2: PROJECT IMAGES */}
              <div className="flex flex-col gap-4 pb-6 border-b border-[#e8d3b9]">
                <div className="flex items-center gap-2 text-[#561922]">
                  <span className="material-symbols-outlined text-[22px] text-[#d4af37]">photo_library</span>
                  <h3 className="font-headline font-bold text-base uppercase tracking-wider">
                    Section 2 – Project Images
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Representative Image URL / Upload</label>
                    <input
                      type="url"
                      value={formData.representativeImage}
                      onChange={(e) => handleInputChange('representativeImage', e.target.value)}
                      placeholder="https://images.unsplash.com/..."
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Prototype Image URL / Upload</label>
                    <input
                      type="url"
                      value={formData.prototypeImage}
                      onChange={(e) => handleInputChange('prototypeImage', e.target.value)}
                      placeholder="https://images.unsplash.com/..."
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  {/* Previews */}
                  <div className="sm:col-span-2 flex items-center gap-4 p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl">
                    <span className="text-[11px] font-bold text-[#6b5c47]">Live Image Previews:</span>
                    <div className="flex items-center gap-3">
                      {formData.representativeImage && (
                        <img src={formData.representativeImage} alt="Representative Preview" className="w-16 h-12 object-cover rounded-lg border border-[#d4af37]" />
                      )}
                      {formData.prototypeImage && (
                        <img src={formData.prototypeImage} alt="Prototype Preview" className="w-16 h-12 object-cover rounded-lg border border-[#d4af37]" />
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* SECTION 3: WORKING MODEL VIDEO */}
              <div className="flex flex-col gap-4 pb-6 border-b border-[#e8d3b9]">
                <div className="flex items-center gap-2 text-[#561922]">
                  <span className="material-symbols-outlined text-[22px] text-[#d4af37]">play_circle</span>
                  <h3 className="font-headline font-bold text-base uppercase tracking-wider">
                    Section 3 – Working Model Video
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">YouTube Video Embed URL</label>
                    <input
                      type="url"
                      value={formData.videoUrl}
                      onChange={(e) => handleInputChange('videoUrl', e.target.value)}
                      placeholder="https://www.youtube.com/embed/..."
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  <div className="sm:col-span-2 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Short Video Demonstration Description</label>
                    <input
                      type="text"
                      value={formData.videoDescription}
                      onChange={(e) => handleInputChange('videoDescription', e.target.value)}
                      placeholder="Explain what investors are observing in the video..."
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 4: TECHNICAL DETAILS */}
              <div className="flex flex-col gap-4 pb-6 border-b border-[#e8d3b9]">
                <div className="flex items-center gap-2 text-[#561922]">
                  <span className="material-symbols-outlined text-[22px] text-[#d4af37]">developer_board</span>
                  <h3 className="font-headline font-bold text-base uppercase tracking-wider">
                    Section 4 – Technical Details & Parts List
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Programming Languages (comma-separated)</label>
                    <input
                      type="text"
                      value={formData.languagesText}
                      onChange={(e) => handleInputChange('languagesText', e.target.value)}
                      placeholder="C, Python, C++, Verilog"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Software & Frameworks (comma-separated)</label>
                    <input
                      type="text"
                      value={formData.frameworksText}
                      onChange={(e) => handleInputChange('frameworksText', e.target.value)}
                      placeholder="ROS2, TensorFlow Lite, FastAPI, Docker"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Frontend Technologies</label>
                    <input
                      type="text"
                      value={formData.frontend}
                      onChange={(e) => handleInputChange('frontend', e.target.value)}
                      placeholder="React, Tailwind CSS, Leaflet"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Backend Technologies</label>
                    <input
                      type="text"
                      value={formData.backend}
                      onChange={(e) => handleInputChange('backend', e.target.value)}
                      placeholder="Node.js, PostgreSQL, MQTT"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  <div className="sm:col-span-2 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Hardware Parts List (Sensors, MCUs, Circuits)</label>
                    <textarea
                      rows="2"
                      value={formData.hardwarePartsText}
                      onChange={(e) => handleInputChange('hardwarePartsText', e.target.value)}
                      placeholder="STM32WB55, ADS1298 Front-End, Monocrystalline Solar Cell, 3-Axis Gyroscope"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    ></textarea>
                  </div>
                </div>
              </div>

              {/* SECTION 5: PROJECT COST & FUNDING */}
              <div className="flex flex-col gap-4 pb-6 border-b border-[#e8d3b9]">
                <div className="flex items-center gap-2 text-[#561922]">
                  <span className="material-symbols-outlined text-[22px] text-[#d4af37]">currency_rupee</span>
                  <h3 className="font-headline font-bold text-base uppercase tracking-wider">
                    Section 5 – Project Cost & Funding (in Indian Rupees ₹)
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Total Project Build Cost (₹) *</label>
                    <input
                      type="text"
                      required
                      value={formData.buildCost}
                      onChange={(e) => handleInputChange('buildCost', e.target.value)}
                      placeholder="₹1,85,000"
                      className={`p-3 bg-[#faf6f0] border rounded-xl text-xs ${errors.buildCost ? 'border-red-500' : 'border-[#e8d3b9]'}`}
                    />
                    {errors.buildCost && <span className="text-[11px] text-red-600 font-bold">{errors.buildCost}</span>}
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Target Funding Required (₹) *</label>
                    <input
                      type="text"
                      required
                      value={formData.targetFunding}
                      onChange={(e) => handleInputChange('targetFunding', e.target.value)}
                      placeholder="₹35,00,000"
                      className={`p-3 bg-[#faf6f0] border rounded-xl text-xs ${errors.targetFunding ? 'border-red-500' : 'border-[#e8d3b9]'}`}
                    />
                    {errors.targetFunding && <span className="text-[11px] text-red-600 font-bold">{errors.targetFunding}</span>}
                  </div>

                  <div className="sm:col-span-2 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Brief Explanation of Estimated Cost</label>
                    <input
                      type="text"
                      value={formData.costExplanation}
                      onChange={(e) => handleInputChange('costExplanation', e.target.value)}
                      placeholder="Hardware BOM accounts for ₹1.2L; prototyping test rigs account for ₹65k."
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  <div className="sm:col-span-2 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Optional Cost Breakdown</label>
                    <input
                      type="text"
                      value={formData.costBreakdown}
                      onChange={(e) => handleInputChange('costBreakdown', e.target.value)}
                      placeholder="Sensors: ₹50k | PCB: ₹35k | Testing: ₹40k | Gateway: ₹25k"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 6: PATENT & INTELLECTUAL PROPERTY STATUS */}
              <div className="flex flex-col gap-4 pb-6 border-b border-[#e8d3b9]">
                <div className="flex items-center gap-2 text-[#561922]">
                  <span className="material-symbols-outlined text-[22px] text-[#d4af37]">policy</span>
                  <h3 className="font-headline font-bold text-base uppercase tracking-wider">
                    Section 6 – Patent & Intellectual Property Status
                  </h3>
                </div>

                <div className="flex flex-col gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Patent Status (Required - Exactly 4 Options) *</label>
                    <select
                      value={formData.patentStatus}
                      onChange={(e) => handleInputChange('patentStatus', e.target.value)}
                      className="p-3 bg-white border-2 border-[#561922] rounded-xl text-xs font-bold text-[#561922]"
                    >
                      {patentOptions.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
                    </select>
                  </div>

                  {/* Conditional Dynamic Fields based on Patent Status */}
                  {formData.patentStatus === 'Granted Patent' && (
                    <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="flex flex-col gap-1">
                        <label className="font-bold text-emerald-950">Patent Number *</label>
                        <input
                          type="text"
                          required
                          value={formData.patentNumber}
                          onChange={(e) => handleInputChange('patentNumber', e.target.value)}
                          placeholder="e.g. IN-389124-B"
                          className="p-2.5 bg-white border rounded-lg text-xs"
                        />
                        {errors.patentNumber && <span className="text-[11px] text-red-600">{errors.patentNumber}</span>}
                      </div>

                      <div className="flex flex-col gap-1">
                        <label className="font-bold text-emerald-950">Grant Date</label>
                        <input
                          type="date"
                          value={formData.grantDate}
                          onChange={(e) => handleInputChange('grantDate', e.target.value)}
                          className="p-2.5 bg-white border rounded-lg text-xs"
                        />
                      </div>
                    </div>
                  )}

                  {formData.patentStatus === 'Published Patent Application' && (
                    <div className="p-4 rounded-xl bg-blue-50 border border-blue-300 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div className="flex flex-col gap-1">
                        <label className="font-bold text-blue-950">Application Number</label>
                        <input
                          type="text"
                          value={formData.applicationNumber}
                          onChange={(e) => handleInputChange('applicationNumber', e.target.value)}
                          placeholder="e.g. 202341058291"
                          className="p-2.5 bg-white border rounded-lg text-xs"
                        />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-bold text-blue-950">Publication Number *</label>
                        <input
                          type="text"
                          required
                          value={formData.publicationNumber}
                          onChange={(e) => handleInputChange('publicationNumber', e.target.value)}
                          placeholder="e.g. IN202341058291A"
                          className="p-2.5 bg-white border rounded-lg text-xs"
                        />
                        {errors.publicationNumber && <span className="text-[11px] text-red-600">{errors.publicationNumber}</span>}
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-bold text-blue-950">Publication Date</label>
                        <input
                          type="date"
                          value={formData.publicationDate}
                          onChange={(e) => handleInputChange('publicationDate', e.target.value)}
                          className="p-2.5 bg-white border rounded-lg text-xs"
                        />
                      </div>
                    </div>
                  )}

                  {formData.patentStatus === 'Patent Applied – Pending' && (
                    <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="flex flex-col gap-1">
                        <label className="font-bold text-amber-950">Application Number *</label>
                        <input
                          type="text"
                          required
                          value={formData.applicationNumber}
                          onChange={(e) => handleInputChange('applicationNumber', e.target.value)}
                          placeholder="e.g. 202411032190"
                          className="p-2.5 bg-white border rounded-lg text-xs"
                        />
                        {errors.applicationNumber && <span className="text-[11px] text-red-600">{errors.applicationNumber}</span>}
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="font-bold text-amber-950">Filing Date</label>
                        <input
                          type="date"
                          value={formData.filingDate}
                          onChange={(e) => handleInputChange('filingDate', e.target.value)}
                          className="p-2.5 bg-white border rounded-lg text-xs"
                        />
                      </div>
                    </div>
                  )}

                  {formData.patentStatus === 'No Patent' && (
                    <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-700">
                      <strong>Status: Open Technology / No Patent Requested.</strong> Project is released under creative commons or trade secret protection without requiring patent filing certificates.
                    </div>
                  )}
                </div>
              </div>

              {/* SECTION 7: DEVELOPER INFORMATION */}
              <div className="flex flex-col gap-4 pb-6 border-b border-[#e8d3b9]">
                <div className="flex items-center gap-2 text-[#561922]">
                  <span className="material-symbols-outlined text-[22px] text-[#d4af37]">person</span>
                  <h3 className="font-headline font-bold text-base uppercase tracking-wider">
                    Section 7 – Developer Information
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Developer Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.devName}
                      onChange={(e) => handleInputChange('devName', e.target.value)}
                      placeholder="Dr. Siddharth Verma"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                    {errors.devName && <span className="text-[11px] text-red-600">{errors.devName}</span>}
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.devEmail}
                      onChange={(e) => handleInputChange('devEmail', e.target.value)}
                      placeholder="founder@aeropulse.health"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                    {errors.devEmail && <span className="text-[11px] text-red-600">{errors.devEmail}</span>}
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Phone Number</label>
                    <input
                      type="tel"
                      value={formData.devPhone}
                      onChange={(e) => handleInputChange('devPhone', e.target.value)}
                      placeholder="+91 98450 12890"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  <div className="sm:col-span-2 flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">College / Institution / Company</label>
                    <input
                      type="text"
                      value={formData.institution}
                      onChange={(e) => handleInputChange('institution', e.target.value)}
                      placeholder="IIT Kharagpur AgTech Incubator / AIIMS Delhi"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-bold text-[#1b1c1a]">Team Size & Composition</label>
                    <input
                      type="text"
                      value={formData.team}
                      onChange={(e) => handleInputChange('team', e.target.value)}
                      placeholder="4 Engineers, 1 Agronomist"
                      className="p-3 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 8: DECLARATION & SUBMIT BUTTON */}
              <div className="flex flex-col gap-4">
                <label className="flex items-start gap-2.5 text-xs text-[#534343] cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.declaration}
                    onChange={(e) => handleInputChange('declaration', e.target.checked)}
                    className="w-4 h-4 mt-0.5 rounded text-[#561922] accent-[#561922]"
                  />
                  <span>
                    <strong>I confirm that the information provided is accurate and that I have the necessary rights to submit this project and its supporting materials.</strong> I understand that patent status verification is subject to administrative audit.
                  </span>
                </label>
                {errors.declaration && <span className="text-[11px] text-red-600 font-bold">{errors.declaration}</span>}

                <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e8d3b9]">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-5 py-2.5 rounded-xl text-xs font-bold text-[#534343] hover:bg-[#efeeeb]"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="btn-gold text-xs py-3 px-6 shadow-md flex items-center gap-2 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-4 h-4 border-2 border-[#561922] border-t-transparent rounded-full animate-spin"></span>
                        <span>Validating & Submitting to NEXUS VENTURE AI...</span>
                      </>
                    ) : (
                      <>
                        <span className="material-symbols-outlined text-[18px]">publish</span>
                        <span>Submit Project to Directory</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
}

window.SubmitProjectModal = SubmitProjectModal;

