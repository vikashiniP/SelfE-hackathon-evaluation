/**
 * NEXUS VENTURE AI - Floating AI Chatbot Component
 * Name: Nexus Venture AI Assistant
 * Trigger: Floating Robot Head with "Talk to Nexus Venture AI"
 * Features:
 * - Search projects by sector, stage, and build costs using live data
 * - Find investors interested in specific sectors
 * - Guide through project submission, escrow, and patent audits
 * - Strict filter for unrelated questions with the exact required response:
 *   "Sorry, I can't help with unrelated questions. I can help you explore startup projects, investors and innovation opportunities on NEXUS VENTURE AI."
 */

function Chatbot({ onSelectProject, onNavigateTab }) {
  const { useState, useEffect, useRef } = React;

  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 'msg-1',
      sender: 'bot',
      text: "Hello! I am the **Nexus Venture AI Assistant**. I can help you explore innovative startup projects, find accredited investors by sector, evaluate build costs, and guide you through submitting your own project.",
      suggestions: [
        'Show me healthcare projects',
        'Find education projects with low build costs',
        'Which investors are interested in agriculture?',
        'How does project submission work?'
      ]
    }
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (isOpen && messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isTyping]);

  // Knowledge base query engine
  const processQuery = (rawQuery) => {
    const query = rawQuery.toLowerCase().trim();

    // Check for off-topic/unrelated questions (e.g., "Where is China?", "Where is the Nile River?", general trivia)
    const unrelatedKeywords = [
      'china', 'nile', 'river', 'capital of', 'weather in', 'president', 'mount everest',
      'football score', 'recipe', 'movie', 'song', 'joke', 'paris', 'france capital', 'who won'
    ];

    const isExplicitlyUnrelated = unrelatedKeywords.some((k) => query.includes(k));
    const isPlatformRelated = [
      'project', 'startup', 'investor', 'invest', 'funding', 'cost', 'sector', 'stage',
      'patent', 'review', 'rating', 'developer', 'founder', 'agriculture', 'healthcare',
      'environment', 'education', 'technology', 'business', 'escrow', 'submit', 'nexus',
      'help', 'hi', 'hello', 'hey', 'cardiopulse', 'agrisense', 'aquapurify', 'codex',
      'neuralgrid', 'ledgerflow', 'ananya', 'rajesh', 'suresh'
    ].some((k) => query.includes(k));

    if (isExplicitlyUnrelated || (!isPlatformRelated && query.length > 15)) {
      return {
        text: "Sorry, I can't help with unrelated questions. I can help you explore startup projects, investors and innovation opportunities on NEXUS VENTURE AI.",
        items: []
      };
    }

    const projects = window.NexusDB ? window.NexusDB.getProjects() : [];
    const investors = window.NexusDB ? window.NexusDB.getInvestors() : [];

    // 1. Sector queries (e.g. "show me healthcare projects")
    const matchedSector = ['healthcare', 'agriculture', 'environment', 'education', 'technology', 'business']
      .find((sec) => query.includes(sec));

    if (matchedSector && (query.includes('project') || query.includes('show') || query.includes('find') || query.includes('startup'))) {
      const secName = matchedSector.charAt(0).toUpperCase() + matchedSector.slice(1);
      const matches = projects.filter((p) => p.sector.toLowerCase() === matchedSector);

      if (matches.length > 0) {
        return {
          text: `Here are the active **${secName}** startup projects on NEXUS VENTURE AI:`,
          items: matches.map((m) => ({
            id: m.id,
            name: m.name,
            cost: m.buildCost,
            stage: m.stage,
            patent: m.patentStatus,
            summary: m.summary
          }))
        };
      }
    }

    // 2. Low build cost queries (e.g. "Find education projects with low build costs")
    if (query.includes('low') && (query.includes('cost') || query.includes('build'))) {
      let filtered = projects;
      if (matchedSector) {
        filtered = filtered.filter((p) => p.sector.toLowerCase() === matchedSector);
      }
      // Sort by build cost ascending
      filtered = [...filtered].sort((a, b) => {
        const costA = parseInt((a.buildCost || '0').replace(/[^0-9]/g, ''), 10);
        const costB = parseInt((b.buildCost || '0').replace(/[^0-9]/g, ''), 10);
        return costA - costB;
      });

      return {
        text: `Here are the startup projects ordered by lowest build cost:`,
        items: filtered.slice(0, 3).map((m) => ({
          id: m.id,
          name: m.name,
          cost: m.buildCost,
          stage: m.stage,
          patent: m.patentStatus,
          summary: m.summary
        }))
      };
    }

    // 3. Investor queries (e.g. "Which investors are interested in agriculture?")
    if (query.includes('investor') || query.includes('angel') || query.includes('fund') || query.includes('syndicate')) {
      if (matchedSector) {
        const secName = matchedSector.charAt(0).toUpperCase() + matchedSector.slice(1);
        const matchedInvestors = investors.filter((inv) =>
          (inv.preferredSectors || []).some((s) => s.toLowerCase() === matchedSector)
        );

        if (matchedInvestors.length > 0) {
          const invList = matchedInvestors.map((i) => `• **${i.name}** (${i.company}) – Ticket Range: ${i.fundingRange}`).join('\n');
          return {
            text: `The following accredited investors on NEXUS VENTURE AI are actively investing in **${secName}**:\n\n${invList}\n\nYou can reach them via the Investor Profile tab.`,
            actionTab: 'investor'
          };
        }
      }

      const allInv = investors.map((i) => `• **${i.name}** (${i.company}) – Sectors: ${i.preferredSectors.join(', ')}`).join('\n');
      return {
        text: `We currently have verified investors ready to allocate capital:\n\n${allInv}\n\nVisit the Investor Profile section to view their track records.`,
        actionTab: 'investor'
      };
    }

    // 4. Project submission queries (e.g. "how does project submission work?")
    if (query.includes('submit') || query.includes('how to post') || query.includes('portal')) {
      return {
        text: `To submit your startup project to **NEXUS VENTURE AI**:\n\n1. Click **Submit Project** in the sidebar or top banner.\n2. Complete the 8-section form with your project name, 6 sectors, and 4 development stages.\n3. Add YouTube video demo embed and image links.\n4. Input your hardware parts list, programming languages, and build cost in Indian Rupees (₹).\n5. Select your patent status (Granted, Published, Applied, or No Patent).\n\nUpon submission, your project instantly appears in the Explore Projects directory!`,
        actionSubmit: true
      };
    }

    // 5. Patent status queries
    if (query.includes('patent') || query.includes('ip')) {
      return {
        text: `NEXUS VENTURE AI recognizes exactly 4 patent statuses to ensure complete transparency:\n\n1. **Granted Patent** (requires patent number and grant date)\n2. **Published Patent Application** (application & publication numbers)\n3. **Patent Applied – Pending** (filing application receipt)\n4. **No Patent** (open-source or copyright protected)\n\nWe never misrepresent pending applications as approved patents.`
      };
    }

    // 6. Greetings / General Help
    if (query.includes('hello') || query.includes('hi') || query.includes('help')) {
      return {
        text: `Hello! I can help you search all startup projects, find investors by sector, look up build costs in Indian Rupees (₹), and guide you through the developer submission process on **NEXUS VENTURE AI**.`
      };
    }

    // Default fallback with helpful options
    return {
      text: `I searched NEXUS VENTURE AI for "${rawQuery}". Here are a few ways I can assist you:`,
      suggestions: [
        'Show me healthcare projects',
        'Find education projects with low build costs',
        'Which investors are interested in agriculture?',
        'How does project submission work?'
      ]
    };
  };

  const handleSendMessage = (textToSend) => {
    const text = textToSend || inputVal;
    if (!text.trim()) return;

    const userMsg = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text: text.trim()
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    setTimeout(() => {
      const response = processQuery(text);
      const botMsg = {
        id: 'msg-bot-' + Date.now(),
        sender: 'bot',
        text: response.text,
        items: response.items || [],
        actionTab: response.actionTab || null,
        suggestions: response.suggestions || []
      };

      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 600);
  };

  const handleItemClick = (projectId) => {
    if (window.NexusDB && onSelectProject) {
      const proj = window.NexusDB.getProjectById(projectId);
      if (proj) {
        onSelectProject(proj);
      }
    }
  };

  return (
    <>
      {/* Floating Trigger Button at Bottom-Right */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="floating-chatbot-btn"
        aria-label="Talk to Nexus Venture AI"
      >
        <div className="robot-head-icon shadow-xs">
          <span className="material-symbols-outlined text-[20px]">smart_toy</span>
        </div>
        <span>Talk to Nexus Venture AI</span>
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="chatbot-window">
          {/* Header */}
          <div className="p-3.5 bg-[#561922] text-white border-b-2 border-[#d4af37] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#d4af37] text-[#561922] flex items-center justify-center font-bold">
                <span className="material-symbols-outlined text-[20px]">smart_toy</span>
              </div>
              <div className="flex flex-col">
                <span className="font-headline font-bold text-xs text-white">
                  Nexus Venture AI Assistant
                </span>
                <span className="text-[10px] text-[#f7e7ce] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  <span>Active Ecosystem Advisor</span>
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="w-7 h-7 rounded-full hover:bg-white/10 flex items-center justify-center text-[#f7e7ce]"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
          </div>

          {/* Messages List */}
          <div className="flex-1 p-3.5 overflow-y-auto flex flex-col gap-3 bg-[#faf6f0] text-xs">
            {messages.map((m) => {
              const isUser = m.sender === 'user';
              return (
                <div key={m.id} className={`flex flex-col gap-1 ${isUser ? 'items-end' : 'items-start'}`}>
                  <div
                    className={`p-3 rounded-2xl max-w-[88%] leading-relaxed ${
                      isUser
                        ? 'bg-[#561922] text-[#f7e7ce] rounded-br-xs border border-[#d4af37]'
                        : 'bg-white text-[#1b1c1a] rounded-bl-xs border border-[#e8d3b9] shadow-xs'
                    }`}
                  >
                    <div className="whitespace-pre-wrap">{m.text}</div>

                    {/* Interactive Project Match Cards */}
                    {m.items && m.items.length > 0 && (
                      <div className="flex flex-col gap-2 mt-2 pt-2 border-t border-[#e8d3b9]">
                        {m.items.map((item) => (
                          <div
                            key={item.id}
                            onClick={() => handleItemClick(item.id)}
                            className="p-2 bg-[#faf6f0] hover:bg-white border border-[#e8d3b9] hover:border-[#561922] rounded-xl cursor-pointer transition-all flex flex-col gap-1"
                          >
                            <div className="flex items-center justify-between">
                              <strong className="text-[#561922]">{item.name}</strong>
                              <span className="text-[10px] font-bold text-[#b89358]">{item.cost}</span>
                            </div>
                            <span className="text-[10px] text-[#534343] line-clamp-1">{item.summary}</span>
                            <div className="flex items-center justify-between text-[9px] text-[#6b5c47] pt-1">
                              <span>Stage: {item.stage}</span>
                              <span className="font-bold text-[#561922] flex items-center gap-0.5">
                                <span>View Details</span>
                                <span className="material-symbols-outlined text-[10px]">arrow_forward</span>
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Suggestion Pills */}
                  {m.suggestions && m.suggestions.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1">
                      {m.suggestions.map((sugg, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleSendMessage(sugg)}
                          className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-white border border-[#d4af37] text-[#561922] hover:bg-[#561922] hover:text-white transition-all text-left"
                        >
                          {sugg}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}

            {isTyping && (
              <div className="flex items-center gap-1.5 p-2 bg-white rounded-xl border border-[#e8d3b9] w-fit text-[#6b5c47] text-[11px]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#561922] animate-bounce"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37] animate-bounce" style={{ animationDelay: '0.15s' }}></span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#561922] animate-bounce" style={{ animationDelay: '0.3s' }}></span>
                <span className="ml-1">Querying database...</span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
            className="p-2.5 bg-white border-t border-[#e8d3b9] flex items-center gap-2"
          >
            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Ask about projects, investors, costs..."
              className="flex-1 p-2 bg-[#faf6f0] border border-[#e8d3b9] rounded-xl text-xs text-[#1b1c1a] focus:outline-none focus:border-[#561922]"
            />
            <button
              type="submit"
              className="p-2 rounded-xl bg-[#561922] hover:bg-[#3c0b12] text-[#d4af37] flex items-center justify-center border border-[#d4af37] cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">send</span>
            </button>
          </form>
        </div>
      )}
    </>
  );
}

window.Chatbot = Chatbot;

