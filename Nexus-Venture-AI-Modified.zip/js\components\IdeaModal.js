/**
 * NEXUS VENTURE AI - Public Idea Submission Component
 * Follows Section 11 of the Master Prompt:
 * Allows the general public to submit innovative ideas.
 * Fields: Name, Email, Idea Title, Sector, Problem Statement, Proposed Solution, Expected Benefits, Optional Image.
 */

function IdeaModal({ isOpen, onClose, onIdeaSubmitted }) {
  if (!isOpen) return null;

  const { useState } = React;

  const [form, setForm] = useState({
    name: '',
    email: '',
    title: '',
    sector: 'Agriculture',
    problem: '',
    solution: '',
    benefits: '',
    imageUrl: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const sectors = ['Agriculture', 'Environment', 'Healthcare', 'Education', 'Technology', 'Business'];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.title.trim() || !form.problem.trim() || !form.solution.trim()) {
      setError('Please fill in all required fields.');
      return;
    }

    const savedIdea = window.NexusDB.addIdea({
      name: form.name.trim(),
      email: form.email.trim(),
      title: form.title.trim(),
      sector: form.sector,
      problem: form.problem.trim(),
      solution: form.solution.trim(),
      benefits: form.benefits.trim(),
      imageUrl: form.imageUrl.trim() || null
    });

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      if (onIdeaSubmitted) onIdeaSubmitted(savedIdea);
      onClose();
    }, 2000);
  };

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true">
      <div className="modal-dialog max-w-xl" onClick={(e) => e.stopPropagation()}>
        
        {/* Header */}
        <div className="modal-header-burgundy">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#d4af37] text-[24px]">lightbulb</span>
            <div className="flex flex-col">
              <h3 className="font-headline font-bold text-lg text-white">
                Submit Public Innovation Idea
              </h3>
              <span className="text-[10px] text-[#f7e7ce] uppercase tracking-wider font-semibold">
                Open Community Gateway
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#561922] text-white flex items-center justify-center border border-[#d4af37]"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="p-6 bg-emerald-50 border-2 border-emerald-300 rounded-2xl text-center flex flex-col items-center gap-3">
              <span className="material-symbols-outlined text-emerald-600 text-[42px]">check_circle</span>
              <h4 className="font-headline font-bold text-xl text-emerald-950">
                Your Idea Has Been Submitted!
              </h4>
              <p className="text-xs text-emerald-800 max-w-md">
                Thank you for contributing to the <strong>NEXUS VENTURE AI</strong> ecosystem. Your concept has been archived securely and will be reviewed by university mentors and developers.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-xs">
              <p className="text-xs text-[#534343] leading-relaxed">
                The general public is invited to submit innovative ideas. Explain the real problem your idea solves and its expected impact.
              </p>

              {error && (
                <div className="p-2.5 bg-red-50 text-red-700 border border-red-300 rounded-lg font-bold">
                  {error}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex flex-col gap-1">
                  <label className="font-bold text-[#1b1c1a]">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Vikas Sharma"
                    className="p-2.5 bg-[#faf6f0] border rounded-xl"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-bold text-[#1b1c1a]">Your Email Address *</label>
                  <input
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="vikas.sharma@gmail.com"
                    className="p-2.5 bg-[#faf6f0] border rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 flex flex-col gap-1">
                  <label className="font-bold text-[#1b1c1a]">Idea Title *</label>
                  <input
                    type="text"
                    required
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    placeholder="e.g. Smart Solar-Powered Grain Moisture Bag"
                    className="p-2.5 bg-[#faf6f0] border rounded-xl font-semibold"
                  />
                </div>

                <div className="flex flex-col gap-1">
                  <label className="font-bold text-[#1b1c1a]">Sector *</label>
                  <select
                    value={form.sector}
                    onChange={(e) => setForm({ ...form, sector: e.target.value })}
                    className="p-2.5 bg-[#faf6f0] border rounded-xl"
                  >
                    {sectors.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-bold text-[#1b1c1a]">Problem Statement (What issue does this address?) *</label>
                <textarea
                  required
                  rows="2"
                  value={form.problem}
                  onChange={(e) => setForm({ ...form, problem: e.target.value })}
                  placeholder="Describe the challenge faced by people, farmers, schools or businesses..."
                  className="p-2.5 bg-[#faf6f0] border rounded-xl"
                ></textarea>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-bold text-[#1b1c1a]">Proposed Solution (How would it work?) *</label>
                <textarea
                  required
                  rows="2"
                  value={form.solution}
                  onChange={(e) => setForm({ ...form, solution: e.target.value })}
                  placeholder="Explain your approach, technology, or physical tool concept..."
                  className="p-2.5 bg-[#faf6f0] border rounded-xl"
                ></textarea>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-bold text-[#1b1c1a]">Expected Benefits for the Community</label>
                <input
                  type="text"
                  value={form.benefits}
                  onChange={(e) => setForm({ ...form, benefits: e.target.value })}
                  placeholder="e.g. Cuts grain post-harvest loss by 20% for smallholder farmers"
                  className="p-2.5 bg-[#faf6f0] border rounded-xl"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-bold text-[#1b1c1a]">Supporting Sketch or Photo URL (Optional)</label>
                <input
                  type="url"
                  value={form.imageUrl}
                  onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
                  placeholder="https://..."
                  className="p-2.5 bg-[#faf6f0] border rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2 border-t border-[#e8d3b9]">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-[#534343]"
                >
                  Cancel
                </button>
                <button type="submit" className="btn-gold text-xs py-2 px-6 shadow-sm">
                  Submit Your Idea
                </button>
              </div>
            </form>
          )}
        </div>

      </div>
    </div>
  );
}

window.IdeaModal = IdeaModal;

